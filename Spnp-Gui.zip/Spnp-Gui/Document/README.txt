The document for the interface and a tutorial can be found in the following web page:

www.ee.duke.edu/~chirel/research.html
