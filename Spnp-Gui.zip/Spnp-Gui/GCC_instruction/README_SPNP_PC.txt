
-------------------------------------------
Have the gcc compiler installed in your PC:
-------------------------------------------
Open the windows explorer, then click on the file full.exe in this directory
Execute full.exe will install the cgywin gcc compiler on the Pc
Install in the directory C:\cygnus

-------------------------------------------
Environment configuration:
-------------------------------------------
  Open a MS-DOS prompt,

  Integrate the path of the gcc compiler in your environment: 
