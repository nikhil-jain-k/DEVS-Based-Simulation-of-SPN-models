use OLE;

# For example sharpe code_1loop.txt | perl plot2_row.pl k result x1 throughput graph1

$NoOfArgs = @ARGV;
if ($NoOfArgs == 0) {
  # print STDERR ("Usage: makePlot_row.pl <xAxis variable> <y variable> [<y variable>]* <comma separated list of parameter variables> <legend for X axis> <legend for Y axis> <Name of the graph> \n");
  print STDERR ("Usage: makePlot_row.pl <xAxis variable> <y variable> [<y variable>]* <legend for X axis> <legend for Y axis> <Name of the graph> \n");
  exit(0);
}

$application = CreateObject OLE 'Excel.Application' || die $!;
$application->{'Visible'} = 1;
$workbook = $application->Workbooks->Add();
for ($i=1; $i<$NoOfArgs-3; $i++) { 
  if ($i > 1) {
    $workbook->Sheets->Add();
  }
  $worksheet_var = "worksheet$i";
  $$worksheet_var = $workbook->Sheets("Sheet$i");
}

@ColumnLetter = ("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");

$xparam = $ARGV[0];
@yparams = ();

for ($i=1; $i<$NoOfArgs-3; $i++) {
  @yparams = (@yparams, $ARGV[$i]);
}

@LegendVars = "legend_test";
print (LegendVars);

$xindex = 0;
$vindex = 0;

$series = "series1";
@series = ();

$line = <STDIN>;
while ($line ne "") {
  if ($line =~ /\b$xparam\b/) {
      # change /: to /=
      if ($line =~ /=[ \t]*([0-9\.e+-]+)/) {
        $xindex++;
        for ($i=1; $i<$NoOfArgs-3; $i++) {
	  $worksheet_var = "worksheet$i";
   	  $$worksheet_var->Range("A$xindex")->{'Value'} = $1;
        }      
	  $vindex = 0;
      }
  }

  
  # ============ Change $NoOfArgs-1 to $NoOfArgs ==============
  for ($i=1; $i<$NoOfArgs-3; $i++) {   

    print STDERR (" \n");
    print STDERR ("============================================");
    print STDERR (" \n");
    print STDERR (" LINE : ");
    print STDERR ($line);   
    print STDERR (" Y PARAM : ");
    $x1 = "$yparams[$i-1]";
    print STDERR ($x1);
    print STDERR (" \n");

    # CHANGE THE TEST check to have the functions xxxx(xx) recognized
   if ($line =~ /\b$yparams[$i-1]\b/) {
   # if ($line =~ /\bresult1\b/) {
   # if ($line =~ /\b[$yparams[$i-1]+()*\b/) {
   # if ($line =~ /\b[()]*\b/) {
      print STDERR ("=== SUCCESS === \n");

      if ($line =~ /:[ \t]*([0-9\.e+-]+)/) {
        $vindex++;

        $worksheet_var = "worksheet$i"; 
	  $$worksheet_var->Range("$ColumnLetter[$vindex]$xindex")->{'Value'} = $1;
      }
    }
  }

  $line = <STDIN>;
}

for ($i=1; $i<$NoOfArgs-3; $i++) {
  print($ARGV[$i]);
  $workbook->Sheets("Sheet$i")->{'Name'} = $ARGV[$i];

  $workbook->Sheets($ARGV[$i])->Select;
  $workbook->Sheets($ARGV[$i])->Columns("B:$ColumnLetter[$vindex]")->{'NumberFormat'} = "0.00000000E+00";
  $workbook->Sheets($ARGV[$i])->Columns("B:$ColumnLetter[$vindex]")->AutoFit;

  $workbook->Sheets($ARGV[$i])->Columns("B:$ColumnLetter[$vindex]")->Select;

  $chart = $workbook->Charts->Add;
  $chart->{'PlotBy'} = 2;
  
  $chart->{'ChartType'} = 65;
  
  $chart->{'Name'} = "$ARGV[$i]_chart";
  $chart->Axes(2, 1)->Select;
  $chart->Axes(2, 1)->{'HasTitle'} = True;
  $chart->Axes(2, 1)->AxisTitle->Characters->{'Text'} = $ARGV[$NoOfArgs-2];
  #$chart->Axes(2, 1)->AxisTitle->Characters->{'Text'} = "TEST 1";
  $chart->Axes(1, 1)->Select;
  $chart->Axes(1, 1)->{'HasTitle'} = True;
  $chart->Axes(1, 1)->AxisTitle->Characters->{'Text'} = $ARGV[$NoOfArgs-3];
  #$chart->Axes(1, 1)->AxisTitle->Characters->{'Text'} = "TEST 2";

  for ($j=1; $j<=$vindex ;$j++) {
    $chart->SeriesCollection($j)->{'XValues'} = "=$ARGV[$i]!C1";
    $legendtext = $ARGV[$NoOfArgs-1];
    $chart->SeriesCollection($j)->{'Name'} = "=\"$legendtext\"";    
  }
}

