#include <stdio.h>
#include "user.h"

/* corresponds to birth-death model in the paper*/

#define PLST 2 /* Short Packet Size */
#define PLMD 4 /* Medium Packet Size */
#define PLLG 32 /* Long Packet Size */
 
#define c1 0.342
#define c2 0.093
#define c3 0.565

#define rateOUT 5000

int K=3;
double lambda=0.9, mu=1, beta=1.1;  

int BN=40; /* Buffer Size */
int QLEN;

double g0=0.01, g1=0.05, beta_01=0.5, beta_10=0.5;
double a0=0.01, a1=0.05, alpha_01=0.5, alpha_10=0.5;

  /* prototype guard functions */ 
  int guardARV ();
 
  int  guardt1() ; 
  int  guardt2 () ; 
  int  guardTunicast () ; 
  int guardBST () ; 
  int guardBMD () ; 
  int guardBLG () ; 

  /* prototype rate functions */ 
  double rateARV0 () ; 
  double rateTunicast () ; 
  

void options() {
 
  iopt(IOP_PR_RGRAPH,VAL_NO) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_NO) ;
  iopt(IOP_USENAME,VAL_NO) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_NO) ;
  iopt(IOP_PR_MC_ORDER,VAL_FROMTO) ;

  iopt(IOP_SENSITIVITY,VAL_NO) ;
  iopt(IOP_MC,VAL_CTMC) ;
  iopt(IOP_SSMETHOD,VAL_SSSOR) ;
  iopt(IOP_TSMETHOD,VAL_FOXUNIF) ;
  iopt(IOP_ITERATIONS,20000) ;
  fopt(FOP_PRECISION,1e-13) ;
  fopt(FOP_ABS_RET_M0,0.0) ;
  iopt(IOP_CUMULATIVE,VAL_YES) ;
  iopt(IOP_SSDETECT,VAL_YES) ;
  iopt(IOP_OK_ABSMARK,VAL_NO) ;
  iopt(IOP_OK_VANLOOP,VAL_NO) ;
  iopt(IOP_OK_TRANS_M0,VAL_YES) ;
  iopt(IOP_OK_VAN_M0,VAL_YES) ;
  iopt(IOP_ELIMINATION,VAL_REDONTHEFLY) ;
 
  

} 


/* REWARD Functions */ 
double QL () {
	if (mark("PBUF") > QLEN) 
		return(1.0);
	else
		return(0);
}
double MLP () {
	if (mark("PBUF") > BN - PLMD) 
		return(1.0);
	else
		return(0);
}
double SLP () {
	if (mark("PBUF") > BN - PLST)
		return(1.0);
	else
		return(0);
}
double LLP () {
	if (mark("PBUF") > BN - PLLG) 
		return(1.0);
	else
		return(0);
}

/* GUARD Functions */  
int guardARV ()
{
  int n = 0;
  if (mark("PCS2")>0) 
    n = 1;
  if (mark("PAR") + mark("PCS1") + n < K)
    return(1);
  else
    return(0);
}

int guardt2 () {
  if (mark("Puon")==0) 
		return(1);
	else
		return(0);
}
int guardTunicast () {
    if (mark("Puon")>0)
                return(1);
	else
		return(0);
}

int guardSTO () {
	if (mark("PBUF") <= BN - PLST)
		return(1);
	else
		return(0);
}
int guardMDO () {
	if (mark("PBUF") <= BN - PLMD)
		return(1);
	else
		return(0);
}
int guardLGO () {
	if (mark("PBUF") <= BN - PLLG)
		return(1);
	else
		return(0);
}

/* RATE Functions */ 



double rateTbroad () {

  if (mark("Pbroad")) 
		return(g1);
  else
		return(g0);
 
}

double rateTunicast () {
double x= mark("Puon")*a1+mark("Puoff")*a0;
return (x);
}


void net() {

   /*  PLACE  */
  place("PAR") ;
  place("PCS1") ;
  place("PCS2") ;

  place("PARV") ;
  place("PST") ;
  place("PMD") ;
  place("PLG") ;
  place("PBUF") ;
  place("POUT") ;

  place("Pbroad");

  place("Puon");
  place("Puoff"); 
  place("Pdepart");
 
  /*  TRANSITION  */
  rateval("TARV1",lambda);
  guard("TARV1", guardARV);
  rateval("TAR",mu) ;
  rateval("TCS",beta);
  imm("tCS");
  priority("tCS",20) ;
  probval("tCS",1.) ;

  ratefun("Tbroad",rateTbroad) ;

  rateval("Yon",beta_01) ;
  rateval("Yoff",beta_10) ;

  ratedep("Tuon",alpha_01,"Puoff");

  ratedep("Tuoff",alpha_10,"Puon");

  ratefun("Tunicast",rateTunicast);
  guard("Tunicast",guardTunicast);
 
  imm("t1");
  probval("t1",1.);
  priority("t1",20);

  imm("t2");
  probval("t2",1.);
  priority("t2",20);
  guard("t2",guardt2);


  imm("tSTI") ;
  priority("tSTI",20) ;
  probval("tSTI",c1) ;
  imm("tMDI") ;
  priority("tMDI",20) ;
  probval("tMDI",c2) ;
  imm("tLGI") ;
  priority("tLGI",20) ;
  probval("tLGI",c3) ;
  imm("tSTO") ;
  priority("tSTO",40) ;
  probval("tSTO",1.) ;
  guard("tSTO",guardSTO) ;
  imm("tMDO") ;
  priority("tMDO",40) ;
  probval("tMDO",1.) ;
  guard("tMDO",guardMDO) ;
  imm("tLGO") ;
  priority("tLGO",40) ;
  probval("tLGO",1.) ;
  guard("tLGO",guardLGO) ;
  imm("tSTL") ;
  priority("tSTL",20) ;
  probval("tSTL",1.) ;
  imm("tMDL") ;
  priority("tMDL",20) ;
  probval("tMDL",1.) ;
  imm("tLGL") ;
  priority("tLGL",20) ;
  probval("tLGL",1.) ;
  imm("tOUT") ;
  priority("tOUT",20) ;
  probval("tOUT",1.) ;
  rateval("TOUT",rateOUT) ;
 

  /*  ARC  */
 
  oarc("TARV1","PAR") ;
  iarc("TAR","PAR") ;
  oarc("TAR","PCS1") ;
  iarc("tCS","PCS1") ;
  moarc("tCS","PCS2", 3) ;
  iarc("TCS","PCS2") ;
  harc("tCS","PCS2") ;

  oarc("Yon","Pbroad") ;
  iarc("Yoff","Pbroad") ;
  harc("Yon","Pbroad") ;


  oarc("Tbroad","PARV") ;

  oarc("TARV1","Puon") ;
  oarc("TCS","Pdepart") ;
  oarc("Tuon","Puon") ;
  iarc("Tuoff","Puon") ;
  iarc("t1","Puon") ;
  miarc("t1","Pdepart",3) ;
  iarc("t2","Puoff") ;
  miarc("t2","Pdepart",3) ;
  oarc("Tuoff","Puoff") ;
  iarc("Tuon","Puoff") ;

  oarc("Tunicast","PARV") ;


  iarc("tSTI","PARV") ;
  iarc("tMDI","PARV") ;
  iarc("tLGI","PARV") ;
  oarc("tSTI","PST") ;
  oarc("tMDI","PMD") ;
  oarc("tLGI","PLG") ;
  iarc("tSTO","PST") ;
  iarc("tSTL","PST") ;
  iarc("tMDO","PMD") ;
  iarc("tMDL","PMD") ;
  iarc("tLGO","PLG") ;
  iarc("tLGL","PLG") ;
  moarc("tSTO","PBUF",PLST) ;
  moarc("tLGO","PBUF",PLLG) ;
  moarc("tMDO","PBUF",PLMD) ;
  iarc("tOUT","PBUF") ;
  moarc("tOUT","POUT",3) ;
  iarc("TOUT","POUT") ;
  harc("tOUT","POUT") ;
 
} 

int assert() { 
  return(RES_NOERR);
}

void ac_init() { 

}

void ac_reach() { 

}


void ac_final() { 
  double llp, mlp, slp, pql;

  solve(INFINITY);
  llp = expected(LLP);
  mlp = expected(MLP);
  slp = expected(SLP);
  
  pr_value("Loss Prob. of Short Packets (S)", slp);
  pr_value("Loss Prob. of Medium Packets (M)", mlp);
  pr_value("Loss Prob. of Long Packets (L)", llp);
  pr_value("Loss Prob. of total Packets (T)", c1 * slp + c2 * mlp + c3 * llp);

  for (QLEN = 0; QLEN < BN; QLEN += 5)
    {
      pql = expected(QL);
      fprintf(Outfile,"\nProb. for Queue Len (> %d) = %.12g\n", QLEN, pql);
    }

  QLEN = BN - 1;
  pql = expected(QL);
  fprintf(Outfile,"\nProb. for Queue Len (= %d) = %.12g\n", BN, pql);

  pr_std_average();
}
