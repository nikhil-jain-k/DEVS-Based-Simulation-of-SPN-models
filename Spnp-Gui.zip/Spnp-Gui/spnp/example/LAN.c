#include <stdio.h>
#include "user.h"

/* corresponds to ACCURATE model in the paper*/

#define PLST 2 /* Short Packet Size */
#define PLMD 4 /* Medium Packet Size */
#define PLLG 32 /* Long Packet Size */
 
#define c1 0.342
#define c2 0.093
#define c3 0.565

#define rateOUT 5000

int K=2;
double lambda=0.9, mu=1, beta=1.1;  

int BN=40; /* Buffer Size */
int QLEN;

double g0=0.01, g1=0.05, d01=0.5, d10=0.5;
double a0=0.01, a1=0.05, b01=0.5, b10=0.5;

  /* prototype guard functions */ 
  int guardARV ();
 
  int  guardARV1 () ; 
  int  guardARV2 () ; 
  int  guardARV3 () ; 
  int  guardARV4 () ; 

  int guardBST () ; 
  int guardBMD () ; 
  int guardBLG () ; 

  /* prototype rate functions */ 
  double rateARV0 () ; 
  double rateARV1 () ; 
  double rateARV2 () ; 
  double rateARV3 () ; 
  double rateARV4 () ; 

void options() {
 
  iopt(IOP_PR_RGRAPH,VAL_NO) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_NO) ;
  iopt(IOP_USENAME,VAL_NO) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_NO) ;
  iopt(IOP_PR_MC_ORDER,VAL_FROMTO) ;

  iopt(IOP_SENSITIVITY,VAL_NO) ;
  iopt(IOP_MC,VAL_CTMC) ;
  iopt(IOP_SSMETHOD,VAL_SSSOR) ;
  iopt(IOP_TSMETHOD,VAL_FOXUNIF) ;
  iopt(IOP_ITERATIONS,20000) ;
  fopt(FOP_PRECISION,1e-13) ;
  fopt(FOP_ABS_RET_M0,0.0) ;
  iopt(IOP_CUMULATIVE,VAL_YES) ;
  iopt(IOP_SSDETECT,VAL_YES) ;
  iopt(IOP_OK_ABSMARK,VAL_NO) ;
  iopt(IOP_OK_VANLOOP,VAL_NO) ;
  iopt(IOP_OK_TRANS_M0,VAL_YES) ;
  iopt(IOP_OK_VAN_M0,VAL_YES) ;
  iopt(IOP_ELIMINATION,VAL_REDONTHEFLY) ;

} 


/* REWARD Functions */ 
double QL () {
	if (mark("PBUF") > QLEN) 
		return(1.0);
	else
		return(0);
}
double MLP () {
	if (mark("PBUF") > BN - PLMD) 
		return(1.0);
	else
		return(0);
}
double SLP () {
	if (mark("PBUF") > BN - PLST)
		return(1.0);
	else
		return(0);
}
double LLP () {
	if (mark("PBUF") > BN - PLLG) 
		return(1.0);
	else
		return(0);
}

/* GUARD Functions */  
int guardARV ()
{
  int n = 0;
  if (mark("POUT")>0) 
    n = 1;
  if (mark("PAR") + mark("PCS") + n < K)
    return(1);
  else
    return(0);
}

int guardARV1 () {
int n = 0;
  if (mark("POUT")>0) n = 1;
  n+=mark("PAR") + mark("PCS");
	if (n>0)
		return(1);
	else
		return(0);
}

int guardARV2 () {
int n = 0;
  if (mark("POUT")>0) n = 1;
  n+=mark("PAR") + mark("PCS");
	if (n>1)
		return(1);
	else
		return(0);
}

int guardARV3 () {
int n = 0;
  if (mark("POUT")>0) n = 1;
  n+=mark("PAR") + mark("PCS");
	if (n>2)
		return(1);
	else
		return(0);
}

int guardARV4 () {
int n = 0;
  if (mark("POUT")>0) n = 1;
  n+=mark("PAR") + mark("PCS");
	if (n>3)
		return(1);
	else
		return(0);
}

int guardBST () {
	if (mark("PBUF") <= BN - PLST)
		return(1);
	else
		return(0);
}
int guardBMD () {
	if (mark("PBUF") <= BN - PLMD)
		return(1);
	else
		return(0);
}
int guardBLG () {
	if (mark("PBUF") <= BN - PLLG)
		return(1);
	else
		return(0);
}

/* RATE Functions */ 



double rateARV0 () {

  if (mark("PON0")) 
		return(g1);
  else
		return(g0);
 
}

double rateARV1 () {

  if (mark("PON1")) 
		return(a1);
  else
		return(a0);
 
}
double rateARV2 () {

  if (mark("PON2")) 
		return(a1);
  else
		return(a0);
 
}
double rateARV3 () {

  if (mark("PON3")) 
		return(a1);
  else
		return(a0);
 
}

double rateARV4 () {

  if (mark("PON4")) 
		return(a1);
  else
		return(a0);
 
}

void net() {

   /*  PLACE  */
  place("PAR") ;
  place("PCS") ;
  place("POUT") ;

  place("PARV") ;
  place("PST") ;
  place("PMD") ;
  place("PLG") ;
  place("PBUF") ;
  place("PEOUT") ;

  place("PON0");
  place("PON1");
  place("PON2"); 
  place("PON3");
  place("PON4");

  /*  TRANSITION  */
  rateval("TARV",lambda) ;
  guard("TARV", guardARV);
  rateval("TAR",mu) ;
  rateval("TCS",beta) ;
  imm("tOUT") ;
  priority("tOUT",20) ;
  probval("tOUT",1.) ;

  ratefun("TARV0",rateARV0) ;

  ratefun("TARV1",rateARV1) ;
  guard("TARV1",guardARV1) ;
  
  ratefun("TARV2",rateARV2) ;
  guard("TARV2",guardARV2) ;
  
  ratefun("TARV3",rateARV3) ;
  guard("TARV3",guardARV3) ;

  ratefun("TARV4",rateARV4) ;
  guard("TARV4",guardARV4) ;

  rateval("T001",d01) ;
  rateval("T010",d10) ;

  rateval("T101",b01) ;
  rateval("T110",b10) ;

  rateval("T201",b01) ;
  rateval("T210",b10) ;

  rateval("T301",b01) ;
  rateval("T310",b10) ;

  rateval("T401",b01) ;
  rateval("T410",b10) ;


  imm("tST") ;
  priority("tST",20) ;
  probval("tST",c1) ;
  imm("tMD") ;
  priority("tMD",20) ;
  probval("tMD",c2) ;
  imm("tLG") ;
  priority("tLG",20) ;
  probval("tLG",c3) ;
  imm("tBST") ;
  priority("tBST",40) ;
  probval("tBST",1.) ;
  guard("tBST",guardBST) ;
  imm("tBMD") ;
  priority("tBMD",40) ;
  probval("tBMD",1.) ;
  guard("tBMD",guardBMD) ;
  imm("tBLG") ;
  priority("tBLG",40) ;
  probval("tBLG",1.) ;
  guard("tBLG",guardBLG) ;
  imm("tLST") ;
  priority("tLST",20) ;
  probval("tLST",1.) ;
  imm("tLMD") ;
  priority("tLMD",20) ;
  probval("tLMD",1.) ;
  imm("tLLG") ;
  priority("tLLG",20) ;
  probval("tLLG",1.) ;
  imm("tEOUT") ;
  priority("tEOUT",20) ;
  probval("tEOUT",1.) ;
  rateval("TOUT",rateOUT) ;
 

  /*  ARC  */
 
  oarc("TARV","PAR") ;
  iarc("TAR","PAR") ;
  oarc("TAR","PCS") ;
  iarc("tOUT","PCS") ;
  moarc("tOUT","POUT", 3) ;
  iarc("TCS","POUT") ;
  harc("tOUT","POUT") ;

  oarc("T001","PON0") ;
  iarc("T010","PON0") ;
  harc("T001","PON0") ;
 
  oarc("T101","PON1") ;
  iarc("T110","PON1") ;
  harc("T101","PON1") ;

  oarc("T201","PON2") ;
  iarc("T210","PON2") ;
  harc("T201","PON2") ;

  oarc("T301","PON3") ;
  iarc("T310","PON3") ;
  harc("T301","PON3") ;

  oarc("T401","PON4") ;
  iarc("T410","PON4") ;
  harc("T401","PON4") ;

  oarc("TARV0","PARV") ;
  oarc("TARV1","PARV") ;
  oarc("TARV2","PARV") ;
  oarc("TARV3","PARV") ;
  oarc("TARV4","PARV") ;

  iarc("tST","PARV") ;
  iarc("tMD","PARV") ;
  iarc("tLG","PARV") ;
  oarc("tST","PST") ;
  oarc("tMD","PMD") ;
  oarc("tLG","PLG") ;
  iarc("tBST","PST") ;
  iarc("tLST","PST") ;
  iarc("tBMD","PMD") ;
  iarc("tLMD","PMD") ;
  iarc("tBLG","PLG") ;
  iarc("tLLG","PLG") ;
  moarc("tBST","PBUF",PLST) ;
  moarc("tBLG","PBUF",PLLG) ;
  moarc("tBMD","PBUF",PLMD) ;
  iarc("tEOUT","PBUF") ;
  moarc("tEOUT","PEOUT",3) ;
  iarc("TOUT","PEOUT") ;
  harc("tEOUT","PEOUT") ;
 
} 

int assert() { 
  return(RES_NOERR);
}

void ac_init() { 

}

void ac_reach() { 

}


void ac_final() { 
  double llp, mlp, slp, pql;
  int dBN = BN/20;

  if (dBN<1) dBN=1;

  solve(INFINITY);
  llp = expected(LLP);
  mlp = expected(MLP);
  slp = expected(SLP);
  
  pr_value("Loss Prob. of Short Packets (S)", slp);
  pr_value("Loss Prob. of Medium Packets (M)", mlp);
  pr_value("Loss Prob. of Long Packets (L)", llp);
  pr_value("Loss Prob. of total Packets (T)", c1 * slp + c2 * mlp + c3 * llp);

  for (QLEN = 0; QLEN < BN; QLEN += dBN)
    {
      pql = expected(QL);
      fprintf(Outfile,"\nProb. for Queue Len (> %d) = %.12g\n", QLEN, pql);
    }

  QLEN = BN - 1;
  pql = expected(QL);
  fprintf(Outfile,"\nProb. for Queue Len (= %d) = %.12g\n", BN, pql);

  pr_std_average();
}
