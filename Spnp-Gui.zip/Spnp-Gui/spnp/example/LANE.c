#include <stdio.h>
#include "user.h"

/* corresponds to MMPP model in paper*/

#define PLST 2 /* Short Packet Size */
#define PLMD 4 /* Medium Packet Size */
#define PLLG 32 /* Long Packet Size */
 
#define c1 0.342
#define c2 0.093
#define c3 0.565

#define rateOUT 5000

int K=3;
double lambda=0.9, mu=1, beta=1.1;  

int BN=100; /* Buffer Size */
int QLEN;

double g0=0.01, g1=0.05, d01=0.5, d10=0.5;
double a0=0.01, a1=0.05, b01=0.5, b10=0.5;
double m2, v2, u2, t2;
double m1, v1, u1, t1;
double rateAH, rateAL,theta0,theta1;

 
  /* prototype guard functions */ 
  int guardARV ();
  int guardARV2 () ; 
  int guardBST () ; 
  int guardBMD () ; 
  int guardBLG () ; 

  /* prototype rate functions */ 
  double rateARV2 () ; 
  double t01 ();
  double t10 ();
  


void options() {
 
  iopt(IOP_PR_RGRAPH,VAL_NO) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_NO) ;
  iopt(IOP_USENAME,VAL_NO) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_NO) ;
  iopt(IOP_PR_MC_ORDER,VAL_FROMTO) ;

  iopt(IOP_SENSITIVITY,VAL_NO) ;
  iopt(IOP_MC,VAL_CTMC) ;
  iopt(IOP_SSMETHOD,VAL_SSSOR) ;
  iopt(IOP_TSMETHOD,VAL_FOXUNIF) ;
  iopt(IOP_ITERATIONS,20000) ;
  fopt(FOP_PRECISION,1e-13) ;
  fopt(FOP_ABS_RET_M0,0.0) ;
  iopt(IOP_CUMULATIVE,VAL_YES) ;
  iopt(IOP_SSDETECT,VAL_YES) ;
  iopt(IOP_OK_ABSMARK,VAL_NO) ;
  iopt(IOP_OK_VANLOOP,VAL_NO) ;
  iopt(IOP_OK_TRANS_M0,VAL_YES) ;
  iopt(IOP_OK_VAN_M0,VAL_YES) ;
  iopt(IOP_ELIMINATION,VAL_REDONTHEFLY) ;
 
  
  m1 = (b01 * a1 + b10 * a0) / (b01 + b10);
  v1 = (a1 - a0) * (a1 - a0) * b01 * b10 / ((b01 + b10) * (b01 + b10));
  u1 = (a1 * a1 * a1 * b01 + a0 * a0 * a0 * b10) / (b01 + b10);
  u1 = u1 - 3 * m1 * v1 - m1 * m1 * m1; 
  t1 = 1 / (b01 + b10);

  m2 = (d01 * g1 + d10 * g0) / (d01 + d10);
  v2 = (g1 - g0) * (g1 - g0) * d01 * d10 / ((d01 + d10) * (d01 + d10));
  u2 = (g1 * g1 * g1 * d01 + g0 * g0 * g0 * d10) / (d01 + d10);
  u2 = u2 - 3 * m2 * v2 - m2 * m2 *m2; 
  t2 = 1 / (d01 + d10);
 
} 


/* REWARD Functions */ 
double QL () {
	if (mark("PBUF") > QLEN) 
		return(1.0);
	else
		return(0);
}
double MLP () {
	if ((mark("PBUF") > BN - PLMD) && enabled("TARV2")) 
		return(1.0);
	else
		return(0);
}
double SLP () {
	if ((mark("PBUF") > BN - PLST) && enabled("TARV2"))
		return(1.0);
	else
		return(0);
}
double LLP () {
	if ((mark("PBUF") > BN - PLLG) && enabled("TARV2")) 
		return(1.0);
	else
		return(0);
}

/* GUARD Functions */  
int guardARV ()
{
  int n = 0;
  if (mark("POUT")>0) 
    n = 1;
  if (mark("PAR") + mark("PCS") + n < K)
    return(1);
  else
    return(0);
}

int guardARV2 () {
	if ((rateAL != 0.0) || mark("PAON"))
		return(1);
	else
		return(0);
}
int guardBST () {
	if (mark("PBUF") <= BN - PLST)
		return(1);
	else
		return(0);
}
int guardBMD () {
	if (mark("PBUF") <= BN - PLMD)
		return(1);
	else
		return(0);
}
int guardBLG () {
	if (mark("PBUF") <= BN - PLLG)
		return(1);
	else
		return(0);
}

/* RATE Functions */ 

double rateARV2 () {

double m,v,u,t,x,e;

int S = 0;

  if (mark("POUT")) 
        S=1; 

  S= S + mark("PAR") + mark("PCS");
  m = S * m1 + m2;
  v = S * v1+v2;
  u = S * u1 + u2;
  t = (S * v1*t1+v2 *t2) /v;
  x =  u / sqrt(v * v * v);
  e = (x * x + 2 - x * sqrt(4 + x * x)) / 2;
  rateAH = m + sqrt(v / e);
  rateAL = m - sqrt(v * e);
  if (mark("PAON")) 
		return(rateAH);
  else
		return(rateAL);
 
}

double t01 () {

double m,v,u,t,x,e;

int S = 0;

  if (mark("POUT")) 
        S=1; 

  S= S + mark("PAR") + mark("PCS");
  m = S * m1 + m2;
  v = S * v1+v2;
  u = S * u1 + u2;
  t = (S * v1 * t1+v2 *t2) /v;
  x =  u / sqrt(v * v * v);
  e = (x * x + 2 - x * sqrt(4 + x * x)) / 2;
  theta0 = 1 / (t * (1 + e));
  return(theta0);

}

double t10() {

double m,v,u,t,x,e;

  int S = 0;

  if (mark("POUT")) 
        S=1; 

  S= S + mark("PAR") + mark("PCS");
  m = S * m1 + m2;
  v = S * v1+v2;
  u = S * u1 + u2;
  t = (S * v1*t1+v2 *t2) /v;
  x =  u / sqrt(v * v * v);
  e = (x * x + 2 - x * sqrt(4 + x * x)) / 2;
  theta1 = e / (t * (1 + e));
  return(theta1);
}
 
void net() {

   /*  PLACE  */
  place("PAR") ;
  place("PCS") ;
  place("POUT") ;

  place("PARV") ;
  place("PST") ;
  place("PMD") ;
  place("PLG") ;
  place("PBUF") ;
  place("PEOUT") ;
  place("PAON") ;

  /*  TRANSITION  */
  rateval("TARV",lambda) ;
  guard("TARV", guardARV);
  rateval("TAR",mu) ;
  rateval("TCS",beta) ;
  imm("tOUT") ;
  priority("tOUT",20) ;
  probval("tOUT",1.) ;

  ratefun("TARV2",rateARV2) ;
  guard("TARV2",guardARV2) ;
  imm("tST") ;
  priority("tST",20) ;
  probval("tST",c1) ;
  imm("tMD") ;
  priority("tMD",20) ;
  probval("tMD",c2) ;
  imm("tLG") ;
  priority("tLG",20) ;
  probval("tLG",c3) ;
  imm("tBST") ;
  priority("tBST",40) ;
  probval("tBST",1.) ;
  guard("tBST",guardBST) ;
  imm("tBMD") ;
  priority("tBMD",40) ;
  probval("tBMD",1.) ;
  guard("tBMD",guardBMD) ;
  imm("tBLG") ;
  priority("tBLG",40) ;
  probval("tBLG",1.) ;
  guard("tBLG",guardBLG) ;
  imm("tLST") ;
  priority("tLST",20) ;
  probval("tLST",1.) ;
  imm("tLMD") ;
  priority("tLMD",20) ;
  probval("tLMD",1.) ;
  imm("tLLG") ;
  priority("tLLG",20) ;
  probval("tLLG",1.) ;
  imm("tEOUT") ;
  priority("tEOUT",20) ;
  probval("tEOUT",1.) ;
  rateval("TOUT",rateOUT) ;
  ratefun("TT01",t01) ;
  ratefun("TT10",t10) ;

  /*  ARC  */
  oarc("TARV","PAR") ;
  iarc("TAR","PAR") ;
  oarc("TAR","PCS") ;
  iarc("tOUT","PCS") ;
  moarc("tOUT","POUT", 3) ;
  iarc("TCS","POUT") ;
  harc("tOUT","POUT") ;

  oarc("TARV2","PARV") ;
  iarc("tST","PARV") ;
  iarc("tMD","PARV") ;
  iarc("tLG","PARV") ;
  oarc("tST","PST") ;
  oarc("tMD","PMD") ;
  oarc("tLG","PLG") ;
  iarc("tBST","PST") ;
  iarc("tLST","PST") ;
  iarc("tBMD","PMD") ;
  iarc("tLMD","PMD") ;
  iarc("tBLG","PLG") ;
  iarc("tLLG","PLG") ;
  moarc("tBST","PBUF",PLST) ;
  moarc("tBLG","PBUF",PLLG) ;
  moarc("tBMD","PBUF",PLMD) ;
  iarc("tEOUT","PBUF") ;
  moarc("tEOUT","PEOUT",3) ;
  iarc("TOUT","PEOUT") ;
  harc("tEOUT","PEOUT") ;
  oarc("TT01","PAON") ;
  iarc("TT10","PAON") ;
  harc("TT01","PAON") ;
} 

int assert() { 
  return(RES_NOERR);
}

void ac_init() { 

}

void ac_reach() { 

}


void ac_final() { 
  double llp, mlp, slp, pql;

  solve(INFINITY);
  llp = expected(LLP);
  mlp = expected(MLP);
  slp = expected(SLP);
  
  pr_value("Loss Prob. of Short Packets (S)", slp);
  pr_value("Loss Prob. of Medium Packets (M)", mlp);
  pr_value("Loss Prob. of Long Packets (L)", llp);
  pr_value("Loss Prob. of total Packets (T)", c1 * slp + c2 * mlp + c3 * llp);

  for (QLEN = 0; QLEN < BN; QLEN += BN / 20)
    {
      pql = expected(QL);
      fprintf(Outfile,"\nProb. for Queue Len (> %d) = %.12g\n", QLEN, pql);
    }

  QLEN = BN - 1;
  pql = expected(QL);
  fprintf(Outfile,"\nProb. for Queue Len (= %d) = %.12g\n", BN, pql);

  pr_std_average();
}
