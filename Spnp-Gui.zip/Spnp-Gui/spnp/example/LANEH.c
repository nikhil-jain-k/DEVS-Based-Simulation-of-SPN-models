#include <stdio.h>
#include "user.h"

/* global variables */ 

int CN, K;

double lambda, mu, beta;  

 
int guardARV();

  /* prototype reward functions */ 
double pCN () ; 
 

void options() {
  
  iopt(IOP_PR_RGRAPH,VAL_NO) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_NO) ;
  iopt(IOP_USENAME,VAL_NO) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_NO) ;
  iopt(IOP_PR_MC_ORDER,VAL_TOFROM) ;
  /*
  iopt(IOP_PR_RGRAPH,VAL_YES) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_NO) ;
  iopt(IOP_USENAME,VAL_NO) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_YES) ;
  iopt(IOP_PR_MC_ORDER,VAL_TOFROM) ;
  */
  /* NUMERICAL SOLUTION chosen */ 
  iopt(IOP_SENSITIVITY,VAL_NO) ;
  iopt(IOP_MC,VAL_CTMC) ;
  iopt(IOP_SSMETHOD,VAL_SSSOR) ;
  iopt(IOP_TSMETHOD,VAL_FOXUNIF) ;
  iopt(IOP_ITERATIONS,2000) ;
  fopt(FOP_PRECISION,1e-06) ;
  fopt(FOP_ABS_RET_M0,0.0) ;
  iopt(IOP_CUMULATIVE,VAL_YES) ;
  iopt(IOP_SSDETECT,VAL_NO) ;
  iopt(IOP_OK_ABSMARK,VAL_NO) ;
  iopt(IOP_OK_VANLOOP,VAL_NO) ;
  iopt(IOP_OK_TRANS_M0,VAL_YES) ;
  iopt(IOP_OK_VAN_M0,VAL_YES) ;
  iopt(IOP_ELIMINATION,VAL_REDONTHEFLY) ;
  /*
  lambda = finput("Arrive Rate");
  mu = finput("Resolution Rate");
  beta = finput("Connection Rate") * 3.0;
  */
  scanf("%d%lf%lf%lf", &K, &lambda, &mu, &beta);
} 

int guardARV()
{
  int n = 0;

  if (mark("POUT")) 
    n = 1;

  if (mark("PARV") + mark("PCS") + n < K)
    return(1);
  else
    return(0);
}

/* REWARD Functions */ 
double pCN () {
  int n = 0;
  
  if (mark("POUT")) 
    n = 1;
  
  if (mark("PARV") + mark("PCS") + n == CN) 
    return(1.0);
  else
    return(0);
}

void net() {
  /*  PLACE  */
  place("PARV") ;
  place("PCS") ;
  place("POUT") ;
  /*  TRANSITION  */
  rateval("TARV",lambda) ;
  guard("TARV", guardARV);
  rateval("TAR",mu) ;
  rateval("TCS",beta) ;
  imm("tOUT") ;
  //priority("tOUT",20) ;
  probval("tOUT",1.) ;
  /*  ARC  */
  oarc("TARV","PARV") ;
  iarc("TAR","PARV") ;
  oarc("TAR","PCS") ;
  iarc("tOUT","PCS") ;
  moarc("tOUT","POUT", 3) ;
  iarc("TCS","POUT") ;
  harc("tOUT","POUT") ;
} 

int assert() { 
  return(RES_NOERR);
}

void ac_init() { 

}

void ac_reach() { 

}

void ac_final() {
  double pcn;
  
  solve(INFINITY);
  for (CN = 0; CN <= K; CN++) 
    {
      pcn = expected(pCN);
      fprintf(Outfile,"\nProb. for Number of Clients (= %d) = %.12g\n", CN, pcn);
    }
  
  pr_std_average();			
}

