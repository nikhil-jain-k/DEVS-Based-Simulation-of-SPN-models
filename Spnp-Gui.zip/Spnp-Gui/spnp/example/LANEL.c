#include <stdio.h>
#include "user.h"

#define PLST 1 /* Short Packet Size */
#define PLMD 2 /* Medium Packet Size */
#define PLLG 16 /* Long Packet Size */
 
#define c1 0.6
#define c2 0.3
#define c3 0.1  

#define rateOUT 30

int N, BN; /* Buffer Size */
int QLEN;

double rateAH, rateAL;
double t01, t10;
 
  /* prototype reward functions */ 
  double BUFLEN50 () ; 
  double BUFLEN150 () ; 
  double BUFLEN250 () ; 
  double BUFLEN350 () ; 
  double BUFLEN100 () ; 
  double BUFLEN450 () ; 
  double BUF_MD () ; 
  double BUFLEN200 () ; 
  double BUFLEN300 () ; 
  double BUFLEN400 () ; 
  double BUF_ST () ; 
  double BUF_LG () ; 

  /* prototype guard functions */ 
  int guardARV () ; 
  int guardBST () ; 
  int guardBMD () ; 
  int guardBLG () ; 

  /* prototype rate functions */ 
  double rateARV () ; 
 
void mmpp2para(double a0, double a1, double b01, double b10,
	       double *m, double *v, double *u, double *t)
{
  *m = (b01 * a1 + b10 * a0) / (b01 + b10);
  *v = (a1 - a0) * (a1 - a0) * b01 * b10 / ((b01 + b10) * (b01 + b10));
  *u = (a1 * a1 * a1 * b01 + a0 * a0 * a0 * b10) / (b01 + b10);
  *t = 1 / (b01 + b10);
}

void para2mmpp(double *l1, double *l2, double *th01, double *th10,
	       double *m, double *v, double *u, double *t, int N)
{
  double x, e;

  *m = N * *(m + 1) + *(m + 2);
  *v = N * *(v + 1) + *(v + 2);
  *u = N * *(u + 1) + *(u + 2);
  *t = (N * *(v + 1) * *(t + 1) + *(v + 2) * *(t + 2)) / *v;

  x = (*u - 3 * *m * *v - *m * *m * *m) / sqrt(*v * *v * *v);
  if (x > 0)
    e = (x * x + 2 - x * sqrt(4 + x * x)) / 2;
  else
    e = (x * x + 2 + x * sqrt(4 + x * x)) / 2;
  
  *l1 = *m + sqrt(*v / e);
  *l2 = *m - sqrt(*v * e);
  *th01 = 1 / (*t * (1 + e));
  *th10 = e / (*t * (1 + e));
  /*
  printf("x = %f, e = %f \n", x, e);
  */
}

void options() {
  double g0, g1, d01, d10;
  double a0, a1, b01, b10;
  double m[3], v[3], u[3], t[3];
  int i;
  
  iopt(IOP_PR_RGRAPH,VAL_NO) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_NO) ;
  iopt(IOP_USENAME,VAL_NO) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_NO) ;
  iopt(IOP_PR_MC_ORDER,VAL_FROMTO) ;
  /*
  iopt(IOP_PR_RGRAPH,VAL_YES) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_YES) ;
  iopt(IOP_USENAME,VAL_NO) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_YES) ;
  iopt(IOP_PR_MC_ORDER,VAL_FROMTO) ;
  */
  /* NUMERICAL SOLUTION chosen */ 
  iopt(IOP_SENSITIVITY,VAL_NO) ;
  iopt(IOP_MC,VAL_CTMC) ;
  iopt(IOP_SSMETHOD,VAL_SSSOR) ;
  iopt(IOP_TSMETHOD,VAL_FOXUNIF) ;
  iopt(IOP_ITERATIONS,2000) ;
  fopt(FOP_PRECISION,1e-06) ;
  fopt(FOP_ABS_RET_M0,0.0) ;
  iopt(IOP_CUMULATIVE,VAL_YES) ;
  iopt(IOP_SSDETECT,VAL_YES) ;
  iopt(IOP_OK_ABSMARK,VAL_NO) ;
  iopt(IOP_OK_VANLOOP,VAL_NO) ;
  iopt(IOP_OK_TRANS_M0,VAL_YES) ;
  iopt(IOP_OK_VAN_M0,VAL_YES) ;
  iopt(IOP_ELIMINATION,VAL_REDONTHEFLY) ;
 
  /* 
  BN = input("Buffer Size");
  rateAH = finput("Hige Rate");
  rateAL = finput("Low Rate");
  t01 = finput("t01");
  t10 = finput("t10");
  */
  scanf("%d%d", &N, &BN);
  scanf("%lf%lf%lf%lf", &g0, &g1, &d01, &d10);
  scanf("%lf%lf%lf%lf", &a0, &a1, &b01, &b10);

  mmpp2para(g0, g1, d01, d10, m+1, v+1, u+1, t+1);
  mmpp2para(a0, a1, b01, b10, m+2, v+2, u+2, t+2);
  para2mmpp(&rateAH, &rateAL, &t01, &t10, m, v, u, t, N);
  
  /*
  printf("g0 = %g, g1 = %g, d01 = %g, d10 = %g \n", g0, g1, d01, d10);
  printf("a0 = %g, a1 = %g, b01 = %g, b10 = %g \n", a0, a1, b01, b10);
  for (i = 0; i < 3; i++) 
    printf("m%d = %g, v%d = %g, u%d = %g, t%d = %g \n", 
	   i, m[i], i, v[i], i, u[i], i, t[i]);
  printf("rateAH = %g, rateAL = %g, t01 = %g, t10 = %g \n",
	 rateAH, rateAL, t01, t10);
	 */

  if (rateAL < 0)
    {
      if (fabs(rateAL) < FOptionValue(FOP_PRECISION))
	rateAL = 0;
      else 
	{
	  printf ("rateAL = %g \n", rateAL);
	  exit(1);
	}
    }   
} 


/* REWARD Functions */ 
double QL () {
	if (mark("PBUF") > QLEN) 
		return(1.0);
	else
		return(0);
}
double MLP () {
	if ((mark("PBUF") > BN - PLMD) && enabled("TARV")) 
		return(1.0);
	else
		return(0);
}
double SLP () {
	if ((mark("PBUF") > BN - PLST) && enabled("TARV"))
		return(1.0);
	else
		return(0);
}
double LLP () {
	if ((mark("PBUF") > BN - PLLG) && enabled("TARV")) 
		return(1.0);
	else
		return(0);
}


/* GUARD Functions */ 
int guardARV () {
	if ((rateAL != 0.0) || mark("PAON"))
		return(1);
	else
		return(0);
}
int guardBST () {
	if (mark("PBUF") <= BN - PLST)
		return(1);
	else
		return(0);
}
int guardBMD () {
	if (mark("PBUF") <= BN - PLMD)
		return(1);
	else
		return(0);
}
int guardBLG () {
	if (mark("PBUF") <= BN - PLLG)
		return(1);
	else
		return(0);
}

/* RATE Functions */ 
double rateARV () {
	if (mark("PAON")) 
		return(rateAH);
	else
		return(rateAL);
}

void net() {
  /*  PLACE  */
  place("PARV") ;
  place("PST") ;
  place("PMD") ;
  place("PLG") ;
  place("PBUF") ;
  place("PEOUT") ;
  place("PAON") ;
  /*  TRANSITION  */
  ratefun("TARV",rateARV) ;
  guard("TARV",guardARV) ;
  imm("tST") ;
  priority("tST",20) ;
  probval("tST",c1) ;
  imm("tMD") ;
  priority("tMD",20) ;
  probval("tMD",c2) ;
  imm("tLG") ;
  priority("tLG",20) ;
  probval("tLG",c3) ;
  imm("tBST") ;
  priority("tBST",40) ;
  probval("tBST",1.) ;
  guard("tBST",guardBST) ;
  imm("tBMD") ;
  priority("tBMD",40) ;
  probval("tBMD",1.) ;
  guard("tBMD",guardBMD) ;
  imm("tBLG") ;
  priority("tBLG",40) ;
  probval("tBLG",1.) ;
  guard("tBLG",guardBLG) ;
  imm("tLST") ;
  priority("tLST",20) ;
  probval("tLST",1.) ;
  imm("tLMD") ;
  priority("tLMD",20) ;
  probval("tLMD",1.) ;
  imm("tLLG") ;
  priority("tLLG",20) ;
  probval("tLLG",1.) ;
  imm("tEOUT") ;
  priority("tEOUT",20) ;
  probval("tEOUT",1.) ;
  rateval("TOUT",rateOUT) ;
  rateval("TT01",t01) ;
  rateval("TT10",t10) ;
  /*  ARC  */
  oarc("TARV","PARV") ;
  iarc("tST","PARV") ;
  iarc("tMD","PARV") ;
  iarc("tLG","PARV") ;
  oarc("tST","PST") ;
  oarc("tMD","PMD") ;
  oarc("tLG","PLG") ;
  iarc("tBST","PST") ;
  iarc("tLST","PST") ;
  iarc("tBMD","PMD") ;
  iarc("tLMD","PMD") ;
  iarc("tBLG","PLG") ;
  iarc("tLLG","PLG") ;
  moarc("tBST","PBUF",PLST) ;
  moarc("tBLG","PBUF",PLLG) ;
  /*  mharc("tBST","PBUF", N - PLST + 1) ;
  mharc("tBMD","PBUF", N - PLMD + 1) ;
  mharc("tBLG","PBUF", N - PLLG + 1) ;*/
  iarc("tEOUT","PBUF") ;
  moarc("tEOUT","PEOUT",3) ;
  iarc("TOUT","PEOUT") ;
  harc("tEOUT","PEOUT") ;
  moarc("tBMD","PBUF",PLMD) ;
  oarc("TT01","PAON") ;
  iarc("TT10","PAON") ;
  harc("TT01","PAON") ;
} 

int assert() { 
  return(RES_NOERR);
}

void ac_init() { 

}

void ac_reach() { 

}

void ac_final() { 
  double llp, mlp, slp, pql;

  solve(INFINITY);
  llp = expected(LLP);
  mlp = expected(MLP);
  slp = expected(SLP);
  
  pr_value("Loss Prob. of Short Packets (S)", slp);
  pr_value("Loss Prob. of Medium Packets (M)", mlp);
  pr_value("Loss Prob. of Long Packets (L)", llp);
  pr_value("Loss Prob. of total Packets (T)", c1 * slp + c2 * mlp + c3 * llp);

  for (QLEN = 0; QLEN < BN; QLEN += BN / 20)
    {
      pql = expected(QL);
      fprintf(Outfile,"\nProb. for Queue Len (> %d) = %.12g\n", QLEN, pql);
    }

  QLEN = BN - 1;
  pql = expected(QL);
  fprintf(Outfile,"\nProb. for Queue Len (= %d) = %.12g\n", BN, pql);

  pr_std_average();
}







