	/* 
	*	Created from the <CentralServer.c> model, this model file
	*	exercises the SYMBOLIC SENSITIVITY ANALYSIS features of 
	*	SPNP v5 by Robert Jones, NASA Langley Research Center,
	*	Hampton, VA.  email: r.l.jones.iii@larc.nasa.gov
	*
	*	created Dec 12, 1996 by Rob Jones
	*/

	# include "user.h"

	double pgamma = 1/6000.0;
	double delta = 1/10.0 * 3600.0;
	double  beta = 1/5.0 * 60.0;
	double   tau = 1.0;
	double alpha = 1/20.0 * 3600.0;
	double     c = 0.9;
	double lambda = 1 * 60;
	double  mu = 2 * 60;
	int      k = 10;
	int      n = 3;
	int quorum = 1;
	
	void options() {
		iopt(IOP_SSDETECT,VAL_YES);
		iopt(IOP_SSMETHOD,VAL_SSSOR);
		iopt(IOP_TSMETHOD,VAL_FOXUNIF);
		iopt(IOP_SENSITIVITY,VAL_NO);
		iopt(IOP_CUMULATIVE,VAL_YES);
		iopt(IOP_PR_MARK_ORDER,VAL_CANONIC);
		iopt(IOP_PR_MC_ORDER,VAL_TOFROM);
		iopt(IOP_PR_MC,VAL_YES);
		iopt(IOP_PR_DERMC,VAL_NO);
		iopt(IOP_PR_PROB,VAL_YES);
		iopt(IOP_PR_DOT,VAL_NO);
		iopt(IOP_MC,VAL_CTMC);
		iopt(IOP_PR_RSET,VAL_YES);
		iopt(IOP_USENAME,VAL_YES);
		iopt(IOP_PR_RGRAPH,VAL_YES);
		iopt(IOP_PR_FULL_MARK,VAL_YES);
		iopt(IOP_ITERATIONS,100000);
		fopt(FOP_ABS_RET_M0,0.0);
		fopt(FOP_PRECISION,1e-9);

		}
		
	int g_trupdn(){
		return mark("procup") > quorum;
	}
	
	int g_trupdn1(){
		return mark("procup") <= quorum;
	}
	
	int g_trdnup(){
		return mark("sysup") == 1 || mark("sysdn") == 1;
	}
	
	int g_sysup(){
		return mark("sysup") == 1;
	}
	
	int g_trsys(){
		return mark("procup") >= quorum;
	}

	void net() {
		parm("alpha");
		parm("gamma");
		parm("beta");
		parm("delta");
		parm("tau");
		parm("mu");
		parm("lambda");
		
		place("sysup");
		init("sysup", 1);
		place("sysdn");
		place("procup");
		init("procup", n);
		place("procdn");
		place("proctmp");
		place("prrb");
		place("prrc");
		place("bufree");
		init("bufree", k);
		place("bufull");
		
		rateval("trsys", 1.0);
		useparm("trsys", "alpha");
		ratedep("trupdn", 1.0,"procup");
		useparm("trupdn", "gamma");
		rateval("trrb", 1.0);
		useparm("trrb", "beta");
		rateval("trrc", 1.0);
		useparm("trrc", "delta");
		rateval("trupdn1", 1.0);
		useparm("trupdn1", "gamma");
		rateval("trdnup", 1.0);
		useparm("trdnup", "tau");
		rateval("trdep", 1.0);
		useparm("trdep", "mu");
		rateval("trarr", 1.0);
		useparm("trarr", "lambda");
		imm("truc");
		imm("trc");
		
		probval("truc", 1-c);
		probval("trc", c);
		
		guard("trupdn", g_trupdn);
		guard("trupdn1", g_trupdn1);
		guard("trdnup", g_trdnup);
		guard("trarr", g_sysup);
		guard("trdep", g_sysup);
		guard("trsys", g_trsys);
		
		iarc("trarr", "bufree");
		oarc("trarr", "bufull");
		iarc("trdep", "bufull");
		oarc("trdep", "bufree");

		iarc("trsys", "sysdn");
		oarc("trsys", "sysup");
		iarc("trupdn1", "procup");
		iarc("trupdn1", "sysup");
		oarc("trupdn1", "procdn");
		oarc("trupdn1", "sysdn");
		iarc("trdnup", "procdn");
		oarc("trdnup", "procup");
		iarc("trupdn", "sysup");
		iarc("trupdn", "procup");
		oarc("trupdn", "proctmp");
		iarc("truc", "proctmp");
		oarc("truc", "prrb");
		iarc("trc", "proctmp");
		oarc("trc", "prrc");
		iarc("trrb", "prrb");
		oarc("trrb", "sysup");
		oarc("trrb", "procdn");
		iarc("trrc", "prrc");
		oarc("trrc", "procdn");
		oarc("trrc", "sysup");
		
		
	}

	int assert() { return(RES_NOERR); }

	void ac_init() 
	{ 
		bind("alpha", alpha);
		bind("beta", beta);
		bind("gamma", pgamma);
		bind("delta", delta);
		bind("lambda", lambda);
		bind("tau", tau);
		bind("mu", mu);
		
		pr_net_info(); 
	}

	void ac_reach() 
	{ 
		pr_parms(); 
		pr_rg_info(); 
	}

	double reward0() { return enabled("trarr"); }
	double reward1() { return mark("use1"); }
	double reward2() { return mark("use2"); }

	double reward() 
	{ 
	}
	double notreward() 
	{ 
	}

	void pr_measures() 
	{
		pr_expected("tokens in place think", reward0);
		pr_expected("tokens in place use1",  reward1);
		pr_expected("tokens in place use2",  reward2);
	}

	void ac_final() 
	{ 
		/* steady-state analysis */
	        solve(INFINITY);

		//pr_mc_info();

	        //pr_std_average(); 
		//pr_measures(); 
		pr_expected("Rejection probability", reward0);

	}




