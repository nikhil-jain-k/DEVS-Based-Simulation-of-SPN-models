#include "user.h"
#include <string.h>

void options() {

  iopt(IOP_SSMETHOD,VAL_GASEI);
  iopt(IOP_PR_FULL_MARK, VAL_YES);
  iopt(IOP_PR_MARK_ORDER, VAL_CANONIC);
  iopt(IOP_PR_MC_ORDER, VAL_TOFROM);
  iopt(IOP_PR_MC, VAL_YES);
  iopt(IOP_MC, VAL_CTMC);
  iopt(IOP_PR_PROB, VAL_YES);
  iopt(IOP_PR_RSET, VAL_YES);
  iopt(IOP_PR_RGRAPH, VAL_YES);
  iopt(IOP_ITERATIONS, 20000);
  iopt(IOP_CUMULATIVE, VAL_NO);
  fopt(FOP_ABS_RET_M0, 0.0);
  fopt(FOP_PRECISION, 0.0000000001);
}

void net() {

  int k = 20;
  int L = 20;
  double lm = 1.00;
  double mu = 1.00;

  /* places and trans */

  place("pArr");

  place("pERIn");
  place("pEROut"); 
  imm("tERIn"); 
  imm("tEROut");

  priority("tEROut", 2); 
  priority("tERIn", 2);

  /* rate & prob */

  rateval("tArr", lm);
  rateval("tER",mu*(double)k);
  probval("tERIn", 1.00);
  probval("tEROut", 1.00);

  /* arcs */

  oarc("tArr", "pArr");
  mharc("tArr", "pArr", L);
  iarc("tERIn", "pArr");
  moarc("tERIn", "pERIn", k);
  harc("tERIn", "pERIn");
  harc("tERIn", "pEROut");
  iarc("tER", "pERIn");
  oarc("tER", "pEROut");
  miarc("tEROut", "pEROut", k);

}

int assert() {

  return(RES_NOERR);
}

void ac_init() {
  pr_net_info();
}

void ac_reach() {
  pr_rg_info();
}

void ac_final() {

  solve(INFINITY);
  pr_mc_info();
  pr_std_average();

}
