# include	"user.h"

/*
This example corresponds to the following piece of software:

A:  statements;
    PARBEGIN 
    B1:  statements;    B2:  IF cond THEN
                             C:  statements;
                             ELSE
                                 DO
                                 D:  statements
                                 WHILE cond;
                             IFEND
    PAREND
*/

options() {
    /* Transient analysis */
	iopt(IOP_PR_RSET, VAL_YES);
	iopt(IOP_PR_PROB, VAL_YES);
	iopt(IOP_PR_MC,   VAL_YES);
	iopt(IOP_PR_RGRAPH, VAL_YES);
	iopt(IOP_PR_DOT, VAL_YES);
	iopt(IOP_TSMETHOD,VAL_TSUNIF);
	iopt(IOP_SIMULATION, VAL_NO);
	iopt(IOP_SIM_RUNS, 200);
	iopt(IOP_SIM_RUNMETHOD, VAL_REPL);
	iopt(IOP_SIM_CUMULATIVE, VAL_YES);
	iopt(IOP_SIM_STD_REPORT, VAL_YES);
	fopt(FOP_SIM_LENGTH, 150);
	fopt(FOP_SIM_ERROR, 0.01);
	fopt(FOP_SIM_CONFIDENCE, .95);
}

/* rates and probabilities are defined as functions */
double			rate0() { return(1.0);}
double			rate1() { return(0.3);}
double			prob2() { return(0.4);}
double			prob3() { return(0.6);}
double			rate4() { return(0.2);}
double			rate5() { return(7.0);}
double			prob6() { return(0.05);}
double			prob7() { return(0.95);}
double			prob8() { return(1.0);}

net() {
	place("p0");
	init("p0",1);
	place("p1");
	place("p2");
	place("p3");
	place("p4");
	place("p5");
	place("p6");
	place("p7");
	place("p8");

    /* priorities associated with transitions */
	imm("t2");	priority("t2",1);
	imm("t3");	priority("t3",1);
	imm("t6");	priority("t6",1);
	imm("t7");	priority("t7",1);
	imm("t8");	priority("t8",1);

	/* rate and probability functions */
	ratefun("A", rate0);
	ratefun("B1",rate1);
	//probval("t2", 0.4);
	//probval("t3", 0.6);
	probfun("t2",prob2);
	probfun("t3",prob3);
	ratefun("C", rate4);
	ratefun("D", rate5);
	probval("t6", 0.05);
	probval("t7", 0.95);
	probval("t8", 1.0);
	//probfun("t6",prob6);
	//probfun("t7",prob7);
	//probfun("t8",prob8);

	iarc("A","p0");		oarc("A","p1");		oarc("A","p3");
	iarc("B1","p1");	oarc("B1","p2");
	iarc("t2","p3");	oarc("t2","p4");
	iarc("t3","p3");	oarc("t3","p5");
	iarc("C","p4");		oarc("C","p6");
	iarc("D","p5");		oarc("D","p7");
	iarc("t6","p7");	oarc("t6","p6");
	iarc("t7","p7");	oarc("t7","p5");
	iarc("t8","p2"); 	iarc("t8","p6");	oarc("t8","p8");
}

assert() { }

ac_init() { fprintf(stderr,"\nSoftware modeling example\n\n"); }


ac_reach() {
  pr_rg_info();
 }

double rfunc() { return(mark("p8")); }

ac_final() {
   int i;

	/* Transient analysis with multiple time points */
	/* reward function */
solve(150.0);
pr_std_average();
pr_expected("probability of completion", rfunc);
/*   for (  i = 1; i < 10; i++ )
   {
      solve( (double) i );
      pr_expected("probability of completion", rfunc);
   }

   for (  i = 10; i <= 20; i += 2 )
   {
      solve( (double) i );
      pr_expected("probability of completion", rfunc);
   }

   for (  i = 20; i <= 50; i += 5 )
   {
      solve( (double) i );
      pr_expected("probability of completion", rfunc);
   }
*/
}

