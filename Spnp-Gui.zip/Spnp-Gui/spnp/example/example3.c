/* This example models a Multi-server FCFS queue with finite buffer */
/* An M/M/m/b queue */

# include	"user.h"

    /* Global variables */
	double lambda;
	double mu;
	int b;
	int m;
	int method;

void options() {

	method = input("Input 0/1 for Steady-state/Transient analysis");
	if ( method == 0 )
		iopt(IOP_SSMETHOD,VAL_SSSOR);
	else if ( method == 1 )
		iopt(IOP_TSMETHOD,VAL_TSUNIF);
	else
	{
		fprintf(stderr,"ERROR: Illegal method specification\n");
		exit(1);
	}

	iopt(IOP_PR_FULL_MARK,VAL_YES);
	iopt(IOP_PR_MARK_ORDER,VAL_CANONIC);
	iopt(IOP_PR_MC_ORDER,VAL_TOFROM);
	iopt(IOP_PR_MC,VAL_YES);
	iopt(IOP_MC,VAL_CTMC);
	iopt(IOP_PR_PROB,VAL_YES);
	iopt(IOP_PR_RSET,VAL_YES);
	iopt(IOP_PR_RGRAPH,VAL_YES);
	iopt(IOP_ITERATIONS,20000);
	iopt(IOP_CUMULATIVE,VAL_NO);
	fopt(FOP_ABS_RET_M0,0.0);
	fopt(FOP_PRECISION,0.00000001);
	lambda = finput("Enter lambda");
	mu = finput("Enter mu");
	b = input("Enter the number of buffers");
	m = input("Enter the number of servers");

}

/* Marking dependent firing rate */
double rate_serv() { if ( mark("buf") < m ) return( mark("buf")*mu);
						else return(m*mu); }

void net() {

	place("buf");
        

	rateval("trin",lambda);
	ratefun("trserv",rate_serv);

	oarc("trin","buf"); mharc("trin","buf",b);
	iarc("trserv","buf");
}

int assert() {
	/* Make sure that the number of tokens in buf does not exceed the
	   buffer size */
	if ( mark("buf") > b )
		return(RES_ERROR);
	else
		return(RES_NOERR);
}

void ac_init() {
	fprintf(stderr,"A model of the M/M/m/b Queue\n");
	pr_net_info();
}

void ac_reach() {
	pr_rg_info();
}

double qlength() { return(mark("buf")); }
double util() { return(enabled("trserv")); }
double tput() { return(rate("trserv")); }
double probrej() { if ( mark("buf") == b ) return(1.0);
						else return(0.0); }

double probempty() { if ( mark("buf") == 0 ) return(1.0);
						else return(0.0); }
double probhalffull() { if ( mark("buf") == b/2 ) return(1.0);
						else return(0.0); }
void ac_final() {

	double time_pt;

	/* measures related to the queue */
	if ( method == 0 )
	{
	  solve(INFINITY);
	  pr_expected("Average Queue Length", qlength);
	  pr_expected("Average Throughput", tput);
	  pr_expected("Utilization", util);
	  
	  /* this case corresponds to buf having b tokens */
	  pr_expected("Probability of rejection",probrej);
	  
	  /* this case corresponds to buf having zero tokens */
	  pr_expected("Probability that queue is empty",probempty);
	  
	  /* this case corresponds to buf having b/2 tokens */
	  pr_expected("Probability that queue is half full",probhalffull);
	}
	else
	{
		for ( time_pt = 0.1; time_pt < 1.0; time_pt += 0.1)
		{
			solve(time_pt);
			pr_expected("Average Queue Length", qlength);
			pr_expected("Average Throughput", tput);
			pr_expected("Utilization", util);


			/* this case corresponds to buf having b tokens */
			pr_expected("Probability of rejection",probrej);

			/* this case corresponds to buf having zero tokens */
			pr_expected("Probability that queue is empty",probempty);

			/* this case corresponds to buf having b/2 tokens */
			pr_expected("Probability that queue is half full",probhalffull);
		}
		for ( time_pt = 1.0; time_pt < 10.0; time_pt += 1.0)
		{
			solve(time_pt);
			pr_expected("Average Queue Length", qlength);
			pr_expected("Average Throughput", tput);
			pr_expected("Utilization", util);


			/* this case corresponds to buf having b tokens */
			pr_expected("Probability of rejection",probrej);

			/* this case corresponds to buf having zero tokens */
			pr_expected("Probability that queue is empty",probempty);

			/* this case corresponds to buf having b/2 tokens */
			pr_expected("Probability that queue is half full",probhalffull);
		}
	}
}
