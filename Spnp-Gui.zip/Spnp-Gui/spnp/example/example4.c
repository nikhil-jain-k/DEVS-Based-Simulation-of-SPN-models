#include "user.h"
#include <math.h>
#define min(x,y) ((x < y) ? x : y )
#define max(x,y) ((x > y) ? x : y )

/*  
    This is a model of the C.MMP multiprocessor system adopted from Blake,
    Reibman and Trivedi "Sensitivity Analysis of Reliability and
    Performability Measures for Multiprocessor Systems", ACM SIGMETRICS
1988.
*/

int k;

extern int abs();
extern double pow();

void options() 
{
  iopt(IOP_SSMETHOD, VAL_SSSOR);
  iopt(IOP_TSMETHOD,VAL_TSUNIF);
  iopt(IOP_OK_TRANS_M0, VAL_YES);
  iopt(IOP_MC,VAL_CTMC);
  iopt(IOP_ITERATIONS,20000);
  fopt(FOP_ABS_RET_M0,0.0);
  fopt(FOP_PRECISION,0.00000001);
  
  k = input("Input minimum number of proc/mem needed (1<=k<=16)");
  if ( k < 1 )
    {
      fprintf(stderr,"ERROR: atleast one processor is needed (k >= 1)");
      exit(1);
    }
  if ( k > 16 )
    { 
      fprintf(stderr,"ERROR: only 16 processors are available (k<=16)");
      exit(1);
    } 
}

int entrflr() 
{
  if ( mark("procup") == 0 && mark("memup") == 0 && mark("swup") == 0 )
    return(0);
  if ( mark("procup") < k || mark("memup") < k || mark("swup") == 0 )
    return(1);
  else
    return(0); 
}

int apfl() 
{ 
  return( mark("procup"));
}

int amfl() 
{ 
  return(mark("memup"));
}

int asfl() 
{ 
  return(mark("swup"));
}

void net() {
  place("procup");
  init("procup", 16);
  place("procdn");
  place("memup");
  init("memup", 16);
  place("memdn");
  place("swup");
  init("swup",1);
  place("swdn");
  
  /* timed transition */
  ratedep("trpr", 0.0000689, "procup");
  ratedep("trmm", 0.000224, "memup");
  rateval("trsw", 0.0002202);
  
  /* immediate transition */
  imm("trflr"); priority("trflr", 100); guard("trflr", entrflr);
  probval("trflr", 1.0); 

  iarc("trpr", "procup"); oarc("trpr", "procdn");
  iarc("trmm", "memup"); oarc("trmm", "memdn");
  iarc("trsw", "swup"); oarc("trsw", "swdn");
  viarc("trflr", "procup", apfl); voarc("trflr", "procdn", apfl);
  viarc("trflr", "memup", amfl); voarc("trflr", "memdn", amfl);
  viarc("trflr", "swup", asfl); voarc("trflr", "swdn", asfl);

}

int assert() 
{
  return(RES_NOERR);
}

void ac_init() 
{
}

void ac_reach() 
{
  pr_rg_info();
}

double reliab() 
{
  if ( mark("procup") >= k && mark("memup") >= k && mark("swup") == 1 )
    return(1.0);
  else
    return(0.0); 
}

double reward_rate() 
{
  double m, l, temp;
  
  if ( mark("procup") >= k && mark("memup") >= k && mark("swup") == 1 )
    {
      l = min((double)mark("procup"), (double)mark("memup"));
      m = max((double)mark("procup"), (double)mark("memup"));
      temp = pow( (1.0 - (1.0 / m)) , l );
      return( m * (1.0 - temp) );
    }
  else
    return(0); 
}

void ac_final() 
{
  double time_pt;
  
  for ( time_pt = 500.0; time_pt < 5000.0; time_pt += 500.0 )
    {
      solve( time_pt );
      pr_expected("Reliability", reliab);
      pr_expected("Expected Reward", reward_rate);
      pr_cum_expected("Expected Accumulated Reward", reward_rate);
    }
}
