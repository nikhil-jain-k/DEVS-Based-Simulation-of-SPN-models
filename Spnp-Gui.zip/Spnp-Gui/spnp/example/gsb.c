
#include <stdio.h>
#include "user.h"

/* global variables */ 

/* all the rates are in the format 1.0/MTTF or 1.0/MTTR (unit: 1/Hour) */

/* global variables for other parts of the system */

/* number of power supply+fan modules */
int numPsf=3;
int numPsfUpMin=2;	/* minimum number to make system up */

/* number of NSPs on bus A and B */
int numNspA=4;
int numNspB=4;
int numNsp=8;
int numNspFcMin=4;	/* minimum number to make system full capacity */
int numNspUpMin=1;

/* number of DSPs on bus A and B */
int numDspA=2;
int numDspB=2;
int numDsp=4;
int numDspFcMin=2;	/* minimum number to make system full capacity */
int numDspUpMin=1;

/* failure rate of HSP */
double frHsp;

/* failure rate of backplane */
double frBp=1.0/6000000.0;

/* failure rate of power supply+fan */
double frPsf=1.0/80000.0;

/* failure rate of bus */
double frBus=1.0/300000.0; 

/* failure rate of NSP */
double frNsp=1.0/100000.0;  /* change later */

/* failure rate of DSP */
double frDsp=1.0/100000.0;  /* change later */

/* repair rate of backplane */
double rrBp=1.0/6.0;

/* repair rate of Ps+Fn, Bus, NSP, DSP  */ 
/*   in lost redudency/partial outage/total outage */ 
double rrLr=1.0/12.0;
double rrPo=1.0/8.0;
double rrTo=1.0/4.0;

double rrHsp,rrNsp,rrDsp;

/* global variables for computing capacity */

double dnNsp, dnDsp, upNsp, upDsp;
double capHsp, capBp, capPsf, capBus; 
double capNsp, capDsp, cap;	/* capacity */



/* prototype reward functions */ 
double uodpm();
double tpodpm();
double ofm();
double tsodpm();
double tsodpmHsp();
double tsodpmBp();
double tsodpmPsf();
double tsodpmBus();
double tsodpmNsp();
double tsodpmDsp();
void calCap();	/* calculate capacity */
void calVar();
int condTo();
int condTso();


/* prototype guard functions */ 

/* prototype rate functions */ 
double rrfPsf();
double rrfBus();

/* prototype cardinality functions */ 



void options() {
  iopt(IOP_PR_RGRAPH,VAL_NO) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_NO) ;
  iopt(IOP_USENAME,VAL_NO) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_NO) ;
  iopt(IOP_PR_MC_ORDER,VAL_FROMTO) ;
  /* NUMERICAL SOLUTION chosen */ 
  iopt(IOP_SENSITIVITY,VAL_NO) ;
  iopt(IOP_MC,VAL_CTMC) ;
  iopt(IOP_SSMETHOD,VAL_SSSOR) ;
  iopt(IOP_TSMETHOD,VAL_FOXUNIF) ;
  iopt(IOP_ITERATIONS,2000) ;
  fopt(FOP_PRECISION,0.000001) ;
  fopt(FOP_ABS_RET_M0,0.0) ;
  iopt(IOP_CUMULATIVE,VAL_NO) ;
  iopt(IOP_SSDETECT,VAL_YES) ;
  iopt(IOP_OK_ABSMARK,VAL_NO) ;
  iopt(IOP_OK_VANLOOP,VAL_NO) ;
  iopt(IOP_OK_TRANS_M0,VAL_YES) ;
  iopt(IOP_OK_VAN_M0,VAL_YES) ;
  iopt(IOP_ELIMINATION,VAL_REDONTHEFLY) ;

  /* some computation */
  calVar();

} 

void calVar() {
  double eq;
  FILE *pp;
  char command[120]="run gsbhsp";
  char cmdvsc[120];
  system(command);
  if ((pp=popen("grep MTTFeq gsbhsp.out | awk '{print $4}'","r"))==NULL) {
    perror("popen");
    exit(1);
  }
  fscanf(pp,"%14lf",&eq);
  printf("%.12f\n",eq);
  fclose(pp);
  frHsp = 1/eq;
  if ((pp=popen("grep MTTReq gsbhsp.out | awk '{print $4}'","r"))==NULL) {
    perror("popen");
    exit(1);
  }
  fscanf(pp,"%14lf",&eq);
  printf("%.12f\n",eq);
  fclose(pp);
  rrHsp = 1/eq;

  strcpy(cmdvsc,"run gsbvsc1");
  system(cmdvsc);
  if ((pp=popen("grep MTTFeq gsbvsc1.out | awk '{print $4}'","r"))==NULL) {
    perror("popen");
    exit(1);
  }
  fscanf(pp,"%14lf",&eq);
  printf("%.12f\n",eq);
  fclose(pp);
  frNsp = 1/eq;
  frDsp = 1/eq;
  if ((pp=popen("grep MTTReq gsbvsc1.out | awk '{print $4}'","r"))==NULL) {
    perror("popen");
    exit(1);
  }
  fscanf(pp,"%14lf",&eq);
  printf("%.12f\n",eq);
  fclose(pp);
  rrNsp = 1/eq;
  rrDsp = 1/eq;
}


/* REWARD Functions */ 


/* Unweighted Outage Downtime Performance Measurement */

double uodpm() {
  double dt;
  calCap();
  if ( cap<0.99999 )  { dt=1; }
  else { dt=0; }
  dt *= 8766*60;
  return dt;
}

int condUo() {
  calCap();
  if ( cap<0.99999 )  { return 1; }
  else { return 0; }
}

double timesUo[2];

/* Partial Outage Downtime Performance Measurement */

double tpodpm() {
  double dt;
  calCap();
  dt = 1-cap;
  dt *= 8766*60;
  return dt;
}

double tpodpmNsp() {
  double dt;
  calCap();
  dt = 1-capNsp;
  dt *= 8766*60;
  return dt;
}

double tpodpmDsp() {
  double dt;
  calCap();
  dt = 1-capDsp;
  dt *= 8766*60;
  return dt;
}

double tpodpmBus() {
  double dt;
  calCap();
  dt = 1-capBus;
  dt *= 8766*60;
  return dt;
}

/* Outage Frequency Measurement */

double ofm() {}

/* Total System Outage DPM */

double tsodpm() {
  double dt;
  calCap();
  if ( cap<0.00001 )  { dt=1; }
  else { dt=0; }
  dt *= 8766*60;
  return dt;
}

int condTso() {
  calCap();
  if ( cap<0.00001 )  { return 1; }
  else { return 0; }
}

double timesTso[2];

/* total system outage caused by HSP */

double tsodpmHsp() {
  double dt;
  calCap();
  if ( capHsp<0.00001 )  { dt=1; }
  else { dt=0; }
  dt *= 8766*60;
  return dt;
}
 
double tsodpmBp() {
  double dt;
  calCap();
  if ( capBp<0.00001 ) { dt=1; }
  else { dt=0; }
  dt *= 8766*60;
  return dt;
}

double tsodpmPsf() {
  double dt;
  calCap();
  if ( capPsf<0.00001 ) { dt=1; }
  else { dt=0; }
  dt *= 8766*60;
  return dt;
}

double tsodpmBus() {
  double dt;
  calCap();
  if ( capBus<0.00001 ) { dt=1; }
  else { dt=0; }
  dt *= 8766*60;
  return dt;
}

double tsodpmNsp() {
  double dt;
  calCap();
  if ( capNsp<0.00001 )  { dt=1; }
  else { dt=0; }
  dt *= 8766*60;
  return dt;
}

double tsodpmDsp() {
  double dt;
  calCap();
  if ( capDsp<0.00001 )  { dt=1; }
  else { dt=0; }
  dt *= 8766*60;
  return dt;
}

void calCap() {
  cap=1;
  if ( mark("hspUp")==0 )  { capHsp=0; cap=0; }
  else { capHsp=1; }
  if ( mark("bpUp")==0 )  { capBp=0; cap=0; }
  else { capBp=1; }
  if ( mark("psfUp")<numPsfUpMin ) { capPsf=0; cap=0; }
  else { capPsf=1; }
//if ( mark("busAUp")==0 && mark("busBUp")==0 ) { capBus=0; cap=0; }
//else { capBus=1; }
  capBus = (mark("busAUp") + mark("busBUp"))/2.0;
  if (capBus < 0.00001) cap=0;
  
  upNsp = mark("nspAUp")*mark("busAUp") + mark("nspBUp")*mark("busBUp");
  upDsp = mark("dspAUp")*mark("busAUp") + mark("dspBUp")*mark("busBUp");
  if ( upNsp<numNspFcMin-0.00001 )  { capNsp = (double)upNsp/numNspFcMin; }
  else { capNsp=1; }
  if ( upDsp<numDspFcMin-0.00001 )  { capDsp = (double)upDsp/numDspFcMin; }
  else { capDsp=1; }
  if (cap>0.99999)  { cap = ( capNsp < capDsp ) ?  capNsp : capDsp; }
}
  



/* GUARD Functions */ 

/* RATE Functions */ 

double rrfPsf() {
  calCap();
  if ( cap<0.00001 ) { return rrTo; }
  else { return rrLr; }
}

double rrfBus() {
  calCap();
  if ( cap<0.00001 ) { return rrTo; }
  else { return rrPo; }
}

/* CARDINALITY Functions */ 



void net() {

  /*  PLACE  */

  place("hspUp");
  init("hspUp",1);
  place("hspDn");
  place("bpUp");
  init("bpUp",1);
  place("bpDn");
  place("psfUp");
  init("psfUp",numPsf);
  place("psfDn");
  place("busAUp");
  init("busAUp",1);
  place("busADn");
  place("busBUp");
  init("busBUp",1);
  place("busBDn");
  place("nspAUp");
  init("nspAUp",numNspA);
  place("nspADn");
  place("nspBUp");
  init("nspBUp",numNspB);
  place("nspBDn");
  place("dspAUp");
  init("dspAUp",numDspA);
  place("dspADn");
  place("dspBUp");
  init("dspBUp",numDspB);
  place("dspBDn");

  /*  TRANSITION  */

  ratedep("hspFail", frHsp, "hspUp");
  ratedep("hspRepr", rrHsp, "hspDn");
  ratedep("bpFail", frBp, "bpUp");
  ratedep("bpRepr", rrBp, "bpDn");
  ratedep("psfFail", frPsf, "psfUp");
  ratefun("psfRepr", rrfPsf);
  ratedep("busAFail", frBus, "busAUp");
  ratefun("busARepr", rrfBus);
  ratedep("busBFail", frBus, "busBUp");
  ratefun("busBRepr", rrfBus);
  ratedep("nspAFail", frNsp, "nspAUp");
  ratedep("nspARepr", rrNsp, "nspADn");
  ratedep("nspBFail", frNsp, "nspBUp");
  ratedep("nspBRepr", rrNsp, "nspBDn");
  ratedep("dspAFail", frDsp, "dspAUp");
  ratedep("dspARepr", rrDsp, "dspADn");
  ratedep("dspBFail", frDsp, "dspBUp");
  ratedep("dspBRepr", rrDsp, "dspBDn");

  /*  ARC  */

  iarc("hspFail", "hspUp");
  oarc("hspFail", "hspDn");
  iarc("hspRepr", "hspDn");
  oarc("hspRepr", "hspUp");
  iarc("bpFail", "bpUp");
  oarc("bpFail", "bpDn");
  iarc("bpRepr", "bpDn");
  oarc("bpRepr", "bpUp");
  iarc("psfFail", "psfUp");
  oarc("psfFail", "psfDn");
  iarc("psfRepr", "psfDn");
  oarc("psfRepr", "psfUp");
  iarc("busAFail", "busAUp");
  oarc("busAFail", "busADn");
  iarc("busARepr", "busADn");
  oarc("busARepr", "busAUp");
  iarc("busBFail", "busBUp");
  oarc("busBFail", "busBDn");
  iarc("busBRepr", "busBDn");
  oarc("busBRepr", "busBUp");
  iarc("nspAFail", "nspAUp");
  oarc("nspAFail", "nspADn");
  iarc("nspARepr", "nspADn");
  oarc("nspARepr", "nspAUp");
  iarc("nspBFail", "nspBUp");
  oarc("nspBFail", "nspBDn");
  iarc("nspBRepr", "nspBDn");
  oarc("nspBRepr", "nspBUp");
  iarc("dspAFail", "dspAUp");
  oarc("dspAFail", "dspADn");
  iarc("dspARepr", "dspADn");
  oarc("dspARepr", "dspAUp");
  iarc("dspBFail", "dspBUp");
  oarc("dspBFail", "dspBDn");
  iarc("dspBRepr", "dspBDn");
  oarc("dspBRepr", "dspBUp");

} 

void assert() { 

}

void ac_init() { 

}

void ac_reach() { 

}

void ac_final() { 
/*
  double t;
  for (t=0; t<=50000; t+=30000)  {
    solve(t);
    pr_expected("dtime",dtime);
    pr_expected("dtimeFC",dtimeFC);
    pr_expected("dtimeF",dtimeF);
    pr_expected("tdpm", tdpm);
  }
*/
  solve(INFINITY);
  pr_expected("uodpm", uodpm);

  pr_message("\n------------------\n");
  pr_expected("tpodpm", tpodpm);
  pr_expected("tpodpmNsp", tpodpmNsp);
  pr_expected("tpodpmDsp", tpodpmDsp);
  pr_expected("tpodpmBus", tpodpmBus);
  pr_value("podpm", expected(tpodpm)-expected(tsodpm));
  pr_value("podpmNsp", expected(tpodpmNsp)-expected(tsodpmNsp));
  pr_value("podpmDsp", expected(tpodpmDsp)-expected(tsodpmDsp));
  pr_value("podpmBus", expected(tpodpmBus)-expected(tsodpmBus));

  pr_message("\n------------------\n");
  pr_expected("tsodpm", tsodpm);
  pr_expected("tsodpmHsp", tsodpmHsp);
  pr_expected("tsodpmBp", tsodpmBp);
  pr_expected("tsodpmPsf", tsodpmPsf);
  pr_expected("tsodpmBus", tsodpmBus);
  pr_expected("tsodpmNsp", tsodpmNsp);
  pr_expected("tsodpmDsp", tsodpmDsp);

  pr_message("\n------------------\n");
  pr_message("\nequivalents for the UO (unweighted) of the system:\n");
  hold_cond(condUo,timesUo);
  pr_value("UO-MTTFeq",timesUo[0]);
  pr_value("UO-MTTReq",timesUo[1]);
  pr_value("UO-OFM:  ", (1-expected(uodpm)/(8766*60)) / timesUo[0] *8766);
  pr_message("\nequivalent DPM computed from MTTFeq and MTTReq:\n");
  pr_value("UODPMeq", timesUo[1]/(timesUo[1]+timesUo[0])*8766*60);

  pr_message("\n------------------\n");
  pr_message("\nequivalents for the TSO of the system:\n");
  hold_cond(condTso,timesTso);
  pr_value("TSO-MTTFeq",timesTso[0]);
  pr_value("TSO-MTTReq",timesTso[1]);
  pr_value("TSOFM:  ", (1-expected(tsodpm)/(8766*60)) / timesTso[0] *8766);
  pr_message("\nequivalent DPM computed from MTTFeq and MTTReq:\n");
  pr_value("TSODPMeq", timesTso[1]/(timesTso[1]+timesTso[0])*8766*60);

  pr_mc_info();
  pr_std_average();
}

