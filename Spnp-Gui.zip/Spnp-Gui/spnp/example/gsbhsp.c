
#include <stdio.h>
#include "user.h"

/* global variables */ 

/* all the rates are in the format 1.0/MTTF or 1.0/MTTR (unit: 1/Hour) */

double lambdaP=1.0/180000.0;	/* (hardware) failure rate for HSP */
double lambdaT=1.0/4000.0;	/* transient (/sw) failure rate for HSP */
double muCr=1.0/4.0;		/* repair rate for Critical HSP fault */
double muNc=1.0/12.0;		/* repair rate for Non-Critical HSP fault */

/* repair rate for non-critical HSP fault (after having repaired critical */
/*        HSP fault.  */
double muNcS=1.0;	

/* reboot time for HSP fault (active HSP failed, unsuccessful detection, */
/*        standby HSP working),   1 min */
double beta1=1.0/(1.0/60.0);

/* reboot time for HSP fault (???)  */
double beta=1.0/(1.0/60.0);

/* Active HSP fault detection/switching to standby HSP delay time,  5 sec  */
double delta=1.0/(4.0/3600.0);

/* coverage for the above detection/switching  */
double c=0.98;

/* coverage for reboot (beta1)  */
double q=0.80;

/* coverage for reboot (beta)   */
double r;

/* Fraction of transient/sw faults that are manifest in Standby HSP */
double alpha=0.2;

/* threshold for counting the unavailability of the HSPs  */
double tR=10.0/3600.0;
 
/* prototype reward functions */ 
double dtime(); 
double dtimeFC(); 
double dtimeF();

/* prototype guard functions */ 

/* prototype rate functions */ 
double rHsp2_D();
double rHsp2_hsp1();
double rD_hsp1();
double rD_Ds();
double rDs_hsp2();
double rDs_FC();
double rHsp1_hsp1s();
double rHsp1_hsp2();
double rHsp1_hsp0();
double rHsp0_F();
double rHsp0_hsp1();
double rHsp1s_hsp0s();
double rHsp0s_hsp1s();
double rHsp0s_F();

/* values for global variables */

/* prototype cardinality functions */ 



void options() {
  iopt(IOP_PR_RGRAPH,VAL_NO) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_NO) ;
  iopt(IOP_USENAME,VAL_NO) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_NO) ;
  iopt(IOP_PR_MC_ORDER,VAL_FROMTO) ;
  /* NUMERICAL SOLUTION chosen */ 
  iopt(IOP_SENSITIVITY,VAL_NO) ;
  iopt(IOP_MC,VAL_CTMC) ;
  iopt(IOP_SSMETHOD,VAL_SSSOR) ;
  iopt(IOP_TSMETHOD,VAL_FOXUNIF) ;
  iopt(IOP_ITERATIONS,2000) ;
  fopt(FOP_PRECISION,0.000001) ;
  fopt(FOP_ABS_RET_M0,0.0) ;
  iopt(IOP_CUMULATIVE,VAL_NO) ;
  iopt(IOP_SSDETECT,VAL_YES) ;
  iopt(IOP_OK_ABSMARK,VAL_NO) ;
  iopt(IOP_OK_VANLOOP,VAL_NO) ;
  iopt(IOP_OK_TRANS_M0,VAL_YES) ;
  iopt(IOP_OK_VAN_M0,VAL_YES) ;
  iopt(IOP_ELIMINATION,VAL_REDONTHEFLY) ;

  /* some computation */
  r = lambdaT/(lambdaP+lambdaT);

} 


/* REWARD Functions */ 
double dtime() {
  double dtime;
  dtime = ( (double)mark("Ds")*exp(-beta1*tR) 
          + (double)mark("D")*exp(-delta*tR)
          + (double)mark("hsp0s")*exp(-beta*tR)
          + (double)mark("hsp0")*exp(-beta*tR)
          + (double)mark("FC")*1.0 
          + (double)mark("F")*1.0 );
  dtime *= 8766*60;
  return dtime;
} 

double dtime60vs10() {
  double dtime;
  dtime = ( (double)mark("Ds")
          + (double)mark("D")*exp(-delta*tR)
          + (double)mark("hsp0s")
          + (double)mark("hsp0")
          + (double)mark("FC")*1.0 
          + (double)mark("F")*1.0 );
  dtime *= 8766*60;
  return dtime;
} 

double dtime5vs10() {
  double dtime;
  dtime = ( (double)mark("Ds")
          + (double)mark("hsp0s")
          + (double)mark("hsp0")
          + (double)mark("FC")*1.0 
          + (double)mark("F")*1.0 );
  dtime *= 8766*60;
  return dtime;
} 

int cond() {
  if ( mark("hsp2")==0 && mark("hsp1")==0 && mark("hsp1s")==0
       && mark("hsp1ss")==0 )  { return 1; }
  else { return 0; }
}

double times[2];

int condFC() {
  if ( mark("FC")==1)  { return 1; }
  else { return 0; }
}

double timesFC[2];

int condF() {
  if ( mark("F")==1)  { return 1; }
  else { return 0; }
}

double timesF[2];

int cond5vs10() {
  if ( mark("hsp2")==0 && mark("hsp1")==0 && mark("hsp1s")==0
       && mark("hsp1ss")==0 && mark("D")==0 )  { return 1; }
  else { return 0; }
}

double times5vs10[2];


double tsodpm() {
  double dtime;
  dtime = ( (double)mark("Ds")
          + (double)mark("D")
          + (double)mark("hsp0s")
          + (double)mark("hsp0")
          + (double)mark("FC")
          + (double)mark("F"));
  dtime *= 8766*60;
  return dtime;
}

double dtimeFC() {
  double dtimeFC;
  dtimeFC = (double)mark("FC")*1.0;
  dtimeFC *= 8766*60;
  return dtimeFC;
}

double dtimeF() {
  double dtimeF;
  dtimeF = (double)mark("F")*1.0;
  dtimeF *= 8766*60;
  return dtimeF;
}

/* GUARD Functions */ 

/* RATE Functions */ 
double rHsp2_D() {
  return(lambdaP+lambdaT);
}
double rHsp2_hsp1() {
  return(lambdaP+alpha*lambdaT);
}
double rD_hsp1() {
  return(delta*c);
}
double rD_Ds() {
  return(delta*(1-c));
}
double rDs_hsp2() {
  return(beta1*q);
}
double rDs_FC () {
  return(beta1*(1-q));
}
double rHsp1_hsp1s() {
  return(beta*(1-r));
}
double rHsp1_hsp2() {
  return(beta*r);
}
double rHsp1_hsp0() {
  return(lambdaP+lambdaT);
}
double rHsp0_F() {
  return(beta*(1-r));
}
double rHsp0_hsp1() {
  return(beta*r);
}
double rHsp1s_hsp0s() {
  return(lambdaP+lambdaT);
}
double rHsp0s_hsp1s() {
  return (beta*r); 
}
double rHsp0s_F() {
  return (beta*(1-r));
}

/* CARDINALITY Functions */ 

void net() {
  
  /*  PLACE  */		/* Active HSP			Standby HSP  */
  place("hsp2");	/* no fault			no fault	*/
  init("hsp2",1);
  place("D");		/* fault, try to detect		no faul	*/
  place("Ds");		/* fault not covered, reboot	no fault	*/
  place("FC");		/* reboot failed, repair	no faul	*/
  place("hsp1");	/* no fault			reboot	*/
  place("hsp1s"); 	/* no fault			repair	*/
  place("hsp1ss");	/* no faul			repair/reboot */
  place("hsp0");	/* reboot			waiting for reboot */
  place("hsp0s");	/* reboot			waiting for repair */
  place("F");		/* repair			waiting for repair */
  /*  TRANSITION  */
  ratefun("hsp2_D",rHsp2_D);
  ratefun("hsp2_hsp1",rHsp2_hsp1);
  ratefun("D_hsp1",rD_hsp1);
  ratefun("D_Ds",rD_Ds);
  ratefun("Ds_hsp2",rDs_hsp2);
  ratefun("Ds_FC",rDs_FC);
  rateval("FC_hsp2",muCr);
  ratefun("hsp1_hsp1s",rHsp1_hsp1s);
  ratefun("hsp1_hsp2",rHsp1_hsp2);
  ratefun("hsp1_hsp0",rHsp1_hsp0);
  ratefun("hsp0_F",rHsp0_F);
  ratefun("hsp0_hsp1",rHsp0_hsp1);
  ratefun("hsp1s_hsp0s",rHsp1s_hsp0s);
  rateval("hsp1s_hsp2",muNc);
  ratefun("hsp0s_hsp1s",rHsp0s_hsp1s);
  ratefun("hsp0s_F",rHsp0s_F);
  rateval("F_hsp1ss",muCr);
  rateval("hsp1ss_hsp2",muNcS);
  /*  ARC  */
  iarc("hsp2_D","hsp2");
  oarc("hsp2_D","D");
  iarc("hsp2_hsp1","hsp2");
  oarc("hsp2_hsp1","hsp1");
  iarc("D_hsp1","D");
  oarc("D_hsp1","hsp1");
  iarc("D_Ds","D");
  oarc("D_Ds","Ds");
  iarc("Ds_hsp2","Ds");
  oarc("Ds_hsp2","hsp2");
  iarc("Ds_FC","Ds");
  oarc("Ds_FC","FC");
  iarc("FC_hsp2","FC");
  oarc("FC_hsp2","hsp2");
  iarc("hsp1_hsp1s","hsp1");
  oarc("hsp1_hsp1s","hsp1s");
  iarc("hsp1_hsp2","hsp1");
  oarc("hsp1_hsp2","hsp2");
  iarc("hsp1_hsp0","hsp1");
  oarc("hsp1_hsp0","hsp0");
  iarc("hsp0_F","hsp0");
  oarc("hsp0_F","F");
  iarc("hsp0_hsp1","hsp0");
  oarc("hsp0_hsp1","hsp1");
  iarc("hsp1s_hsp0s","hsp1s");
  oarc("hsp1s_hsp0s","hsp0s");
  iarc("hsp1s_hsp2","hsp1s");
  oarc("hsp1s_hsp2","hsp2");
  iarc("hsp0s_hsp1s","hsp0s");
  oarc("hsp0s_hsp1s","hsp1s");
  iarc("hsp0s_F","hsp0s");
  oarc("hsp0s_F","F");
  iarc("F_hsp1ss","F");
  oarc("F_hsp1ss","hsp1ss");
  iarc("hsp1ss_hsp2","hsp1ss");
  oarc("hsp1ss_hsp2","hsp2");
} 

void assert() { 

}

void ac_init() { 

}

void ac_reach() { 

}

void ac_final() { 
/*
  double t;
  for (t=0; t<=50000; t+=30000)  {
    solve(t);
    pr_expected("dtime",dtime);
    pr_expected("dtimeFC",dtimeFC);
    pr_expected("dtimeF",dtimeF);
  }
*/
  solve(INFINITY);
  pr_expected("dtime",dtime);
  pr_expected("dtimeFC",dtimeFC);
  pr_expected("dtimeF",dtimeF);
  pr_expected("tsodpm",tsodpm);
  pr_hold_cond("test",cond);
  hold_cond(cond,times);
  pr_value("times0",times[0]);
  pr_value("times1",times[1]);
  pr_value("tsodpm computed from times", times[1]/(times[1]+times[0])*8766*60);

  pr_message("\nlook at state FC\n");
  hold_cond(condFC,timesFC);
  pr_value("timesFC0",timesFC[0]);
  pr_value("timesFC1",timesFC[1]);
  pr_value("dtimeFC computed from timesFC", timesFC[1]/(timesFC[1]+timesFC[0])
          *8766*60);

  pr_message("\nlook at state F\n");
  hold_cond(condF,timesF);
  pr_value("timesF0",timesF[0]);
  pr_value("timesF1",timesF[1]);
  pr_value("dtimeF computed from timesF", timesF[1]/(timesF[1]+timesF[0])
          *8766*60);

  pr_message("\nput Ds,0,0s into down state\n");
  pr_expected("dtime60vs10",dtime60vs10);

  pr_message("\n------------------\n");
  pr_message("\n(This is what actually used ");
  pr_message("and fed into upper level.)\n");
  pr_message("\nPut D into up state, Ds,0,0s into down state.\n");
  pr_expected("dtime5vs10",dtime5vs10);
  hold_cond(cond5vs10,times5vs10);
  pr_value("MTTFeq",times5vs10[0]);
  pr_value("MTTReq",times5vs10[1]);
  pr_value("ofm:  ", (1-expected(dtime5vs10)/(8766*60)) / times5vs10[0] *8766);

  pr_mc_info();
  pr_std_average();
}

