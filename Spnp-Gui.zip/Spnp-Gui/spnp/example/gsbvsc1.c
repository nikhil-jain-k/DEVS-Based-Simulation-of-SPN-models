
#include <stdio.h>
#include "user.h"

/* global variables */ 

/* all the rates are in the format 1.0/MTTF or 1.0/MTTR (unit: 1/Hour) */

double lambdaP=1.0/120000.0;	/* (hardware) failure rate for HSP */
double lambdaT=1.0/4000.0;	/* transient (/sw) failure rate for HSP */

/* reboot time for HSP fault (active HSP failed, unsuccessful detection, */
/*        standby HSP working),   1 min */
double beta1=1.0/(1.0/60.0);

/* coverage for reboot (beta1)  */
/*double q=0.80;*/
double q;

/* coverage for reboot (beta)   */
double r;

/* repair rate of Ps+Fn, Bus, NSP, DSP  */
/*   in lost redudency/partial outage/total outage */
double rrLr=1.0/24.0;
double rrPo=1.0/8.0;
double rrTo=1.0/4.0;

 
/* prototype reward functions */ 
double dtime(); 
int cond();

/* prototype guard functions */ 

/* prototype rate functions */ 
double rHsp2_Ds();
double rDs_hsp2();
double rDs_FC();

/* values for global variables */

/* prototype cardinality functions */ 



void options() {
  iopt(IOP_PR_RGRAPH,VAL_NO) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_NO) ;
  iopt(IOP_USENAME,VAL_NO) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_NO) ;
  iopt(IOP_PR_MC_ORDER,VAL_FROMTO) ;
  /* NUMERICAL SOLUTION chosen */ 
  iopt(IOP_SENSITIVITY,VAL_NO) ;
  iopt(IOP_MC,VAL_CTMC) ;
  iopt(IOP_SSMETHOD,VAL_SSSOR) ;
  iopt(IOP_TSMETHOD,VAL_FOXUNIF) ;
  iopt(IOP_ITERATIONS,2000) ;
  fopt(FOP_PRECISION,0.000001) ;
  fopt(FOP_ABS_RET_M0,0.0) ;
  iopt(IOP_CUMULATIVE,VAL_NO) ;
  iopt(IOP_SSDETECT,VAL_YES) ;
  iopt(IOP_OK_ABSMARK,VAL_NO) ;
  iopt(IOP_OK_VANLOOP,VAL_NO) ;
  iopt(IOP_OK_TRANS_M0,VAL_YES) ;
  iopt(IOP_OK_VAN_M0,VAL_YES) ;
  iopt(IOP_ELIMINATION,VAL_REDONTHEFLY) ;

  /* some computation */
  r = lambdaT/(lambdaP+lambdaT);
  q=r;

} 


/* REWARD Functions */ 

double dtime() {
  double dtime;
  dtime = ( (double)mark("Ds")
          + (double)mark("FC"));
  dtime *= 8766*60;
  return dtime;
}

int cond() {
  if ( mark("hsp2")==0 )  { return 1; }
  else { return 0; }
}

double times[2];


/* GUARD Functions */ 


/* RATE Functions */ 
double rHsp2_Ds() {
  return(lambdaP+lambdaT);
}
double rDs_hsp2() {
  return(beta1*q);
}
double rDs_FC () {
  return(beta1*(1-q));
}

/* CARDINALITY Functions */ 

void net() {
  
  /*  PLACE  */		/* Active HSP			Standby HSP  */
  place("hsp2");	/* no fault			no fault	*/
  init("hsp2",1);
  place("Ds");		/* fault not covered, reboot	no fault	*/
  place("FC");		/* reboot failed, repair	no faul	*/
  /*  TRANSITION  */
  ratefun("hsp2_Ds",rHsp2_Ds);
  ratefun("Ds_hsp2",rDs_hsp2);
  ratefun("Ds_FC",rDs_FC);
  rateval("FC_hsp2",rrPo);
  /*  ARC  */
  iarc("hsp2_Ds","hsp2");
  oarc("hsp2_Ds","Ds");
  iarc("Ds_hsp2","Ds");
  oarc("Ds_hsp2","hsp2");
  iarc("Ds_FC","Ds");
  oarc("Ds_FC","FC");
  iarc("FC_hsp2","FC");
  oarc("FC_hsp2","hsp2");
} 

void assert() { 

}

void ac_init() { 

}

void ac_reach() { 

}

void ac_final() { 
  solve(INFINITY);
  pr_expected("dtime",dtime);

  pr_message("\n------------------\n");
  pr_message("\n(This is what actually used ");
  pr_message("and fed into upper level.)\n");
  pr_message("\nequivalents for the subsystem:\n");
  hold_cond(cond,times);
  pr_value("MTTFeq",times[0]);
  pr_value("MTTReq",times[1]);
  pr_value("ofm:  ", (1-expected(dtime)/(8766*60)) / times[0] *8766);
  pr_message("\nequivalent DPM computed from MTTFeq and MTTReq:\n");
  pr_value("DPMeq", times[1]/(times[1]+times[0])*8766*60);

  pr_mc_info();
  pr_std_average();
}

