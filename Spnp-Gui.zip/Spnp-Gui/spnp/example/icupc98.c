/* This is the SPNP source code for the first recovery scheme adopted from
   Ma, Ro and Trivedi "Performability Analysis of Channel Allocation with 
   Channel Recovery Strategy in Cellular Networks",  In Proceedings 
   of IEEE 1998 International Conference on Universal Personal
   Communications (ICUPC'98), Florence, Italy, 5-9 October, 1998.  
*/

#include "user.h"
#include <math.h>

#define MAX_ITERATIONS  6
#define MAX_ERROR	1e-7

/* Global variables */
double lam_n, lam_h_o, lam_d, lam_f, h_b, mu_r, lam_h_i, tmp;
int t_channel, g_c, sym;
FILE *s1_in, *s1_diff;
 
void options() {
  iopt(IOP_SSMETHOD, VAL_SSSOR);
  iopt(IOP_TSMETHOD,VAL_TSUNIF); 
  iopt(IOP_OK_TRANS_M0, VAL_YES);
  iopt(IOP_MC,VAL_CTMC);
  iopt(IOP_ITERATIONS,20000);
  fopt(FOP_ABS_RET_M0,0.0);
  fopt(FOP_PRECISION,MAX_ERROR*1e-3);

  t_channel=28;
  g_c = 1;
  lam_n = 10;  /* New call arrival rate */
  
  lam_h_o = 0.33;   /* handoff every 5 minutes */
  
  lam_h_i = 0.2; /* Handoff_in rate */
  
  lam_d=0.5; /* call duration: 120 seconds */

  lam_f=0.000016677;
  mu_r = 0.0167;
} 

void net() {

  /* parameters */
  parm("lam_h_i");
  parm("lam_n");

  place("T");	place("B");	place("R");
  place("CP");   	init("CP",t_channel) ;

  /* timed trans */
  rateval("t_n", 1.0);
  useparm("t_n", "lam_n");
  rateval("t_h_i", 1.0);
  useparm("t_h_i","lam_h_i");
  ratedep("t_d", lam_d, "T");
  ratedep("t_f", lam_f, "T");
  ratedep("t_h_o", lam_h_o,"T");
  rateval("t_r", mu_r);

   /* immed trans */
  imm("t_1") ; priority("t_1", 100) ;
  probval("t_1",1.0);

  /*  ARC  form timed trans*/
  miarc("t_n","CP", g_c+1); oarc("t_n","T"); moarc("t_n","CP",g_c);
  iarc("t_h_i","CP"); oarc("t_h_i","T");
  iarc("t_h_o","T"); oarc("t_h_o","CP");
  iarc("t_d","T");  oarc("t_d","CP");
  iarc("t_f","T");  oarc("t_f","B"); 	oarc("t_f","R");
  iarc("t_r","R");  oarc("t_r","CP");

  /*  ARC  for immediate trans */
  iarc("t_1","B");  iarc("t_1", "CP"); oarc("t_1", "T");
  
    /* assign parameters */
  bind("lam_h_i", lam_h_i);
  bind("lam_n", lam_n);

  } 

int assert() {
  return(RES_NOERR);
}

void ac_init() { 
}

void ac_reach() {
}

double BH() 
{
  if (mark("CP")==0)
    return (1.0);
  else 
    return (0.0);
}

double BN() 
{
  if (mark("CP")<=g_c)
    return (1.0);
  else 
    return (0.0);
}

double ACh()
{
  return(mark("CP"));
}

double hotput()
{
  return(rate("t_h_o"));
}

/* average failure arrival rate */
double ftput()
{
  return(rate("t_f"));
}

double fnum()
{
  return(mark("B"));
}

void ac_final() {
  int i;
  double tp,err;
  
  for (i=1; i<MAX_ITERATIONS; i++) {
    pr_value("lam_h_i", lam_h_i);
    bind("lam_h_i", lam_h_i);
    solve(INFINITY);
    tp = expected(hotput);
    pr_value("Throughput of t_h_o", tp);
    err = fabs((lam_h_i-tp)/tp);
    pr_value("Error", err);
    if( err < MAX_ERROR ) break;
    lam_h_i = tp;
  }

  pr_expected("block handoff:", BH);
  pr_expected("block new:", BN);   
  pr_expected("available channel: ", ACh);
  pr_value("avg. waiting time:", expected(fnum)/expected(ftput));
}
