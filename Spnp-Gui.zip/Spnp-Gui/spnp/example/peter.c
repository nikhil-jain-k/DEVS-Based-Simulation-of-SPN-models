#include <stdio.h>

#define TPRIO 10
#define LPRIO 50
#define PRIO 100
#define HPRIO 200

# include	"user.h"

/* This is an spnp input file for two phase commit protocol
   Peter King                                   */

typedef char PLACE[MAX_NAME_LENGTH+1];
typedef char TRANS[MAX_NAME_LENGTH+1];

#define NEW_NAME(a,b,c)  { strcpy(a,b); strcat(a,c); }
#define NEW_PLACE(a,b,c) { strcpy(a,b); strcat(a,c); place(a); }
#define NEW_TRANS(a,b,c) { strcpy(a,b); strcat(a,c); }
#define NEW_IMM_TRANS(a,b,c)   { strcpy(a,b); strcat(a,c); imm(a); }

void create_server( char *name, int no_locks);

void create_task( char *name, char *server, int no_locks,
		  double (*compute)(),
		  double (*grant)(),
		  double (*refuse)(),
		  int (*can_grant)(),
		  int (*can_refuse)());

void create_transaction( char *transaction, char **tasks, int no_tasks,
			 double start_rate,
			 int (*rdrain)(),
			 int (*ssdrain)(),
			 int (*xenable)());

double Pgrant(), Prefuse();
double Prate();
int can_Pgrant(), can_Prefuse();
double Qgrant(), Qrefuse();
double Qrate();
int can_Qgrant(), can_Qrefuse();
double Rgrant(), Rrefuse();
double Rrate();
int can_Rgrant(), can_Rrefuse();
double Sgrant(), Srefuse();
double Srate();
int can_Sgrant(), can_Srefuse();
double Tgrant(), Trefuse();
double Trate();
int can_Tgrant(), can_Trefuse();
double Ugrant(), Urefuse();
double Urate();
int can_Ugrant(), can_Urefuse();
double Vgrant(), Vrefuse();
double Vrate();
int can_Vgrant(), can_Vrefuse();
double Wgrant(), Wrefuse();
double Wrate();
int can_Wgrant(), can_Wrefuse();
double Xgrant(), Xrefuse();
double Xrate();
int can_Xgrant(), can_Xrefuse();
double Ygrant(), Yrefuse();
double Yrate();
int can_Ygrant(), can_Yrefuse();
double Zgrant(), Zrefuse();
double Zrate();
int can_Zgrant(), can_Zrefuse();
int  Ffaildrain(), Fsomsucdrain(),  Ffailenable(),
  Gfaildrain(), Gsomsucdrain(), Gfailenable(),
  Kfaildrain(), Ksomsucdrain(), Kfailenable(),
  Jfaildrain(), Jsomsucdrain(), Jfailenable(),
  Hfaildrain(), Hsomsucdrain(), Hfailenable();

#define MAX_SERVERS 5
#define MAX_TRANSACTIONS 5
#define MAX_TASKS 10

double server_rate[MAX_SERVERS];
int server_locks[MAX_SERVERS];

double task_mean[MAX_TASKS];
int task_locks[MAX_TASKS];
int task_server[MAX_TASKS];

struct tr_info {
  int (*rdrain)();
  int (*ssdrain)();
  int (*xenable)();
} transaction_info[] = {
  { Ffaildrain, Fsomsucdrain, Ffailenable},
  { Gfaildrain, Gsomsucdrain, Gfailenable},
  { Hfaildrain, Hsomsucdrain, Hfailenable},
  { Jfaildrain, Jsomsucdrain, Jfailenable},
  { Kfaildrain, Ksomsucdrain, Kfailenable},
};
struct t_info {
  double (*compute_rate)();
  int (*can_grant)();
  int (*can_refuse)();
  double (*grant)();
  double (*refuse)();
} task_info[] = {
  {Prate, can_Pgrant, can_Prefuse, Pgrant, Prefuse},
  {Qrate, can_Qgrant, can_Qrefuse, Qgrant, Qrefuse},
  {Rrate, can_Rgrant, can_Rrefuse, Rgrant, Rrefuse},
  {Srate, can_Sgrant, can_Srefuse, Sgrant, Srefuse},
  {Trate, can_Tgrant, can_Trefuse, Tgrant, Trefuse},
  {Urate, can_Ugrant, can_Urefuse, Ugrant, Urefuse},
  {Vrate, can_Vgrant, can_Vrefuse, Vgrant, Vrefuse},
  {Wrate, can_Wgrant, can_Wrefuse, Wgrant, Wrefuse},
  {Xrate, can_Xgrant, can_Xrefuse, Xgrant, Xrefuse},
  {Yrate, can_Ygrant, can_Yrefuse, Ygrant, Yrefuse},
  {Zrate, can_Zgrant, can_Zrefuse, Zgrant, Zrefuse}
};


int transaction_tasks[MAX_TRANSACTIONS];
int init_task[MAX_TRANSACTIONS];

double transaction_rate[MAX_TRANSACTIONS];
int no_servers, total_tasks, no_transactions;
int no_tasks;

char * trans_names[] = { "F", "G", "H", "J", "K"};
char * server_names[] = { "A", "B", "C", "D", "E"};

char *task_names[] = { "P", "Q", "R", "S" ,"T" ,"U" ,"V" ,"W" ,"X" ,"Y" ,"Z" };

void options()
{
  int i;
  double dbg = 0;

  no_servers = input(" Number of servers");
  if ( no_servers > MAX_SERVERS)
    fprintf(stderr, "No servers %d exceeds maximum %d\n", no_servers, MAX_SERVERS);
  for ( i = 0; i < no_servers; i++)
    {
      server_rate[i] = finput("Server rate");
      server_locks[i] = input("No locks");
    }

  no_transactions = input("Number of transactions");
  if ( no_transactions > MAX_TRANSACTIONS)
    fprintf(stderr, "No transactions %d exceeds maximum %d\n", no_transactions, MAX_TRANSACTIONS);
  total_tasks = 0;
  for ( i = 0; i < no_transactions; i++)
    {
      transaction_tasks[i] = input("Number of tasks this transaction");
      transaction_rate[i] = finput("Transaction think rate");

      total_tasks += transaction_tasks[i];
    }
  if ( total_tasks > MAX_TASKS)
    fprintf(stderr, "No tasks %d exceeds maximum %d\n", total_tasks, MAX_TASKS);

  for ( i = 0; i < total_tasks; i++)
    {
      task_mean[i] = finput("Task Computing mean");
      task_locks[i] = input("Task no of locks needed");
      task_server[i] = input("Server for task");
    }

  iopt(IOP_PR_FULL_MARK,VAL_NO);
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC);
  iopt(IOP_PR_MC_ORDER,VAL_TOFROM);
  iopt(IOP_PR_MC,VAL_YES);
  iopt(IOP_PR_PROB,VAL_YES);
  iopt(IOP_DEBUG,dbg ? VAL_YES:VAL_NO);
  iopt(IOP_MC,VAL_CTMC);
  iopt(IOP_PR_RSET,VAL_YES);
  iopt(IOP_PR_RGRAPH,VAL_YES);
  iopt(IOP_USENAME,dbg ? VAL_YES:VAL_NO);
  fopt(FOP_PRECISION,0.00000001);

  iopt(IOP_SSMETHOD,VAL_SSSOR);

}

void net()
{
  int i;

  total_tasks = 0;
  for ( i = 0; i < no_transactions; i++)
    {
      create_transaction(trans_names[i],
			 task_names+total_tasks, transaction_tasks[i],
			 transaction_rate[i],
			 transaction_info[i].rdrain,
			 transaction_info[i].ssdrain,
			 transaction_info[i].xenable);
      total_tasks += transaction_tasks[i];
    }

  for ( i = 0; i < no_servers; i++)
      create_server( server_names[i], server_locks[i]);

  for( i = 0; i < total_tasks; i++)
    create_task( task_names[i], server_names[task_server[i]], task_locks[i],
		 task_info[i].compute_rate,
		 task_info[i].grant, task_info[i].refuse,
		 task_info[i].can_grant, task_info[i].can_refuse);

}

double grant( char *server, char *task)
{
  PLACE free, locked;
  int f, l;

  NEW_NAME(free, server, "_free");
  NEW_NAME(locked, server, "_locked");
  f = mark(free);
  l = mark(locked);
  if ( l == 0 ) return 1.0;
  if ( f == 0 ) return 0.0;
  return ((double) f)/(l+f);
}

int trans_fail_drain( char *trans)
{
  PLACE x;
  NEW_NAME( x, trans, "_one_failed");
  return mark(x);
}

int trans_some_suc_drain( char *trans)
{
  PLACE x;
  NEW_NAME( x, trans, "_some_succeed");
  return mark(x);
}

int xfailenable(char *trans, int i)
{
  PLACE failed, succeeded;
  int m = 0;
  NEW_NAME(failed, trans, "_one_failed");
  m = mark(failed);
  if ( m == 0 )
    return 0;
  NEW_NAME(succeeded, trans, "_some_succeed");
  return ((mark(succeeded) + m) == transaction_tasks[i]);
}

int Ffailenable()
{
  return xfailenable("F", 0);
}

int Ffaildrain()
{
  return trans_fail_drain("F");
}

int Fsomsucdrain()
{
  return trans_some_suc_drain("F");
}

int Gfailenable()
{
  return xfailenable("G", 1);
}

int Gfaildrain()
{
  return trans_fail_drain("G");
}

int Gsomsucdrain()
{
  return trans_some_suc_drain("G");
}

int Hfailenable()
{
  return xfailenable("H", 2);
}

int Hfaildrain()
{
  return trans_fail_drain("H");
}

int Hsomsucdrain()
{
  return trans_some_suc_drain("H");
}

int Jfailenable()
{
  return xfailenable("J", 3);
}

int Jfaildrain()
{
  return trans_fail_drain("J");
}

int Jsomsucdrain()
{
  return trans_some_suc_drain("J");
}

int Kfailenable()
{
  return xfailenable("K", 4);
}

int Kfaildrain()
{
  return trans_fail_drain("K");
}

int Ksomsucdrain()
{
  return trans_some_suc_drain("K");
}

double task_done_rate(int task)
{
  PLACE computing;
  NEW_NAME( computing, server_names[task_server[task]], "_Computing");
  return server_rate[task_server[task]]/(task_mean[task]*mark(computing));
}

void create_transaction( char *transaction, char **tasks, int no_tasks,
			 double start_rate,
			 int (*ofdrain)(),
			 int (*ssdrain)(),
			 int (*enabled)())
{
  TRANS start_trans, task_start, task_done, task_refuse, all_done,
    some_failed, task_commit, task_abort, task_abort2,
    task_running, task_terminate, trans_idle;
  PLACE start_task, running, some_succeed, one_failed, all_succeeded,
    abort_transaction;

  int i;
fprintf(stderr, "Create Transaction %s First task %s Last %s ntasks %d\n",
	transaction, *tasks, *(tasks+no_tasks), no_tasks);

  NEW_PLACE(running, transaction, "_running");
  NEW_PLACE(trans_idle, transaction, "_idle");
  init(trans_idle, no_tasks);
  NEW_PLACE(some_succeed, transaction, "_some_succeed");
  NEW_PLACE(one_failed, transaction, "_one_failed");
  NEW_PLACE(all_succeeded, transaction, "_all_succeeded");
  NEW_PLACE(abort_transaction, transaction, "_abort_transact");

  NEW_TRANS(start_trans, transaction, "_start");
  rateval( start_trans, start_rate);
  priority( start_trans, TPRIO);
  NEW_IMM_TRANS(all_done, transaction, "_all_done");
  probval( all_done, 1.0);
  priority( all_done, HPRIO);
  NEW_IMM_TRANS(some_failed, transaction, "_some_failed");
  priority( some_failed, HPRIO);
  probval( some_failed, 1.0);
  guard( some_failed, enabled);

  /* simple arcs */
  miarc( start_trans, trans_idle, no_tasks);
  miarc( all_done, some_succeed, no_tasks);
  /*  iarc( some_failed, one_failed); */
  moarc( some_failed, abort_transaction, no_tasks);
  moarc( all_done, all_succeeded, no_tasks);

  viarc(some_failed, one_failed, ofdrain);
  viarc(some_failed, some_succeed, ssdrain);

  for ( i = 0; i < no_tasks; i++)
    {
      NEW_PLACE( start_task, tasks[i], "_tr_start");
      NEW_PLACE( task_running, tasks[i], "_tr_run");
      NEW_NAME( task_start, tasks[i], "_Start");
      NEW_NAME( task_done, tasks[i], "_Done");
      NEW_NAME( task_refuse, tasks[i], "_Lock_Refuse");
      NEW_NAME( task_commit, tasks[i], "_Commit");
      NEW_NAME( task_abort, tasks[i], "_Abort");
      NEW_NAME( task_abort2, tasks[i], "_Abort2");
      NEW_NAME( task_terminate, tasks[i], "_Terminate");

      oarc(start_trans, task_running);
      iarc( task_terminate, task_running);
      oarc( task_terminate, trans_idle);

      oarc(start_trans, start_task);
      iarc(task_start, start_task);
      oarc(task_start, running);
      iarc(task_done, running);
      iarc(task_refuse, running);

      oarc(task_done, some_succeed);
      oarc(task_refuse, one_failed);

      iarc(task_commit, all_succeeded);
      iarc(task_abort, abort_transaction);
      iarc(task_abort2, abort_transaction);

    }
}

void create_task( char *task, char *server, int no_locks,
		  double (*compute)(),
		  double (*grant_lock)(),
		  double (*refuse_lock)(),
		  int (*can_grant_lock)(),
		  int (*can_refuse_lock)())
{
  TRANS start, got_all,  done, lock_request, lock_refuse, lock_grant,
    abort, commit, ready, abort2, terminate;

  PLACE locking, asking, failed, lock_release, releasing, computing,
    locks_held,
    lock_locked, lock_free, server_computing, lock_select, lock_wait;

fprintf( stderr, "Create Task %s on Server %s %d locks\n", task, server, no_locks);
  NEW_IMM_TRANS( start, task, "_Start");
  probval( start, 1.0);
  priority( start, HPRIO);
  NEW_IMM_TRANS( got_all, task, "_got_all");
  probval( got_all, 1.0);
  priority( got_all, HPRIO+1);

  NEW_TRANS( done, task, "_Done");
  priority( done, TPRIO);
  ratefun(done, compute);

  NEW_IMM_TRANS( commit, task, "_Commit");
  probval( commit, 1.0);
  priority( commit, HPRIO);
  NEW_IMM_TRANS( abort, task, "_Abort");
  probval( abort, 1.0);
  priority( abort, HPRIO);
  NEW_IMM_TRANS( abort2, task, "_Abort2");
  probval( abort2, 1.0);
  priority( abort2, HPRIO);
  NEW_IMM_TRANS( terminate, task, "_Terminate");
  probval( terminate, 1.0);
  priority( terminate, LPRIO);

  NEW_PLACE( locking, task, "_locking");
  NEW_PLACE( asking, task, "_asking");
  NEW_PLACE( failed, task, "_failed");
  NEW_PLACE( computing, task, "_computing");
  NEW_PLACE( ready, task, "_ready");
  NEW_PLACE( releasing, task, "_releasing");

  NEW_PLACE( locks_held, task, "_locks_held");

  NEW_IMM_TRANS(lock_request, task, "_Lock_Request");
  probval( lock_request, 1.0);
  priority( lock_request, HPRIO);
  NEW_IMM_TRANS(lock_grant, task, "_Lock_Grant");
  guard( lock_grant, can_grant_lock);
  probfun( lock_grant, grant_lock);
  priority( lock_grant, HPRIO);
  NEW_IMM_TRANS(lock_refuse, task, "_Lock_Refuse");
  guard( lock_refuse, can_refuse_lock);
  probfun( lock_refuse, refuse_lock);
  priority( lock_refuse, HPRIO);
  NEW_IMM_TRANS(lock_release, task, "_Lock_Release");
  probval( lock_release, 1.0);
  priority( lock_release, HPRIO);

  NEW_NAME(lock_locked, server, "_locked");
  NEW_NAME(lock_free, server, "_free");
  NEW_NAME( server_computing, server, "_Computing");

  oarc( start, locking);
  oarc( start, server_computing);

  /* request locks */
  iarc( lock_request, locking);
  oarc( lock_request, asking);

  iarc( lock_grant, asking); /* grant or refuse lock */
  iarc( lock_refuse, asking);
  iarc( lock_grant, lock_free);
  oarc( lock_grant, lock_locked);
  oarc( lock_grant, locks_held);

  iarc( lock_release, lock_locked);
  oarc( lock_release, lock_free);

  NEW_NAME( lock_wait, server, "_lock_wait");
  NEW_NAME( lock_select, server, "_lock_select");

  oarc( lock_request, lock_wait);

  iarc( lock_grant, lock_select);
  oarc( lock_grant, locking);

  iarc( lock_refuse, lock_select);

  /* all locks granted path */
  iarc( got_all, locking);
  oarc( got_all, computing);
  miarc( got_all, locks_held, no_locks);
  moarc( got_all, locks_held, no_locks);

  iarc( done, computing);
  iarc( done, server_computing);
  iarc( abort, server_computing);
  oarc( done, ready);

  iarc( commit, ready);
  oarc( commit, releasing);

  iarc( abort2, ready);
  oarc( abort2, releasing);

  /* lock refused */
  oarc( lock_refuse, failed);

  iarc( abort, failed);
  oarc( abort, releasing);

  iarc( lock_release, locks_held);
  iarc( lock_release, releasing);
  oarc( lock_release, releasing);

  iarc(terminate, releasing);
}

void create_server( char *server, int no_locks)
{
  PLACE computing;
  PLACE lock_wait, lock_select,
    lock_test;
  TRANS lock_free, lock_locked;
  /* Computing subnet */
  NEW_PLACE(computing, server, "_Computing");

  /* lock requests */
  NEW_PLACE(lock_wait, server, "_lock_wait");
  NEW_PLACE(lock_select,server, "_lock_select");

  NEW_TRANS( lock_test, server, "_lock_test");
  rateval( lock_test, 99.0);
  priority( lock_test, LPRIO);

  iarc( lock_test, lock_wait);
  oarc( lock_test, lock_select);

  /* lock counter manager */
  NEW_PLACE( lock_locked, server, "_locked");
  NEW_PLACE( lock_free, server, "_free");

  init( lock_free, no_locks);
}

int assert()
{
  /* if ( mark("A_Computing") > no_tasks+1 )
     return RES_ERROR; */
  return RES_NOERR;
}

void ac_init() {
	fprintf(stderr,"\nTwo Phase Commit\n\n");
	pr_net_info();
}

void ac_reach() {
	fprintf(stderr,"\nThe reachability graph has been generated\n\n");
	/* pr_rg_info(); */
}

/*
void ac_timing()
{
  fprintf( stderr, "Timing called\n");
}

*/
double	P_Xput() { return(rate("P_Done")); }
double	Q_Xput() { return(rate("Q_Done")); }
double	R_Xput() { return(rate("R_Done")); }
double	S_Xput() { return(rate("S_Done")); }
double	T_Xput() { return(rate("T_Done")); }
double	U_Xput() { return(rate("U_Done")); }
double	V_Xput() { return(rate("V_Done")); }
double	W_Xput() { return(rate("W_Done")); }
double	X_Xput() { return(rate("X_Done")); }
double	Y_Xput() { return(rate("Y_Done")); }
double	Z_Xput() { return(rate("Z_Done")); }

double	F_xput() { return(rate("F_start")); }
double	G_xput() { return(rate("G_start")); }
double	H_xput() { return(rate("H_start")); }

double     A_locked() { return mark("A_locked"); }
double     B_locked() { return mark("B_locked"); }
double     C_locked() { return mark("C_locked"); }
double     D_locked() { return mark("D_locked"); }
double     E_locked() { return mark("E_locked"); }

double     plocked(int i) { return (mark("A_locked") == i ); }
double     p0locked() { return plocked(0); }
double     p1locked() { return plocked(1); }
double     p2locked() { return plocked(2); }
double     p3locked() { return plocked(3); }
double     p4locked() { return plocked(4); }
double     p5locked() { return plocked(5); }
double     p6locked() { return plocked(6); }
double     p7locked() { return plocked(7); }
double     p8locked() { return plocked(8); }
double     p9locked() { return plocked(9); }

void ac_final()
{
  double q, x;

  solve(INFINITY);

  pr_mc_info();
  pr_std_average();

  pr_expected("Steady-state F throughput :", F_xput);
  if ( no_transactions >1 )
    pr_expected("Steady-state G throughput :", G_xput);
  if ( no_transactions >2 )
    pr_expected("Steady-state H throughput :", H_xput);

  pr_expected(" P throughtput :", P_Xput);
  if ( total_tasks > 1 )
    pr_expected(" Q throughtput :", Q_Xput);
  if ( total_tasks > 2 )
    pr_expected(" R throughtput :", R_Xput);
  if ( total_tasks > 3 )
    pr_expected(" S throughtput :", S_Xput);
  if ( total_tasks > 4 )
    pr_expected(" T throughtput :", T_Xput);
  if ( total_tasks > 5 )
    pr_expected(" U throughtput :", U_Xput);
  if ( total_tasks > 6 )
    pr_expected(" V throughtput :", V_Xput);
  if ( total_tasks > 7 )
    pr_expected(" W throughtput :", W_Xput);
  if ( total_tasks > 8 )
    pr_expected(" X throughtput :", X_Xput);
  if ( total_tasks > 9 )
    pr_expected(" Y throughtput :", Y_Xput);
  if ( total_tasks > 10 )
    pr_expected(" Z throughtput :", Z_Xput);

    pr_expected(" A locked :", A_locked);
  if ( no_servers > 1 )
    pr_expected(" B locked :", B_locked);
  if ( no_servers > 2 )
    pr_expected(" C locked :", C_locked);
  if ( no_servers > 3 )
    pr_expected(" D locked :", D_locked);
  if ( no_servers > 4 )
    pr_expected(" E locked :", E_locked);

  /* output ( " Lock distribution on A"); */
  pr_expected("  0 :", p0locked);
  pr_expected("  1 :", p1locked);
  pr_expected("  2 :", p2locked);
  pr_expected("  3 :", p3locked);
  pr_expected("  4 :", p4locked);
  pr_expected("  5 :", p5locked);
  pr_expected("  6 :", p6locked);
  pr_expected("  7 :", p7locked);
  pr_expected("  8 :", p8locked);
  pr_expected("  9 :", p9locked);
}

double Prate()
{
  return task_done_rate(0);
}
double Qrate()
{
  return  task_done_rate(1);
}
double Rrate()
{
  return  task_done_rate(2);
}

double Srate()
{
  return  task_done_rate(3);
}
double Trate()
{
  return task_done_rate(4);
}

double Urate()
{
  return  task_done_rate(5);
}

double Vrate()
{
  return  task_done_rate(6);
}

double Wrate()
{
  return  task_done_rate(7);
}

double Xrate()
{
  return task_done_rate(8);
}

double Yrate()
{
  return  task_done_rate(9);
}

double Zrate()
{
  return  task_done_rate(10);
}

double Pgrant()
  {
    return grant(server_names[task_server[0]], task_names[0]);
  }
double Qgrant()
  {
    return grant(server_names[task_server[1]], task_names[1]);
  }
double Rgrant()
  {
    return grant(server_names[task_server[2]], task_names[2]);
  }
double Sgrant()
  {
    return grant(server_names[task_server[3]], task_names[3]);
  }
double Tgrant()
  {
    return grant(server_names[task_server[4]], task_names[4]);
  }
double Ugrant()
  {
    return grant(server_names[task_server[5]], task_names[5]);
  }
double Vgrant()
  {
    return grant(server_names[task_server[6]], task_names[6]);
  }
double Wgrant()
  {
    return grant(server_names[task_server[7]], task_names[7]);
  }
double Xgrant()
  {
    return grant(server_names[task_server[8]], task_names[8]);
  }
double Ygrant()
  {
    return grant(server_names[task_server[9]], task_names[9]);
  }
double Zgrant()
  {
    return grant(server_names[task_server[10]], task_names[10]);
  }

double Prefuse()
  {
    return 1 - Pgrant();
  }
double Qrefuse()
  {
    return 1-Qgrant();
  }
double Rrefuse()
  {
    return 1 - Rgrant();
  }
double Srefuse()
  {
    return 1 - Sgrant();
  }
double Trefuse()
  {
    return 1-Tgrant();
  }
double Urefuse()
  {
    return 1 - Ugrant();
  }
double Vrefuse()
  {
    return 1-Vgrant();
  }
double Wrefuse()
  {
    return 1 - Wgrant();
  }
double Xrefuse()
  {
    return 1-Xgrant();
  }
double Yrefuse()
  {
    return 1 - Ygrant();
  }
double Zrefuse()
  {
    return 1-Zgrant();
  }

int can_Pgrant()
{
  return Pgrant() > 0;
}
int can_Prefuse()
{
  return Prefuse() > 0;
}

int can_Qgrant()
{
  return Qgrant() > 0;
}
int can_Qrefuse()
{
  return Qrefuse() > 0;
}

int can_Rgrant()
{
  return Rgrant() > 0;
}
int can_Rrefuse()
{
  return Rrefuse() > 0;
}

int can_Sgrant()
{
  return Sgrant() > 0;
}
int can_Srefuse()
{
  return Srefuse() > 0;
}

int can_Tgrant()
{
  return Tgrant() > 0;
}
int can_Trefuse()
{
  return Trefuse() > 0;
}

int can_Ugrant()
{
  return Ugrant() > 0;
}
int can_Urefuse()
{
  return Urefuse() > 0;
}


int can_Vgrant()
{
  return Vgrant() > 0;
}
int can_Vrefuse()
{
  return Vrefuse() > 0;
}

int can_Wgrant()
{
  return Wgrant() > 0;
}
int can_Wrefuse()
{
  return Wrefuse() > 0;
}

int can_Xgrant()
{
  return Xgrant() > 0;
}
int can_Xrefuse()
{
  return Xrefuse() > 0;
}

int can_Ygrant()
{
  return Ygrant() > 0;
}
int can_Yrefuse()
{
  return Yrefuse() > 0;
}

int can_Zgrant()
{
  return Zgrant() > 0;
}
int can_Zrefuse()
{
  return Zrefuse() > 0;
}

