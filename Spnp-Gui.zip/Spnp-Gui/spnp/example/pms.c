#include "user.h"
#include <string.h>

#define MAXPHASE 30

static struct initpv {
  double prob;
  int nToken[5];
} initPV[10];

static double pTime[MAXPHASE], failrate[MAXPHASE];
static double reprate[MAXPHASE], coverage[MAXPHASE];

static int upreq[MAXPHASE], downreq[MAXPHASE], numvp[MAXPHASE];

static int TNUM = 4, nPlace = 5, nState = 0, nPhase = 0, ntPhase = 1;

static char sPlace[5][10] = {"P_LPH", "P_UP", "P_DOWN", "P_SPARE", "P_FAIL"};

static int UPREQ, DOWNREQ;

static double phaseTime, NUMVP, FAILRATE, REPRATE, C;

void LoadP(FILE *fp, void *data, int type)
{
  int *iData, idData, i;
  double *fData, fdData;
  char sstr[100], *ptr;

  if (type)
    fData = (double *)data;
  else
    iData = (int *)data;

  while(fgets(sstr, 100, fp)) {
    if (!strncmp(sstr, "default:", 8)) {
      ptr = strchr(sstr, ':');
      if (type)
	sscanf(ptr + 1, "%lf", &fdData);
      else
	sscanf(ptr + 1, "%d", &idData);
      for (i = 0; i < ntPhase; i ++) 
	if (type)
	  fData[i] = fdData;
	else
	  iData[i] = idData;
      continue;
    }
    if (!strncmp(sstr, "end", 3))
      break;
    sscanf(sstr, "%d", &i);
    if ((i >= 0) && (i < ntPhase)) {
      ptr = strchr(sstr, ':');
       if (type)
	sscanf(ptr + 1, "%lf", &fData[i]);
      else
	sscanf(ptr + 1, "%d", &iData[i]);
    }
  }
}

void LoadConfig(char *sModelName)
{
  FILE *fp;
  char sstr[100], *ptr;

  sprintf(sstr, "%s.cfg", sModelName);
  if ((fp = fopen(sstr, "r")) == NULL) {
    perror("Can not Open the Config File");
    exit(1);
  }

  while (fgets(sstr, 100, fp)) {
    if (*sstr == '#' || *sstr == '\n')
      continue;

    if (!strncmp(sstr, "Number of Phase:", 16)) {
      ptr = strchr(sstr, ':');
      sscanf(ptr + 1, "%d", &ntPhase);
      continue;
    }

    if (!strncmp(sstr, "Number of CPU:", 14)) {
      ptr = strchr(sstr, ':');
      sscanf(ptr + 1, "%d", &TNUM);
      continue;
    }

    if (!strncmp(sstr, "Failure Rate:", 13)) {
      LoadP(fp, (void *)failrate, 1);
      continue;
    }

    if(!strncmp(sstr, "Repair Rate:", 12)) {
      LoadP(fp, (void *)reprate, 1);
      continue;
    }

    if(!strncmp(sstr, "Number of Step:", 15)) {
      LoadP(fp, (void *)numvp, 0);
      continue;
    }

    if(!strncmp(sstr, "Coverage:", 9)) {
      LoadP(fp, (void *)coverage, 1);
      continue;
    }

    if(!strncmp(sstr, "Phase Time:", 11)) {
      LoadP(fp, (void *)pTime, 1);
      continue;
    }

    if(!strncmp(sstr, "CPU Requirement:", 15)) {
      LoadP(fp, (void *)upreq, 0);
      continue;
    }

    if(!strncmp(sstr, "CPU Down Cause Fail:", 20)) {
      LoadP(fp, (void *)downreq, 0);
      continue;
    }
  }
  fclose(fp);
}
       
void LoadState(char *sModelName)
{
  FILE *fp;
  char sstr[100], *ptr, nstr[10];
  int i, j, num, np;

  sprintf(sstr, "%s.rg", sModelName);
  if ((fp = fopen(sstr, "r")) == NULL) {
    perror("Can not Open the Output File of Last Phase");
    exit(1);
  }

  while (fgets(sstr, 100, fp)) {
    if (!strncmp(sstr, "_ntanmark", 8)) {
      sscanf(sstr + 11, "%d", &num);
      nState += num;
      continue;
    }
    
    if (!strncmp(sstr, "_nabsmark", 8)) {
      sscanf(sstr + 11, "%d", &num);
      nState += num;
      continue;
    }

    if (!strncmp(sstr, "_nvanmark", 8)) {
      sscanf(sstr + 11, "%d", &num);
      nState += num;
      continue;
    }
    
    if (!strncmp(sstr, "_reachset", 8)) {
      num = nState + 1;
      for (i = 0; i < num; i ++) {
	fgets(sstr, 100, fp);
	if (*sstr == '#')
	  continue;
	sscanf(sstr, "%d", &np);
	ptr = strchr(sstr, '_');
	if (*(++ptr) == 'v') {
	  nState --;
	  continue;
	}
	
	ptr ++;
	for (j = 0; j < nPlace; j ++) {
	  sscanf(ptr, "%s", nstr);
	  if (*nstr == ':')
	    initPV[np].nToken[j] = 0;
	  else
	    sscanf(nstr, "%d", &initPV[np].nToken[j]);
	  ptr = strstr(ptr, nstr);
	  ptr += strlen(nstr);
	}
      }
      break;
    }
  }
  fclose(fp);
}
    
void LoadProb(char *sModelName)
{
  FILE *fp;
  char sstr[100], *ptr, nstr[40], c;
  int i, np;
  double ttime;

  sprintf(sstr, "%s.prb", sModelName);
  if ((fp = fopen(sstr, "r")) == NULL) {
    perror("Can not Open the Output File of Last Phase");
    exit(1);
  }

  while (fgets(sstr, 100, fp)) {
    if (!strncmp(sstr, "_time", 5)) {
      sscanf(sstr + 8, "%lf", &ttime);
      if (ttime != pTime[nPhase - 1])
	continue;
      fgets(sstr, 100, fp);
      np = 0;
      while (fgets(sstr, 100, fp)) {
	ptr = sstr;
	while (1) {
	  sscanf(ptr, "%s", nstr);
	  if (!strlen(nstr))
	    break;
	  sscanf(nstr, "%d%c%lf", &i, &c, &initPV[np].prob);
	  np ++;
	  if (np >= nState)
	    break;
	  ptr = strstr(ptr, nstr);
	  ptr += strlen(nstr);
	  if (ptr - sstr >= strlen(sstr))
	    break;
	  else if (!strstr(ptr, ":"))
	    break;
	}
	if (np >= nState)
	    break;
      }
      break;
    }
  }
  fclose(fp);
}

void LoadPhaseParameter(char *sPhase)
{
  char *ptr;
  int n;

  if ((ptr = strchr(modelname, '_')) == NULL) {
    printf("Wrong Model Name.\n");
    exit(1);
  }
 
  sscanf(ptr + 1, "%d", &n);
  nPhase = n;
  strncpy(sPhase, modelname, ptr - modelname);
  *(sPhase + (ptr - modelname)) = '\0';

  LoadConfig(sPhase);

  phaseTime = pTime[n];
  UPREQ = upreq[n];
  DOWNREQ = downreq[n];
  FAILRATE = failrate[n];
  REPRATE = reprate[n];
  C = coverage[n];
  NUMVP = (double)numvp[n];

  if (n) {
    sprintf(sPhase + (ptr - modelname), "_%d", n - 1);
  }
}

void options() {
  char LastPhase[20];
  
  iopt(IOP_TSMETHOD,VAL_TSUNIF); 
  iopt(IOP_PR_FULL_MARK,VAL_YES);
/*  iopt(IOP_ELIMINATION, VAL_REDAFTERRG); */
  iopt(IOP_OK_TRANS_M0, VAL_YES);
  iopt(IOP_OK_VAN_M0, VAL_YES);
  iopt(IOP_OK_VANLOOP, VAL_YES);
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC);
  iopt(IOP_PR_MC_ORDER,VAL_TOFROM);
  iopt(IOP_PR_MC,VAL_YES);
  iopt(IOP_PR_PROB,VAL_YES);
  iopt(IOP_MC,VAL_CTMC);
  iopt(IOP_PR_RSET,VAL_YES);
  iopt(IOP_PR_RGRAPH,VAL_YES);
  iopt(IOP_ITERATIONS,20000);
  fopt(FOP_ABS_RET_M0,0.0);
  fopt(FOP_PRECISION,0.00000001);

  LoadPhaseParameter(LastPhase);
  if(nPhase) {
    LoadState(LastPhase);
    LoadProb(LastPhase);
  }
  
}

int GFRec()
{
  if (mark("P_UP") < UPREQ)
    return 1;
  else
    return 0;
}

int GFShutdown()
{
  if (mark("P_UP") > UPREQ)
    return 1;
  else
    return 0;
}

int GFSysfail()
{
  if (mark("P_DOWN") >= DOWNREQ)
    return 1;
  else
    return 0;
}

int GFSysfailu()
{
  if ((mark("P_DOWN") >= DOWNREQ) && (mark("P_UP") > 0))
    return 1;
  else
    return 0;
}

int VFUp()
{
  return mark("P_UP");
}

int VFDown()
{
  return mark("P_DOWN");
}

double RFSysDown()
{
  if (mark("P_FAIL"))
    return 0.0;
  else
    return 1.0;
}

void SetInitProb(int nph)
{
  int i, j;
  char tstr[20];

  if (nph) {
    for (i = 0; i < nState; i ++) {
      if (initPV[i].prob < 0.00000001)
	continue;
      sprintf(tstr, "IT_IP%d", i);
      imm(tstr);
      probval(tstr, initPV[i].prob);
      miarc(tstr, "P_LPH", TNUM);
      for (j = 0; j < nPlace; j ++) 
	if (initPV[i].nToken[j])
	  moarc(tstr, sPlace[j], initPV[i].nToken[j]);
    }
  } else {
    imm("IT_IP");
    probval("IT_IP", 1.0);
    miarc("IT_IP", "P_LPH", TNUM);
    moarc("IT_IP", sPlace[1], TNUM);
  }    
}

void net()
{
  place("P_LPH"); init("P_LPH", TNUM);

  SetInitProb(nPhase);
    
  place("P_UP"); 
  place("P_DOWN"); 
  place("P_SPARE");  
  place("P_FAIL");

  ratedep("T_FAIL", FAILRATE, "P_UP");
  iarc("T_FAIL", "P_UP"); 
  oarc("T_FAIL", "P_DOWN");

  ratedep("T_REPAIR", REPRATE, "P_DOWN");
  iarc("T_REPAIR", "P_DOWN"); 
  oarc("T_REPAIR", "P_UP");

  imm("IT_RECS");
  probval("IT_RECS", C); 
  guard("IT_RECS", GFRec); 
  priority("IT_RECS", 10);
  iarc("IT_RECS", "P_SPARE"); 
  oarc("IT_RECS", "P_UP");

  imm("IT_RECF");
  probval("IT_RECF", 1 - C); 
  guard("IT_RECF", GFRec); 
  priority("IT_RECF", 10); 
  iarc("IT_RECF", "P_SPARE"); 
  oarc("IT_RECF", "P_DOWN");

  imm("IT_SHUTDOWN"); 
  probval("IT_SHUTDOWN", 1); 
  guard("IT_SHUTDOWN", GFShutdown); 
  priority("IT_SHUTDOWN", 10);
  iarc("IT_SHUTDOWN", "P_UP"); 
  oarc("IT_SHUTDOWN", "P_SPARE");

  imm("IT_SYSFAIL1");  
  probval("IT_SYSFAIL1", 1); 
  guard("IT_SYSFAIL1", GFSysfailu); 
  priority("IT_SYSFAIL1", 100);
  viarc("IT_SYSFAIL1", "P_UP", VFUp); 
  voarc("IT_SYSFAIL1", "P_FAIL", VFUp);

  imm("IT_SYSFAIL2"); 
  probval("IT_SYSFAIL2", 1); 
  guard("IT_SYSFAIL2", GFSysfail); 
  priority("IT_SYSFAIL2", 10);
  viarc("IT_SYSFAIL2", "P_DOWN", VFDown); 
  voarc("IT_SYSFAIL2", "P_FAIL", VFDown);  
}

int assert() {
  return(RES_NOERR);
}

void ac_init() {
  pr_net_info(); /* information on the net structure */
}

void ac_reach() {
  pr_rg_info(); /* information on the reachability graph */
}

void
ac_final() {
  double ttime, tstep = phaseTime / NUMVP;

  for (ttime = 0; ttime <= phaseTime; ttime += tstep) {
    solve(ttime);
    pr_expected("System Fail", RFSysDown);
  }
  solve(phaseTime);
  pr_mc_info(); 
  pr_std_average(); /* default measures */
}

  






