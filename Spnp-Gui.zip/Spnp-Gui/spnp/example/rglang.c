/* rglang.c */

#include	"sysinclude.h"
#include	"port.h"
#include	"const.h"
#include	"type.h"
#include	"var.h"
#include	"options.h"
#include	"lexical.h"
#include	"utility.h"
#include	"rglang.h"

# define	RGKEYS	15

static	char	*RGTable[RGKEYS] = {	/* the possible keywords */
		"_t",
		"_a",
		"_v",
		"_l",
		"_nplace",
		"_ntrans",
		"_places",
		"_transitions",
		"_ntanmark",
		"_nabsmark",
		"_nvanmark",
		"_nvanloop",
		"_nentries",
		"_reachset",
		"_reachgraph" };
/* It is used to look up the keywords read by the lexical analyzer. */

/*************************************************************************
Parses the reachability graph file read from "ff".
"full_mark" tells whether the format of the marking is full format or not. */

int		RgParse(FILE *ff, int full_mark)
{
	int	Token,col,row,tr;
	int	pl,tk;
	double	val;
	EE	*auxee;
	/* initialize "Chrd", "Line", "Table", "Nkeyword" */
	Chrd = getc(ff);
	Line = 1;
	Table = RGTable;
	Nkeyword = RGKEYS;
	for (;;) {
		Token = Lex(ff);
		/* check if it is the end of the file */
	SKLEX:	if (Token == L_EOF)	/* input is not complete: error */
			return(RES_ERROR);
		/* check if token after first keyword of statement is '=' */
		if (Lex(ff) != L_EQUAL) {
			sprintf(Msg,"line %d, missing '='",Line);
			LogMsg(MSG_EXIT,Msg);
		}
		/* case on the type of statement */
		switch (Token) {
		case R_nplace:
		case R_ntrans:
		case R_ntanmark:
		case R_nabsmark:
		case R_nvanmark:
		case R_nvanloop:
		case R_nentries:
			if (Lex(ff) != L_NUMBER)
				E_specexp(Table[Token]);
			break;
		case R_places:
		case R_transitions:
	/* for the moment the info is not used */
			for (; (Token = Lex(ff)) == L_NUMBER;) {
				if (Lex(ff) != L_COLON)
					E_charexp(':');
				if (Lex(ff) != L_STRING)
					E_specexp("name");
				if (Lex(ff) != L_SEMICOLON)
					E_charexp(';');
			}
			goto SKLEX;
		case R_reachset:
			for (; (Token = Lex(ff)) == L_NUMBER;) {
				switch (Lex(ff)) {
				case R_T:
				case R_A:
				case R_V:
				case R_L:
					/* ignore markings */
					if (full_mark == VAL_YES) {
						for (pl = 0; pl < Nplace; pl++)
							switch (Token = Lex(ff)) {
							case L_NUMBER:
								if ((tk = Vdouble) < 0 || tk > MAX_TOKEN)
									E_valerr("token");
								break;
							case L_COLON:
								break;
							default:
								E_specexp("token");
							}
					} else {
						while (Lex(ff) != L_SEMICOLON);
					}
					continue;
				default:
					E_specexp("markingtype");
				}
			}
			goto SKLEX;
		case R_reachgraph:
			while ((Token = Lex(ff)) == L_NUMBER) {
				row = Vdouble;
				while ((Token = Lex(ff)) != L_SEMICOLON) {
					if (Token != L_NUMBER)
						 E_specexp("marking");
					col = Vdouble;
					if (Lex(ff) != L_COLON)
						 E_charexp(':');
					if (Lex(ff) != L_NUMBER)
						 E_specexp("transition");
					tr = Vdouble;
					if (Lex(ff) != L_COLON)
						 E_charexp(':');
					if ((Token = Lex(ff)) != L_NUMBER && Token != L_FLOAT)
						 E_specexp("rate/prob");
					val = Vdouble;
					auxee = get_EE();
					auxee->row.pt = Qrow[row];
					auxee->value = val;
					auxee->tr = tr;
					auxee->col.ind = col;
					Qrow[row] = auxee;
				}
			}
			return(RES_NOERR);
		default:
			E_unknown(Buffer);
		} /* end of switch */
		/* check wheter the statement is closed by a ';' */
		Token = Lex(ff);
		if (Token != L_SEMICOLON)
			E_charexp(';');
	} /* end of for(;;) */
} /* RgParse */
