#include <stdio.h>
#include "user.h"

 
/* prototype reward functions */ 
  double netup () ; 
 

void options() {
  iopt(IOP_PR_RGRAPH,VAL_NO) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_NO) ;
  iopt(IOP_USENAME,VAL_NO) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_NO) ;
  iopt(IOP_PR_MC_ORDER,VAL_FROMTO) ;
  /* NUMERICAL SOLUTION chosen */ 
  iopt(IOP_SENSITIVITY,VAL_NO) ;
  iopt(IOP_MC,VAL_CTMC) ;
  iopt(IOP_SSMETHOD,VAL_SSSOR) ;
  iopt(IOP_TSMETHOD,VAL_FOXUNIF) ;
  iopt(IOP_ITERATIONS,2000) ;
  fopt(FOP_PRECISION,0.000001) ;
  fopt(FOP_ABS_RET_M0,0.0) ;
  iopt(IOP_CUMULATIVE,VAL_YES) ;
  iopt(IOP_SSDETECT,VAL_YES) ;
  iopt(IOP_OK_ABSMARK,VAL_NO) ;
  iopt(IOP_OK_VANLOOP,VAL_NO) ;
  iopt(IOP_OK_TRANS_M0,VAL_YES) ;
  iopt(IOP_OK_VAN_M0,VAL_YES) ;
  iopt(IOP_ELIMINATION,VAL_REDONTHEFLY) ;
} 


/* REWARD Functions */ 
double netup () {
  return( mark("UP") ? 1.0 : 0.0 );
}

void net() {
  /*  PLACE  */
  place("UP") ;
  init("UP",1) ;
  place("DOWN") ;
  place("repair") ;
  /*  TRANSITION  */
  trans("rp_1");   rateval("rp_1",0.01) ;
  trans("fault");   rateval("fault",0.00001) ;
  trans("rp_2");   rateval("rp_2",0.01) ;
  /*  ARC  */
  iarc("fault","UP") ;
  oarc("fault","DOWN") ;
  iarc("rp_1","DOWN") ;
  oarc("rp_1","repair") ;
  iarc("rp_2","repair") ;
  oarc("rp_2","UP") ;
} 

int assert() { 
  return(RES_NOERR);
}

void ac_init() { 

}

void ac_reach() { 

}

void ac_final() { 
 FILE *results;
 double t,Ass;

 results = fopen("results","w");
 solve(INFINITY);
 Ass = expected(netup);
 solve(0.0);
 fprintf(results,"%.0f %e %e %e\n",0.,Ass,1.,1.);
 for(t=100.; t<= 5000.; t += 100.) {
    solve(t);
    fprintf(results,"%.of %e %e %e\n",t,Ass,expected(netup),cum_expected(netup)/t);
 }
 fclose(results);
}

