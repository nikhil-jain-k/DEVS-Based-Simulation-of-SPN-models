	/* 
	*	Created from the <CentralServer.c> model, this model file
	*	exercises the SYMBOLIC SENSITIVITY ANALYSIS features of 
	*	SPNP v5 by Robert Jones, NASA Langley Research Center,
	*	Hampton, VA.  email: r.l.jones.iii@larc.nasa.gov
	*
	*	created Dec 12, 1996 by Rob Jones
	*/

	# include "user.h"

	#define DEFAULT   0
	#define REWARD    1
	#define ABSORBING 2

	int whichone = DEFAULT;

	double	q0 = 0.1;
	double	q1 = 0.3;
	double	q2 = 0.6;

	double	thinktime = 1;
	double	CPUrate = 0.01;
	double	rate1 = 0.04;
	double	rate2 = 0.05;

	int TK;

	void options() {
		iopt(IOP_SSDETECT,VAL_YES);
		iopt(IOP_SSMETHOD,VAL_SSSOR);
		iopt(IOP_TSMETHOD,VAL_FOXUNIF);
		iopt(IOP_SENSITIVITY,VAL_YES);
		iopt(IOP_CUMULATIVE,VAL_YES);
		iopt(IOP_PR_MARK_ORDER,VAL_CANONIC);
		iopt(IOP_PR_MC_ORDER,VAL_TOFROM);
		iopt(IOP_PR_MC,VAL_NO);
		iopt(IOP_PR_DERMC,VAL_NO);
		iopt(IOP_PR_PROB,VAL_NO);
		iopt(IOP_PR_DOT,VAL_NO);
		iopt(IOP_MC,VAL_CTMC);
		iopt(IOP_PR_RSET,VAL_NO);
		iopt(IOP_USENAME,VAL_YES);
		iopt(IOP_PR_RGRAPH,VAL_NO);
		iopt(IOP_PR_FULL_MARK,VAL_YES);
		iopt(IOP_ITERATIONS,100000);
		fopt(FOP_ABS_RET_M0,0.0);
		fopt(FOP_PRECISION,1e-9);

		TK = input("Number of customers");

		whichone = input("0) default, 1) reward, 2) absorbing");
	 	if (whichone < 0 || whichone > 2) whichone = DEFAULT;	
	}

	void net() {
		parm("exit_prob");
		parm("out1_prob");
		parm("out2_prob");
		parm("lambda");
		parm("theta");

		place("think"); 			
		/*trans("go"); */  			ratedep("go",1.0/thinktime,"think");
							useparm("go", "theta");

		iarc("go","think");			oarc("go","CPU");
		place("CPU");				

		/*trans("CPUdone");	*/		rateval("CPUdone", 1.0); 
							useparm("CPUdone", "lambda"); 

		iarc("CPUdone","CPU");			oarc("CPUdone","decide");
		place("decide");

		imm("exit"); 		 
							probval("exit",1.0); 
							priority("exit",3);
							useparm("exit", "exit_prob");

		imm("out1"); 				probval("out1",1.0);
							priority("out1",3); 
							useparm("out1", "out1_prob");

		imm("out2"); 				probval("out2",1.0);
							priority("out2",3); 
							useparm("out2", "out2_prob");

		iarc("exit","decide");		oarc("exit","think");
		iarc("out1","decide");		oarc("out1","use1");
		iarc("out2","decide");		oarc("out2","use2");
		place("use1");
		place("use2");
		/*trans("done1"); */			rateval("done1",1.0/rate1);
							useparm("done1", "theta");
		/*trans("done2"); */			rateval("done2",1.0/rate2);
							useparm("done2", "theta");

		iarc("done1","use1");		oarc("done1","CPU");
		iarc("done2","use2");		oarc("done2","CPU");

		switch (whichone) {
		case REWARD:
			init("CPU",TK); 
			break;
		case ABSORBING:
			init("CPU",TK); 
			mharc("go","think",TK);
			break;
		default:
			init("think",TK);
			break;
		}
	}

	int assert() { return(RES_NOERR); }

	void ac_init() 
	{ 
		bind("exit_prob", 0.01);
	        bind("out1_prob", 0.30);
	        bind("out2_prob", 0.69);
	        bind("lambda", 1.0/CPUrate);
	        bind("theta", 1.0);
		pr_net_info(); 
	}

	void ac_reach() 
	{ 
		pr_parms(); 
		pr_rg_info(); 
	}

	double reward0() { return mark("think"); }
	double reward1() { return mark("use1"); }
	double reward2() { return mark("use2"); }

	double reward() 
	{ 
		if (mark("think") == TK) return 0.0;
		else return 1.0;
	}
	double notreward() 
	{ 
		if (mark("think") == TK) return 1.0;
		else return 0.0;
	}

	void pr_measures() 
	{
		pr_expected("tokens in place think", reward0);
		pr_expected("tokens in place use1",  reward1);
		pr_expected("tokens in place use2",  reward2);
	}

	void ac_final() 
	{ 
		/* steady-state analysis */
	        solve(INFINITY);

		pr_mc_info();

	        if (whichone == ABSORBING){
			pr_mtta("thinking in the old way.");
	                pr_newmtta("all thinking new!");
		}
	        else if (whichone == REWARD)
	                pr_mtta_fun("all thinking!", reward);
#if 0
	        pr_std_average(); 
		pr_measures(); 

		/* transient analysis */
		solve(10.0); 
	        pr_std_average(); 
		pr_std_cum_average();
		pr_measures(); 

		/* change values of some parameters */
		bind("lambda", 2.0/CPUrate);

		/* resolve */
		solve(INFINITY); 
	        pr_measures(); 
		solve(10.0); 
	        pr_measures(); 

		/* select only certain parameters for sensitivity analysis */

		/* 
		*  no need to call solve(time) again, all pr_xxx functions 
		*  use most recent time--in this case time = 10.0
		*/
		sens("exit_prob","out1_prob","out2_prob",(char *)0);
	        pr_std_average(); 

		/* turn sensitivity analysis off! */
		sens((char *)0);
	        pr_std_average(); 

		/* turn sensitivity analysis back on for all parameters */
		sens(ALL,(char *)0);
	        pr_std_average(); 
#endif
		/* done */
	}




