/***************************************************************************
 * SPNP Simulator
 * Supervisor: Dr. Ciardo,  ciardo@cs.wm.edu
 * Author: gli@cs.wm.edu
 * Department of Computer Science, College of William & Mary
 ***************************************************************************/
 

/* Main Modifications   */
/* September 99:   BT         normal distribution added */
#include "sysinclude.h"
#include "port.h"
#include "const.h"
#include "type.h"
#include "var.h"
#include "options.h"
#include "utility.h"
#include "net.h"
#include "cspl.h"
#include "conf.h"
#include "sim.h"
#include "splaytree.h"
#include "randfunction.h"

/* global variable for simulation  */

IMM_type   *IMMtran;
event_type *tran;
trans_node *translist;

double *inevent, *presample,*workmem;
int    *transkeep,*placekeep,*fplacekeep;
ME     new_me, *Currmark;

double clk = 0.0;                  /* clock used by simulator */
double last_clk = 0.0;		   /* used in collecting stat */
double clkmax;                     /* Maximum simulation time */
 
int fire_node;

extern double conf_percent;
extern double relative_err;

extern  long r_seed;

/* defined stat for accumulating data */
struct {
	double *avg_tokens, *nonempty;            /* average number of tokens in each place */
	double *avg_level, *fnonempty;            /* average level of each fluid place  */   
	double *enabled;
	int   *throughput;
	double *user;
        int   *events;
} stat;


SPTREE      splaytree;
IMMQUE      IMM_que;
expect_link expect_list;

/****************************************************************
 * Signal Handler, in case interupted during simulation         *
 ****************************************************************/
void sim_int()
{
       sprintf(Msg,"Interrupt Caught. Panic Dump Results to outfile. \n");
       LogMsg(MSG_ERROR,Msg);
       LogState(MSG_ERROR,&new_me);
       analyze_stat();
       free_sim_mem();
       exit(1);
}


/* create some data space for stat collecting - only run once per simulation */
void stat_initialize()
{
  int i;

  expect_list.pr_expected = NULL;
  expect_list.pr_cum_expected = NULL;

  ac_final();

  /* initialize stat */	  
  stat.nonempty = (double *)malloc(sizeof(double) * Nplace);
  stat.avg_tokens = (double *)malloc(sizeof(double) * Nplace);
  stat.avg_level  = (double *)malloc(sizeof(double) *FNplace);
  stat.fnonempty  = (double *)malloc(sizeof(double) *FNplace);
  stat.enabled = (double *)malloc(sizeof(double) * Ntrans);
  stat.throughput = (int *)malloc(sizeof(int) * Ntrans);
  stat.user = (double *)malloc(sizeof(double) * expect_list.number);
  stat.events = (int *)malloc(sizeof(int));
  new_me.mk = malloc(sizeof(PP) * Nplace);
  new_me.fmk=malloc(sizeof(FPP)*FNplace);
  new_me.ratea=malloc(sizeof(FPP)*FNplace);
  new_me.rateb=malloc(sizeof(FPP)*FNplace);

  tran=(event_type *)malloc(sizeof(event_type)*Ntrans);

  IMMtran=(IMM_type *)malloc(sizeof(IMM_type)*Ntrans);

  inevent   = (double *)malloc(sizeof(double) * Ntrans);
  presample = (double *)malloc(sizeof(double) * Ntrans);
  workmem   = (double *)malloc(sizeof(double) * Ntrans); 
  transkeep=(int *)malloc(sizeof(int)*Ntrans);
  placekeep=(int *)malloc(sizeof(int)*Nplace);
  fplacekeep=(int *)malloc(sizeof(int)*FNplace);
  translist=malloc(sizeof(trans_node)*Ntrans);

  for(i=0;i<Ntrans;i++) {
    tran[i].trans_index=i;
    IMMtran[i].trans_index=i;
    translist[i].place=NULL;
    translist[i].trans=NULL;
    translist[i].fplace=NULL;
  }
}

/*  Initialize globals - once per run */
void initialize()
{
  int i;

  IMM_que.front=NULL;
  IMM_que.rear=NULL;
  IMM_que.number=0;

  last_clk = clk = 0.0;

  /* initialize set for sim */
  for (i = 0; i < Ntrans; i++) {
    inevent[i]=0; presample[i]=-1;workmem[i]=0;
  }

  splaytree.root=NULL;

  for (i = 0; i < Nplace; i++)  new_me.mk[i] = Arrplace[i].initial;
  for (i = 0; i < FNplace;i++)  {
    new_me.fmk[i]=FArrplace[i].initial;
    new_me.ratea[i]=0;
    new_me.rateb[i]=0;
  }  

  Currmark = &new_me;

  /* initialize stat to 0 for each run */
  for (i = 0; i < Nplace; i++) stat.avg_tokens[i] = stat.nonempty[i] = 0.0;
  for (i = 0; i < Ntrans; i++) {
       stat.enabled[i] = 0.0;
       stat.throughput[i] = 0;
  }

  for (i = 0; i <= expect_list.number; i++)  stat.user[i] = 0.0;

  stat.events[0]=0;
}

void batchinitialize()
{
  int i;

  /* reinitialize set for sim */
  for (i = 0; i < Ntrans; i++) {
      presample[i]=-1;workmem[i]=0;
      if (inevent[i] !=0) {tran[i].time -= clk;IMMtran[i].time -=clk;}
  }

  /* initialize stat to 0 for each run */
  for (i = 0; i < Nplace; i++) stat.avg_tokens[i] = stat.nonempty[i] = 0.0;
  for (i = 0; i < Ntrans; i++) {
       stat.enabled[i] = 0.0;
       stat.throughput[i] = 0;
  }

  for (i = 0; i <= expect_list.number; i++)
       stat.user[i] = 0.0;

  stat.events[0]=0;
  last_clk = clk=0;
}

/* reduces the time searching for every transition, check only related 
   each list in the arry represents all transitions that share a common
   place as either input or output: places related and transitions related 
   tothe fire node 
*/
void make_correspondence_list()
{int	lp, lt;
 int	i,type,redundent,pol;
 int    number; 
 
 trans_type *transnode,*tmp;
 index_node *placenode,*temp;

 for (lt = 0; lt < Ntrans; lt++) {
   transnode=malloc(sizeof(trans_type));
   transnode->index=lt;
   transnode->type=0;
   transnode->next=NULL;
   translist[lt].trans = transnode;
 }

 for (lt = 0; lt < Ntrans; lt++) {

   if(Arrtrans[lt].type == DIS_CON && Arrtrans[lt].val == INFINITY) continue;

   number=0;
   for (lp = 0; lp< Nplace; lp++) {
     if ((Arrtrans[lt].inp && Arrtrans[lt].inp[lp])||
	 (Arrtrans[lt].vin && Arrtrans[lt].inp[lp]==VARIABLE)) {
       /* found out the input places related with transition lt */
       redundent=0;temp=translist[lt].place;
       while( temp!=NULL && !redundent) {
	 if (temp->index == lp) redundent=1;
	 temp=temp->next;
       }
       if (!redundent) {
	 placenode=(index_node *)malloc(sizeof(index_node));
	 placenode->index=lp;
	 temp = translist[lt].place;
	 translist[lt].place=placenode;
	 placenode->next=temp;      
       }

       for (i = 0; i < Ntrans; i++) {
	 type=3;
	 pol=0;
	 if (i==lt) continue;
	 if (Arrtrans[i].guard_ptr ) type=2; 
	 else if (Arrtrans[i].inp[lp] ) type=1;                    /* Enable to Disable */
	 else if (Arrtrans[i].inh&&Arrtrans[i].inh[lp] ) type=0;   /* Disable to Enable */       

	 if ((Arrtrans[i].type == DIS_EXP)||(Arrtrans[i].type == DIS_GEO)) {
	   if ( !Arrtrans[i].affect[lt] || Arrtrans[i].affect[lt] == PRD) {
	     if (Arrtrans[i].dep==DEP_MK) pol=PRD;
	     else if (Arrtrans[i].dep==DEP_PL && Arrtrans[i].pl == lp) pol=PRD;
	   }
	 } else {
	   if ( !Arrtrans[i].affect[lt] || Arrtrans[i].affect[lt] == PRS) pol=0;
	   else pol=Arrtrans[i].affect[lt];
	 }

	 if (pol > 0 || type != 3) {	    
	   redundent=0;
	   tmp = translist[lt].trans->next;
	   while (tmp ) {
	     if (tmp->index == i) {
	       if (tmp->type !=type) tmp->type=2;
	       redundent = 1;
	       break;
	     }
	     tmp=tmp->next;
	   }

	   /* add node */
	   if (!redundent) {
	     tmp = malloc(sizeof(trans_type));
	     tmp->index = i;
	     tmp->type=type;
	     tmp->policy=pol;
	     tmp->next = translist[lt].trans->next;
	     translist[lt].trans->next = tmp;
	   }
	 }
       }
     }

     if ((Arrtrans[lt].out && Arrtrans[lt].out[lp])||
	 (Arrtrans[lt].vou && Arrtrans[lt].out[lp]==VARIABLE)) {    /* outgoing place of it */
       /* check redendence  */
       redundent=0;temp=translist[lt].place;
       while(temp && !redundent) {
	 if (temp->index == lp) redundent=1;
	 temp=temp->next;
       }
       if (!redundent) {
	 placenode=(index_node *)malloc(sizeof(index_node));
	 placenode->index=lp;
	 temp = translist[lt].place;
	 translist[lt].place=placenode;
	 placenode->next=temp;
       }
    
       for (i = 0; i < Ntrans; i++) {
	 type=3;
	 pol=0;
	 if (i == lt) continue;
	 if (Arrtrans[i].guard_ptr ) type =2 ;
	 else if (Arrtrans[i].inh&&Arrtrans[i].inh[lp]) type =1;       /* Enable to Disable  */
	 else if (Arrtrans[i].inp[lp]) type =0;       /* Disable to Enable  */

	 if ((Arrtrans[i].type == DIS_EXP)||(Arrtrans[i].type == DIS_GEO)) {
	   if ( !Arrtrans[i].affect[lt] || Arrtrans[i].affect[lt] == PRD) {
	     if (Arrtrans[i].dep==DEP_MK) pol=PRD;
	     else if (Arrtrans[i].dep==DEP_PL && Arrtrans[i].pl == lp) pol=PRD;
	   }
	 } else {
	   if ( !Arrtrans[i].affect[lt] || Arrtrans[i].affect[lt] == PRS) pol=0;
	   else pol=Arrtrans[i].affect[lt];
	 }

	 if (pol > 0 || type != 3) {	    
	   redundent = 0;

	   tmp = translist[lt].trans->next;
	   while (tmp ) {
	     if (tmp->index == i) {
	       if (tmp->type != type ) tmp->type=2;
	       redundent = 1;
	       break;
	     }
	     tmp=tmp->next;
	   }

	   /* add node */
	   if (!redundent) {
	     tmp = malloc(sizeof(trans_type));
	     tmp->index = i;
	     tmp->type=type;
	     tmp->policy=pol;
	     tmp->next = translist[lt].trans->next;
	     translist[lt].trans->next = tmp;
	   }
	 }
       }
     }
   }
 }
}

/* deal with the IMM transitions */
void add_to_IMMlist(IMM_type *IMM_ptr)
{
  IMM_type *tmp,*temp;
	
  if(inevent[IMM_ptr->trans_index]==0) inevent[IMM_ptr->trans_index]=1;
 
  if (IMM_que.number == 0) {
     IMM_que.front = IMM_ptr;
     IMM_que.rear = IMM_ptr;
     IMM_ptr->next = NULL;
     IMM_ptr->prev = NULL;
  } else if (IMM_ptr->time <= IMM_que.front->time) {
    IMM_que.front->next=IMM_ptr;
    IMM_ptr->prev=IMM_que.front;
    IMM_ptr->next=NULL;
    IMM_que.front=IMM_ptr;
  } else if (IMM_ptr->time > IMM_que.rear->time) {
    IMM_que.rear->prev=IMM_ptr;
    IMM_ptr->next=IMM_que.rear;
    IMM_ptr->prev=NULL;
    IMM_que.rear=IMM_ptr;
  } else {
    tmp=IMM_que.front;
    while (tmp) {
      if (IMM_ptr->time > tmp->time) {
	temp=tmp;
	tmp=tmp->prev;
      }
    }
    tmp->next=IMM_ptr;
    IMM_ptr->prev=tmp;
    IMM_ptr->next=temp;
    temp->prev=IMM_ptr;
  }
 
  IMM_que.number+=1;
}


/* Remove an IMM from the list of IMMs                     */
void remove_from_IMMlist (IMM_type *IMM_ptr)
{
  int i;

  i=IMM_ptr->trans_index;
  inevent[i]=0;
  if (IMM_que.number==0) {
       sprintf(Msg,"Error in remove from empty IMMlist.\n");
       LogMsg(MSG_ERROR,Msg);
       LogState(MSG_ERROR,&new_me);
       analyze_stat();
       free_sim_mem();
       exit(1);
   } else {
     IMM_que.number-=1;
     if(Arrtrans[i].policy == PRS) presample[i]=IMM_ptr->time-clk;

     if (IMM_que.number==0) {
	IMM_que.front = NULL;
	IMM_que.rear = NULL;
     } else {
	if (IMM_ptr == IMM_que.front) {
	   IMM_que.front = IMM_que.front->prev;
	   IMM_que.front->next = NULL;
	} else {
	   if (IMM_ptr == IMM_que.rear) {
	      IMM_que.rear = IMM_que.rear->next;
	      IMM_que.rear->prev = NULL;
	   } else {
	      IMM_ptr->next->prev = IMM_ptr->prev;
	      IMM_ptr->prev->next = IMM_ptr->next;
	   }
	}
     }
   }
}


void emptyIMM_que()
{
  IMM_type *ptr;
  if (IMM_que.number > 0) {
    ptr=IMM_que.front;
    while (ptr) {
      inevent[ptr->trans_index]=0;
      if (Arrtrans[ptr->trans_index].policy==PRS) presample[ptr->trans_index]=ptr->time-clk;
      ptr=ptr->prev;
    }
    IMM_que.front=NULL;
    IMM_que.rear=NULL;
    IMM_que.number=0;
  }
}

void obtain_IMM(IMM_type **IMM_ptr)
{
  IMM_type *tmp;
  double tot_val = 0.0, val = 0.0, pr,time,epsilon;

  if(IMM_que.number == 0) {
       sprintf(Msg,"Error in obtaining from empty IMMlist.\n");
       LogMsg(MSG_ERROR,Msg);
       LogState(MSG_ERROR,&new_me);
       analyze_stat();
       free_sim_mem();
       exit(1);
  } 

  if (IMM_que.number== 1) {
    IMM_que.number=0;
    *IMM_ptr = IMM_que.front;
    inevent[IMM_que.front->trans_index]=0;
    presample[IMM_que.front->trans_index]=-1;
    IMM_que.front=NULL;
    IMM_que.rear=NULL;
  } else {
    tmp = IMM_que.front; time=tmp->time; epsilon=FOptionValue(FOP_TIME_EPSILON);
    while ( tmp ) {
      if (RABS(tmp->time,time)>=epsilon) break;
      if (Arrtrans[tmp->trans_index].prob_dep == DEP_NO)
	tot_val += (workmem[tmp->trans_index] = Arrtrans[tmp->trans_index].prob_val);
      else if (Arrtrans[tmp->trans_index].prob_dep == DEP_PL) {
	tot_val+=(workmem[tmp->trans_index])= 
  Arrtrans[tmp->trans_index].prob_val*(mark(Arrplace[Arrtrans[tmp->trans_index].prob_pl].name));
      }
      else if (Arrtrans[tmp->trans_index].prob_dep == DEP_MK)
	tot_val+=(workmem[tmp->trans_index] = (*Arrtrans[tmp->trans_index].prob_fun)());
      tmp= tmp->prev;
    }

    pr = uniform_random();  /* change of BT */

    /* find the transition to fire */
    tmp = IMM_que.front;
    while (tmp) {
      if (RABS(tmp->time,time)>=epsilon ) break;
      val += workmem[tmp->trans_index] / tot_val;
      if (pr <= val) {
	*IMM_ptr = tmp;
	remove_from_IMMlist(tmp);
	break;
      }
      tmp = tmp->prev;
    }
  }
}

/*****************************************************/
/* deal with the continuous time priority queue      */

/* add an event to the event queue                   */
void add_to_eventlist(event_type *event_ptr)
{
  if(inevent[event_ptr->trans_index]==0) inevent[event_ptr->trans_index]=1;
  spenq(event_ptr,&splaytree);
}

/* Obtain an event from the head of the event queue            */
void obtain_event (event_type **event_ptr)
{
  if (splaytree.root == NULL) {
       sprintf(Msg,"Error in obtaining from empty event que.\n");
       LogMsg(MSG_ERROR,Msg);
       LogState(MSG_ERROR,&new_me);
       analyze_stat();
       free_sim_mem();
       exit(1);
  }
  else {
     *event_ptr = spdeq(&(splaytree.root)); 
     
     inevent[(*event_ptr)->trans_index]=0;
     presample[(*event_ptr)->trans_index]=-1;
  }
}

/* Remove an event from the heaptree of events                     */
void remove_from_eventlist (event_type *event_ptr)
{

 inevent[event_ptr->trans_index]=0;

 if (Arrtrans[event_ptr->trans_index].policy==PRS)
   presample[event_ptr->trans_index]=event_ptr->time-clk;

 spdelete(event_ptr,&splaytree);
}

void emptysplaytree()
{
 int i;
 for (i=0;i<Ntrans;i++)  
   if(Arrtrans[i].type != DIS_IMM&&Arrtrans[i].type !=DIS_CON && Arrtrans[i].type!=DIS_GEO && Arrtrans[i].type!=DIS_POI) 
     inevent[i]=0;
 splaytree.root=NULL;
}

/* check transition & add/delete event */
void check_and_add(int i)
{
   int  over=0;
   double nexttime, val,val2;

   if (IMM_que.number) {
      if (Arrtrans[IMM_que.front->trans_index].prio > Arrtrans[i].prio) over=1;
   } else if (splaytree.root) {
      if (Arrtrans[splaytree.root->trans_index].prio > Arrtrans[i].prio) over=1;
   }     	
  
   if (!over && InternalEnabled(&Arrtrans[i])) {
     if (IMM_que.number) {
       if (Arrtrans[IMM_que.front->trans_index].prio < Arrtrans[i].prio) emptyIMM_que();
     } else if (Arrtrans[i].type != DIS_IMM && splaytree.root) { 	 
       if (Arrtrans[splaytree.root->trans_index].prio < Arrtrans[i].prio) emptysplaytree();
     }
      switch (Arrtrans[i].type) {
         case DIS_IMM :
	    if (Arrtrans[i].val <= 0) {
	      sprintf(Msg,"Warning: Non-Positive Prob in transition %s.\n", Arrtrans[i].name);
	      LogMsg(MSG_ERROR,Msg);
	      return;
	     }
             nexttime=clk;
	     break;
	    
          case DIS_CON :
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      
	      if (Arrtrans[i].dep == DEP_MK)           inevent[i]=(*Arrtrans[i].fun)();
	      else if (Arrtrans[i].dep == DEP_NO)      inevent[i]=Arrtrans[i].val;
	      else if (Arrtrans[i].dep == DEP_PL)
	                    inevent[i]=Arrtrans[i].val*mark(Arrplace[Arrtrans[i].pl].name);
	      nexttime=clk+inevent[i];
	      presample[i]=inevent[i];
	    }
       	    break;
      
          case DIS_UNF:
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      	    
	      if (Arrtrans[i].dep == DEP_MK){
	        val=(*Arrtrans[i].fun)();
		val2=(*Arrtrans[i].fun2)();
	      }
	      else if (Arrtrans[i].dep == DEP_NO) {
	        val=Arrtrans[i].val;
		val2=Arrtrans[i].val2;
	      }
	      else if (Arrtrans[i].dep == DEP_PL){
	        val = Arrtrans[i].val * mark(Arrplace[Arrtrans[i].pl].name);	      
	        val2= Arrtrans[i].val2* mark(Arrplace[Arrtrans[i].pl].name);
	      }
	      presample[i]=uniform(val,val2);
	      nexttime=clk+presample[i];
	    }
       	    break;

          case DIS_WEI:
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      	    
	      if (Arrtrans[i].dep == DEP_MK){
	        val=(*Arrtrans[i].fun)();
		val2=(*Arrtrans[i].fun2)();
	      }
	      else if (Arrtrans[i].dep == DEP_NO) {
	        val=Arrtrans[i].val;
		val2=Arrtrans[i].val2;
	      }
	      else if (Arrtrans[i].dep == DEP_PL){
	        val = Arrtrans[i].val * mark(Arrplace[Arrtrans[i].pl].name);	      
	        val2= Arrtrans[i].val2* mark(Arrplace[Arrtrans[i].pl].name);
	      }
	      presample[i]=weibull(val,val2);
	      nexttime=clk+presample[i];
	    }
       	    break;

          case DIS_CAU:
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      	    
	      if (Arrtrans[i].dep == DEP_MK){
	        val=(*Arrtrans[i].fun)();
		val2=(*Arrtrans[i].fun2)();
	      }
	      else if (Arrtrans[i].dep == DEP_NO) {
	        val=Arrtrans[i].val;
		val2=Arrtrans[i].val2;
	      }
	      else if (Arrtrans[i].dep == DEP_PL){
	        val = Arrtrans[i].val * mark(Arrplace[Arrtrans[i].pl].name);	      
	        val2= Arrtrans[i].val2* mark(Arrplace[Arrtrans[i].pl].name);
	      }
	      presample[i]=Cauchy(val,val2);
	      nexttime=clk+presample[i];
	    }
       	    break;

          case DIS_NOM:
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      	    
	      if (Arrtrans[i].dep == DEP_MK){
	        val=(*Arrtrans[i].fun)();
		val2=(*Arrtrans[i].fun2)();
	      }
	      else if (Arrtrans[i].dep == DEP_NO) {
	        val=Arrtrans[i].val;
		val2=Arrtrans[i].val2;
	      }
	      else if (Arrtrans[i].dep == DEP_PL){
	        val = Arrtrans[i].val * mark(Arrplace[Arrtrans[i].pl].name);	      
	        val2= Arrtrans[i].val2* mark(Arrplace[Arrtrans[i].pl].name);
	      }
	      presample[i]=truncated_norm(val,val2);
	      nexttime=clk+presample[i];
	    }
       	    break;

          case DIS_GAM:
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      	    
	      if (Arrtrans[i].dep == DEP_MK){
	        val=(*Arrtrans[i].fun)();
		val2=(*Arrtrans[i].fun2)();
	      }
	      else if (Arrtrans[i].dep == DEP_NO) {
	        val=Arrtrans[i].val;
		val2=Arrtrans[i].val2;
	      }
	      else if (Arrtrans[i].dep == DEP_PL){
	        val = Arrtrans[i].val * mark(Arrplace[Arrtrans[i].pl].name);	      
	        val2= Arrtrans[i].val2* mark(Arrplace[Arrtrans[i].pl].name);
	      }
	      presample[i]=Gamma(val,val2);
	      nexttime=clk+presample[i];
	    }
       	    break;

          case DIS_BET:
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      	    
	      if (Arrtrans[i].dep == DEP_MK){
	        val=(*Arrtrans[i].fun)();
		val2=(*Arrtrans[i].fun2)();
	      }
	      else if (Arrtrans[i].dep == DEP_NO) {
	        val=Arrtrans[i].val;
		val2=Arrtrans[i].val2;
	      }
	      else if (Arrtrans[i].dep == DEP_PL){
	        val = Arrtrans[i].val * mark(Arrplace[Arrtrans[i].pl].name);	      
	        val2= Arrtrans[i].val2* mark(Arrplace[Arrtrans[i].pl].name);
	      }
	      presample[i]=Beta(val,val2);
	      nexttime=clk+presample[i];
	    }
       	    break;


         case DIS_ERL:
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      	    
	      if (Arrtrans[i].dep == DEP_MK){
	        val=(*Arrtrans[i].fun)();
		val2=(*Arrtrans[i].fun2)();
	      }
	      else if (Arrtrans[i].dep == DEP_NO) {
	        val=Arrtrans[i].val;
		val2=Arrtrans[i].val2;
	      }
	      else if (Arrtrans[i].dep == DEP_PL){
	        val = Arrtrans[i].val * mark(Arrplace[Arrtrans[i].pl].name);	      
	        val2= Arrtrans[i].val2* mark(Arrplace[Arrtrans[i].pl].name);
	      }
	      presample[i]=erlang(val,(int)val2);
	      nexttime=clk+presample[i];
	    }
       	    break;

         case DIS_PAR:
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      	    
	      if (Arrtrans[i].dep == DEP_MK){
	        val=(*Arrtrans[i].fun)();
		val2=(*Arrtrans[i].fun2)();
	      }
	      else if (Arrtrans[i].dep == DEP_NO) {
	        val=Arrtrans[i].val;
		val2=Arrtrans[i].val2;
	      }
	      else if (Arrtrans[i].dep == DEP_PL){
	        val = Arrtrans[i].val * mark(Arrplace[Arrtrans[i].pl].name);	      
	        val2= Arrtrans[i].val2* mark(Arrplace[Arrtrans[i].pl].name);
	      }
	      presample[i]=Pareto(val,val2);
	      nexttime=clk+presample[i];
	    }
       	    break;

          case DIS_LOG :
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      	    
	      if (Arrtrans[i].dep == DEP_MK){
	        val=(*Arrtrans[i].fun)();
		val2=(*Arrtrans[i].fun2)();
	      }
	      else if (Arrtrans[i].dep == DEP_NO) {
	        val=Arrtrans[i].val;
		val2=Arrtrans[i].val2;
	      }
	      else if (Arrtrans[i].dep == DEP_PL){
	        val = Arrtrans[i].val * mark(Arrplace[Arrtrans[i].pl].name);	      
	        val2= Arrtrans[i].val2* mark(Arrplace[Arrtrans[i].pl].name);
	      }
	      presample[i]=lognorm(val,val2);
	      nexttime=clk+presample[i];
	    }
       	    break;

	  case DIS_EXP :
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      
	      if (Arrtrans[i].dep == DEP_MK)  inevent[i]=(*Arrtrans[i].fun)();
	      else if (Arrtrans[i].dep == DEP_NO) inevent[i]=Arrtrans[i].val;
	      else if (Arrtrans[i].dep == DEP_PL) 
	                    inevent[i]=Arrtrans[i].val*mark(Arrplace[Arrtrans[i].pl].name);
	    
	      presample[i]=expon(inevent[i]);
	      nexttime=clk+presample[i];
	    }
       	    break;

	  case DIS_GEO :
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      
	      if (Arrtrans[i].dep == DEP_MK) {
		inevent[i]=(*Arrtrans[i].fun)(); 
		val2=(*Arrtrans[i].fun2)();
	      }
	      else if (Arrtrans[i].dep == DEP_NO) {
		inevent[i]=Arrtrans[i].val;
		val2=Arrtrans[i].val2;
	      }
	      else if (Arrtrans[i].dep == DEP_PL) { 
		inevent[i]=Arrtrans[i].val*mark(Arrplace[Arrtrans[i].pl].name);
		val2=Arrtrans[i].val2*mark(Arrplace[Arrtrans[i].pl].name);
	      }
	      presample[i]=geometry(inevent[i])*val2;
	      nexttime=clk+presample[i];
	    }
       	    break;

	  case DIS_POI :
	    if (Arrtrans[i].policy==PRS && presample[i]>=0) nexttime=clk+presample[i];
	    else if(Arrtrans[i].policy==PRI && presample[i]) nexttime=clk+presample[i];
	    else {      
	      if (Arrtrans[i].dep == DEP_MK) {
		inevent[i]=(*Arrtrans[i].fun)(); 
		val2=(*Arrtrans[i].fun2)();
	      }
	      else if (Arrtrans[i].dep == DEP_NO) {
		inevent[i]=Arrtrans[i].val;
		val2=Arrtrans[i].val2;
	      }
	      else if (Arrtrans[i].dep == DEP_PL) { 
		inevent[i]=Arrtrans[i].val*mark(Arrplace[Arrtrans[i].pl].name);
		val2=Arrtrans[i].val2*mark(Arrplace[Arrtrans[i].pl].name);
	      }
	      presample[i]=Poisson(inevent[i])*val2;
	      nexttime=clk+presample[i];
	    }
       	    break;

	  case DIS_NOVAL:
	    InternalAssert(0,"Distribution not defined");
	    break;

         default:
	   InternalAssert(0,"Distribution not implemented yet");
	   break;
	}
      if (nexttime >= clk) {
        tran[i].time=nexttime;
	if (Arrtrans[i].type==DIS_IMM || Arrtrans[i].type==DIS_CON || Arrtrans[i].type==DIS_GEO || Arrtrans[i].type==DIS_POI ) {
	  IMMtran[i].time=nexttime;
	  add_to_IMMlist(&IMMtran[i]);
	} else {
	  tran[i].time=nexttime;
	  add_to_eventlist(&tran[i]);
	}
      } else {inevent[i]=INFINITY ;      /* enabled and firing time INFINITY  */}
   }
} 


void check_and_deq(int i)
{
  if (!InternalEnabled(&Arrtrans[i])) {
    if(Arrtrans[i].type==DIS_CON && inevent[i]==INFINITY) inevent[i]=0;
    else if(Arrtrans[i].type==DIS_IMM||Arrtrans[i].type==DIS_CON||Arrtrans[i].type==DIS_POI||Arrtrans[i].type==DIS_GEO) remove_from_IMMlist(&IMMtran[i]);
    else remove_from_eventlist(&tran[i]);
  }
}

void check_and_mdy(int i)
{
  double val,val2,sample;
  int pol;

  val=Arrtrans[i].val;val2=Arrtrans[i].val2;
  pol=Arrtrans[i].affect[fire_node];  
  
  switch (Arrtrans[i].type) {
  case DIS_EXP:
    val=inevent[i];
    if (pol==PRD) {
      if (Arrtrans[i].dep == DEP_MK)     val=(*Arrtrans[i].fun)();
      else if(Arrtrans[i].dep == DEP_PL) val=Arrtrans[i].val*mark(Arrplace[Arrtrans[i].pl].name);
   
      if (val!=inevent[i]) {
	sample=expon(val);
	remove_from_eventlist(&tran[i]);
	tran[i].time=clk+sample;
	inevent[i]=val;
	presample[i]=sample;
	add_to_eventlist(&tran[i]);
      }
    } 
    break;

  case DIS_GEO:
    val=inevent[i];
    if (pol==PRD) {
      if (Arrtrans[i].dep == DEP_MK) {
	val=(*Arrtrans[i].fun)();
	val2=(*Arrtrans[i].fun2)();
      }
      else if(Arrtrans[i].dep == DEP_PL) {
	val=Arrtrans[i].val*mark(Arrplace[Arrtrans[i].pl].name);
	val2=Arrtrans[i].val2*mark(Arrplace[Arrtrans[i].pl].name);
      }

      if (val!=inevent[i]) {
	sample=geometry(val)*val2;
	remove_from_IMMlist(&IMMtran[i]);
	tran[i].time=clk+sample;
        IMMtran[i].time=clk+sample; /*change of BT */
	inevent[i]=val;
	presample[i]=sample;
	add_to_IMMlist(&IMMtran[i]);
      }
    } 
    break;

  case DIS_POI:
    val=inevent[i];
    if (pol==PRD) {
      if (Arrtrans[i].dep == DEP_MK) {
	val=(*Arrtrans[i].fun)();
	val2=(*Arrtrans[i].fun2)();
      }
      else if(Arrtrans[i].dep == DEP_PL) {
	val=Arrtrans[i].val*mark(Arrplace[Arrtrans[i].pl].name);
	val2=Arrtrans[i].val2*mark(Arrplace[Arrtrans[i].pl].name);
      }
      sample=Poisson(val)*val2;
      remove_from_IMMlist(&IMMtran[i]);
      tran[i].time=clk+sample;
      IMMtran[i].time=clk+sample; /*change of BT */
      inevent[i]=val;
      presample[i]=sample;
      add_to_IMMlist(&IMMtran[i]);
    }
    if (pol==PRI) {
      if (tran[i].time != (clk+presample[i])) {
	remove_from_IMMlist(&IMMtran[i]);
	tran[i].time=clk+presample[i];
        IMMtran[i].time=clk+presample[i]; /*change of BT */
        inevent[i]=val;
	add_to_IMMlist(&IMMtran[i]);
      }      
    }
    break;

  case DIS_CON:
    if (pol==PRD) {
      if (Arrtrans[i].dep==DEP_MK) val=(*Arrtrans[i].fun)();
      else if(Arrtrans[i].dep == DEP_PL) val=Arrtrans[i].val*mark(Arrplace[Arrtrans[i].pl].name);
   
      if (val != inevent[i]) {
	remove_from_IMMlist(&IMMtran[i]);
	tran[i].time=clk+val;
        IMMtran[i].time=clk+val;
	inevent[i]=val;
	presample[i]=val;
	add_to_IMMlist(&IMMtran[i]);
      }
    }
    if (pol==PRI) {
      if (tran[i].time != (clk+presample[i])) {
	remove_from_IMMlist(&IMMtran[i]);
	tran[i].time=clk+presample[i];
        IMMtran[i].time=clk+presample[i];  /*change of BT */
	add_to_IMMlist(&IMMtran[i]);
      }
    }
    break;

  case DIS_UNF:
    if (pol == PRD) {
      if (Arrtrans[i].dep==DEP_MK) {val=(*Arrtrans[i].fun)();val2=(*Arrtrans[i].fun2)();}
      else if(Arrtrans[i].dep == DEP_PL) {
	val=val*mark(Arrplace[Arrtrans[i].pl].name);
	val2=val2*mark(Arrplace[Arrtrans[i].pl].name);
      }

      sample=uniform(val,val2);
      remove_from_eventlist(&tran[i]);
      tran[i].time=clk+sample;
      inevent[i]=1;
      presample[i]=sample;
      add_to_eventlist(&tran[i]);
    }
    if (pol==PRI) {
      if (tran[i].time != (clk+presample[i])) {
	remove_from_eventlist(&tran[i]);
	tran[i].time=clk+presample[i];
	add_to_eventlist(&tran[i]);
      }      
    }
    break;

  case DIS_BET:
    if (pol == PRD) {
      if (Arrtrans[i].dep==DEP_MK) {val=(*Arrtrans[i].fun)();val2=(*Arrtrans[i].fun2)();}
      else if(Arrtrans[i].dep == DEP_PL) {
	val=val*mark(Arrplace[Arrtrans[i].pl].name);
	val2=val2*mark(Arrplace[Arrtrans[i].pl].name);
      }

      sample=Beta(val,val2);
      remove_from_eventlist(&tran[i]);
      tran[i].time=clk+sample;
      inevent[i]=1;
      presample[i]=sample;
      add_to_eventlist(&tran[i]);
    }
    if (pol==PRI) {
      if (tran[i].time != (clk+presample[i])) {
	remove_from_eventlist(&tran[i]);
	tran[i].time=clk+presample[i];
	add_to_eventlist(&tran[i]);
      }      
    }
    break;

  case DIS_GAM:
    if (pol == PRD) {
      if (Arrtrans[i].dep==DEP_MK) {val=(*Arrtrans[i].fun)();val2=(*Arrtrans[i].fun2)();}
      else if(Arrtrans[i].dep == DEP_PL) {
	val=val*mark(Arrplace[Arrtrans[i].pl].name);
	val2=val2*mark(Arrplace[Arrtrans[i].pl].name);
      }

      sample=Gamma(val,val2);
      remove_from_eventlist(&tran[i]);
      tran[i].time=clk+sample;
      inevent[i]=1;
      presample[i]=sample;
      add_to_eventlist(&tran[i]);
    }
    if (pol==PRI) {
      if (tran[i].time != (clk+presample[i])) {
	remove_from_eventlist(&tran[i]);
	tran[i].time=clk+presample[i];
	add_to_eventlist(&tran[i]);
      }      
    }
    break;

  case DIS_LOG:
    if (pol == PRD) {
      if (Arrtrans[i].dep==DEP_MK) {val=(*Arrtrans[i].fun)();val2=(*Arrtrans[i].fun2)();}
      else if(Arrtrans[i].dep == DEP_PL) {
	val=val*mark(Arrplace[Arrtrans[i].pl].name);
	val2=val2*mark(Arrplace[Arrtrans[i].pl].name);
      }

      sample=lognorm(val,val2);
      remove_from_eventlist(&tran[i]);
      tran[i].time=clk+sample;
      inevent[i]=1;
      presample[i]=sample;
      add_to_eventlist(&tran[i]);
    }
    if (pol==PRI) {
      if (tran[i].time != (clk+presample[i])) {
	remove_from_eventlist(&tran[i]);
	tran[i].time=clk+presample[i];
	add_to_eventlist(&tran[i]);
      }      
    }
    break;

  case DIS_NOM:
    if (pol == PRD) {
      if (Arrtrans[i].dep==DEP_MK) {val=(*Arrtrans[i].fun)();val2=(*Arrtrans[i].fun2)();}
      else if(Arrtrans[i].dep == DEP_PL) {
	val=val*mark(Arrplace[Arrtrans[i].pl].name);
	val2=val2*mark(Arrplace[Arrtrans[i].pl].name);
      }

      sample=truncated_norm(val,val2);
      remove_from_eventlist(&tran[i]);
      tran[i].time=clk+sample;
      inevent[i]=1;
      presample[i]=sample;
      add_to_eventlist(&tran[i]);
    }
    if (pol==PRI) {
      if (tran[i].time != (clk+presample[i])) {
	remove_from_eventlist(&tran[i]);
	tran[i].time=clk+presample[i];
	add_to_eventlist(&tran[i]);
      }      
    }
    break;

  case DIS_ERL:
    if (pol == PRD) {
      if (Arrtrans[i].dep==DEP_MK) {val=(*Arrtrans[i].fun)();val2=(*Arrtrans[i].fun2)();}
      else if(Arrtrans[i].dep == DEP_PL) {
	val=val*mark(Arrplace[Arrtrans[i].pl].name);
	val2=val2*mark(Arrplace[Arrtrans[i].pl].name);
      }

      sample=erlang(val,(int)val2);
      remove_from_eventlist(&tran[i]);
      tran[i].time=clk+sample;
      inevent[i]=1;
      presample[i]=sample;
      add_to_eventlist(&tran[i]);
    }
    if (pol==PRI) {
      if (tran[i].time != (clk+presample[i])) {
	remove_from_eventlist(&tran[i]);
	tran[i].time=clk+presample[i];
	add_to_eventlist(&tran[i]);
      }      
    }
    break;

 case DIS_PAR:
    if (pol == PRD) {
      if (Arrtrans[i].dep==DEP_MK) {val=(*Arrtrans[i].fun)();val2=(*Arrtrans[i].fun2)();}
      else if(Arrtrans[i].dep == DEP_PL) {
	val=val*mark(Arrplace[Arrtrans[i].pl].name);
	val2=val2*mark(Arrplace[Arrtrans[i].pl].name);
      }

      sample=Pareto(val,val2);
      remove_from_eventlist(&tran[i]);
      tran[i].time=clk+sample;
      inevent[i]=1;
      presample[i]=sample;
      add_to_eventlist(&tran[i]);
    }
    if (pol==PRI) {
      if (tran[i].time != (clk+presample[i])) {
	remove_from_eventlist(&tran[i]);
	tran[i].time=clk+presample[i];
	add_to_eventlist(&tran[i]);
      }      
    }
    break;

  case DIS_WEI :
    if (pol == PRD) {
      if (Arrtrans[i].dep==DEP_MK) {val=(*Arrtrans[i].fun)();val2=(*Arrtrans[i].fun2)();}
      else if(Arrtrans[i].dep == DEP_PL) {
	val=val*mark(Arrplace[Arrtrans[i].pl].name);
	val2=val2*mark(Arrplace[Arrtrans[i].pl].name);
      }

      sample=weibull(val,val2);
      remove_from_eventlist(&tran[i]);
      tran[i].time=clk+sample;
      inevent[i]=1;
      presample[i]=sample;
      add_to_eventlist(&tran[i]);
    }
    if (pol==PRI) {
      if (tran[i].time != (clk+presample[i])) {
	remove_from_eventlist(&tran[i]);
	tran[i].time=clk+presample[i];
	add_to_eventlist(&tran[i]);
      }      
    }
    break;

  case DIS_CAU :
    if (pol == PRD) {
      if (Arrtrans[i].dep==DEP_MK) {val=(*Arrtrans[i].fun)();val2=(*Arrtrans[i].fun2)();}
      else if(Arrtrans[i].dep == DEP_PL) {
	val=val*mark(Arrplace[Arrtrans[i].pl].name);
	val2=val2*mark(Arrplace[Arrtrans[i].pl].name);
      }

      sample=Cauchy(val,val2);
      remove_from_eventlist(&tran[i]);
      tran[i].time=clk+sample;
      inevent[i]=1;
      presample[i]=sample;
      add_to_eventlist(&tran[i]);
    }
    if (pol==PRI) {
      if (tran[i].time != (clk+presample[i])) {
	remove_from_eventlist(&tran[i]);
	tran[i].time=clk+presample[i];
	add_to_eventlist(&tran[i]);
      }      
    }
    break;

  case DIS_IMM:
    break;

  case DIS_NOVAL:
    InternalAssert(0,"Distribution not defined");
    break; 

  default:
    InternalAssert(0,"Distribution not implemented");
  }
}

/* search the fluid place see if one fluid event will encount */

double schedule_fevent()
{ int lp,i;
  TR *auxtr;
  double ratea,rateb,levels,bound,time, end,EVENTTIME=INFINITY;
  FBK *tmp;

  for (lp=0;lp<FNplace;lp++) {

    /* calculate the new flow rate for each fluid place */
    ratea=0;
    rateb=0;

    for (i=0;i<Ntrans;i++) {
      if (inevent[i]){
	auxtr=&Arrtrans[i];
	ratea-=((auxtr->finr[lp] ==INFINITY)?(*(auxtr->fvina[lp]))():0);
	ratea+=((auxtr->foutr[lp]==INFINITY)?(*(auxtr->fvoua[lp]))():0);
	rateb-=((auxtr->finr[lp] ==INFINITY)?(*(auxtr->fvinb[lp]))():auxtr->finr[lp]);
	rateb+=((auxtr->foutr[lp]==INFINITY)?(*(auxtr->fvoub[lp]))():auxtr->foutr[lp]);
      }
    }
    new_me.ratea[lp]=ratea; new_me.rateb[lp]=rateb;
    levels=new_me.fmk[lp]; bound=FArrplace[lp].bound;
    if (levels==0 && rateb<0) {new_me.rateb[lp]=rateb=0;new_me.ratea[lp]=ratea=0;}
    if (levels==bound && ratea*levels+rateb >0) {new_me.rateb[lp]=rateb=0;new_me.ratea[lp]=ratea=0;}
    if (ratea==0){
      time=INFINITY;
      tmp=FArrplace[lp].fbreak;
      if (rateb >0 ) {
	end=0;
	while (tmp && end==0) {
	  if ( tmp->val<= levels+FOptionValue(FOP_FLUID_EPSILON)) tmp=tmp->next;  /* BT */
	  else end=tmp->val;
	}
	if (end==0) end=bound;
	if (end==INFINITY) time=INFINITY;  /*BT */
	else time=(end-levels)/rateb;
      }
      if (rateb<0) { 
	end=INFINITY;
	while(tmp && end<levels) {
	  if (tmp->val < levels-FOptionValue(FOP_FLUID_EPSILON)) { end=tmp->val; tmp=tmp->next;} /* BT */
	  else tmp=NULL;
	}
	if (end==INFINITY) end=0;
	time=(end-levels)/rateb;
      }
      if (EVENTTIME==INFINITY) {EVENTTIME=time;}
      else if (time != INFINITY && EVENTTIME > time) EVENTTIME=time;
    }else if (ratea > 0) {
      tmp=FArrplace[lp].fbreak;   /* BT */
      if (levels + rateb/ratea > 0) {
	end=0;
	while (tmp && end==0) {
	  if ( tmp->val<= levels+FOptionValue(FOP_FLUID_EPSILON)) tmp=tmp->next;  /* BT */
	  else end=tmp->val;
	}
	if (end==0) end=bound;
	if (end==INFINITY) time=INFINITY;  /*BT */
	else time=log((end+rateb/ratea)/(levels+rateb/ratea))/ratea;
      }
      if (levels+rateb/ratea < 0) { 
	end=INFINITY;
	while(tmp && end<levels) {
	  if (tmp->val < levels-FOptionValue(FOP_FLUID_EPSILON)) { end=tmp->val; tmp=tmp->next;} /* BT */
	  else tmp=NULL;
	}
	if (end==INFINITY) end=0;
	time=log((end+rateb/ratea)/(levels+rateb/ratea))/ratea;
      }
      if (EVENTTIME==INFINITY) {EVENTTIME=time;}
      else if (time != INFINITY && EVENTTIME > time) EVENTTIME=time;
    }else if(ratea < 0) {
      tmp=FArrplace[lp].fbreak;  /* BT */
      if (levels + rateb/ratea < 0) {
	end=0;
	while (tmp && end==0) {
	  if ( tmp->val<= (levels+FOptionValue(FOP_FLUID_EPSILON))) tmp=tmp->next;  /* BT */
	  else end=tmp->val;
	}
	if (end==0) end=bound;
	if (end==INFINITY || end>=-rateb/ratea) time=INFINITY;  /*BT */
	else time=log((end+rateb/ratea)/(levels+rateb/ratea))/ratea;
      }
      if (levels+rateb/ratea > 0) { 
	end=INFINITY;
	while(tmp && end<levels) {
	  if (tmp->val < levels-FOptionValue(FOP_FLUID_EPSILON)) { end=tmp->val; tmp=tmp->next;} /*BT */
	  else tmp=NULL;
	}
	if (end==INFINITY) end=0;
        if (end <= -rateb/ratea) time=INFINITY;  /*BT */
	else time=log((end+rateb/ratea)/(levels+rateb/ratea))/ratea;
      }
      if (EVENTTIME==INFINITY) {EVENTTIME=time;}
      else if (time != INFINITY && EVENTTIME > time) EVENTTIME=time;
    }
  }
  return(EVENTTIME==INFINITY? INFINITY:EVENTTIME+clk);
}

/* Search the Arrtrans array see if there is a transition ready */
void schedule_trans(int order)
{
  int   i,number;

  SetCurrentState(Currmark);

  if (order == 0)  for (i = 0; i < Ntrans; i++)  check_and_add(i); /* regular transitions */
  else {
    if (fire_node < 0) {   
      for(i=0;i<Ntrans;i++) {
	if (inevent[i]>0) check_and_deq(i);
	if (inevent[i]==0) check_and_add(i);
      }
    } else {    
      trans_type	*ptr;
      ptr = translist[fire_node].trans;
      number=0;
      while (ptr ) {
	switch(ptr->type) {
	case 0:
	  if ( inevent[ptr->index] == 0)  	check_and_add(ptr->index);
	  else if (ptr->policy) check_and_mdy(ptr->index);
	  break;

	case 1:    
	  if (inevent[ptr->index])  check_and_deq(ptr->index);
	  if (inevent[ptr->index] && ptr->policy) check_and_mdy(ptr->index);
	  break;

	case 2:
	  if (inevent[ptr->index] == 0)   check_and_add(ptr->index);
	  else {
	    check_and_deq(ptr->index);
	    if (inevent[ptr->index] && ptr->policy) check_and_mdy(ptr->index);
	  }
	  break;

	case 3:
	  if (inevent[ptr->index] && ptr->policy) check_and_mdy(ptr->index) ;
	  break;

	}
	ptr = ptr->next;
      }
    }
  }
}

/* Return the state reached from state "&new_me" when "tr" occurs.
It assumes that "tr" is enabled in "&new_me".  It checks the assertion. */
ME *ReachState_Sim(EVENT tr)
{
 int     i,lp;
 double  tk,ratea,rateb;
 TR      *auxtr;
 index_node *tmp;

 SetCurrentState(&new_me);

 for (lp=0;lp<FNplace;lp++) { 
     tk=new_me.fmk[lp];
     if (new_me.ratea[lp] == 0) tk += new_me.rateb[lp]*(clk-last_clk);   
     else {
       ratea=new_me.ratea[lp];
       rateb=new_me.rateb[lp];
       tk=-1*rateb/ratea+(tk+rateb/ratea)*exp(ratea*(clk-last_clk));
     }
     
     if (tr >=0 ) {
       auxtr=&Arrtrans[tr];
       tk-=((auxtr->finp[lp]==VARIABLE)?(*(auxtr->fvin[lp]))():auxtr->finp[lp]);
       tk+=((auxtr->fout[lp]==VARIABLE)?(*(auxtr->fvou[lp]))():auxtr->fout[lp]);
     }
     new_me.fmk[lp]=tk;
     if (FArrplace[lp].bound >= 0 && (tk >(FArrplace[lp].bound+FOptionValue(FOP_FLUID_EPSILON)))) {
       sprintf(Msg,"level overflow in fluid place %s",
	       FArrplace[lp].name);
       LogMsg(MSG_ERROR,Msg);
       LogState(MSG_ERROR,&new_me);
       return(NULL);
     }
 }

 if (tr>=0){ 

    auxtr = &Arrtrans[tr];

    tmp=translist[tr].place;
    while (tmp!=NULL) {
        i=tmp->index;
	tk = new_me.mk[i];
	tk -= ((auxtr->inp[i] == VARIABLE)?(*(auxtr->vin[i]))():auxtr->inp[i]);
	tk += ((auxtr->out[i] == VARIABLE)?(*(auxtr->vou[i]))():auxtr->out[i]);
	if (tk > MAX_TOKEN) {
	   sprintf(Msg,"token overflow in place %s: when %s fires",
	   Arrplace[i].name,Arrtrans[tr].name);
	   LogMsg(MSG_ERROR,Msg);
	   LogState(MSG_ERROR,&new_me);
	   return(NULL);
	}
	InternalAssert(tk >= 0 && tk <= MAX_TOKEN,"Illegal number of tokens");
	placekeep[i]=tk;
	tmp=tmp->next;
    }
    tmp=translist[tr].place;
    while (tmp !=NULL) {
      i=tmp->index;
      new_me.mk[i]=placekeep[i];
      tmp=tmp->next;
    }
 }

 SetCurrentState(NULL);  
 Currmark = &new_me;	  
 return(&new_me);
}

/* collect statistics about the net */
void collect_stat()
{
 expect_type *ptr;
 int i;
 if(IOptionValue(IOP_SIM_STD_REPORT)==VAL_YES) {
   stat.events[0]+=1;
   if (IOptionValue(IOP_SIM_CUMULATIVE)==VAL_YES ) {		     
     for (i = 0; i < Nplace; i++) {
       stat.nonempty[i] += (new_me.mk[i] ? (clk - last_clk) : 0.0);
       stat.avg_tokens[i] += (new_me.mk[i] * (clk - last_clk));
     }
     for (i = 0; i < Ntrans; i++)
       if (i==fire_node || inevent[i]!=0 ) stat.enabled[i] += (clk-last_clk);
     if ((fire_node >= 0) && (clk<clkmax)) stat.throughput[fire_node]++;
   }
 }

 /* user measures */
 
 if (expect_list.number) {
    ptr=expect_list.pr_cum_expected;
    while (ptr) {
       stat.user[ptr->index] += (*(ptr->func))() * (clk - last_clk);
       ptr = ptr->next; 
    }
    ptr=expect_list.pr_expected;
 }
}


/* free up memory space */
void free_sim_mem()
{
	int	i;
	trans_type *ptr, *dis;
	index_node *pptr,*ptmp;

	for (i = 0; i < Ntrans; i++) {
		ptr = translist[i].trans;
		while (ptr != NULL) {
			dis = ptr;
			ptr = ptr->next;
			free(dis);
		}
	}
	for (i=0;i<Ntrans;i++) {
	  pptr=translist[i].place;
	  while(pptr) {
	    ptmp=pptr;
	    pptr=pptr->next;
	    free(ptmp);
	  }
	}

	free(translist);
	free(new_me.mk);
	free(stat.nonempty);
	free(stat.avg_tokens);
	free(stat.enabled);
	free(stat.throughput);
	free(stat.user);
	free(tran);
	free(translist);
	free(transkeep);
	free(placekeep);
}

/* collect the data for confidence interval    */
void conf_data()
{
  expect_type *ptr;
  int i;

  data(EVENTS, 0, (double) stat.events[0]);
  if (IOptionValue(IOP_SIM_CUMULATIVE)==VAL_YES) {
     for (i = 0; i < Nplace; i++) {
	 data(NONEMPTY, i, (double) stat.nonempty[i] / clk);
	 data(TOKENS, i, stat.avg_tokens[i] / clk);
     }
     
     for (i = 0; i < Ntrans; i++) {
	 data(ENABLED, i, stat.enabled[i] / clk);
	 data(THROUGHPUT, i, (double) stat.throughput[i] / clk);
     }
  }
  else {	
     for (i = 0; i < Nplace; i++) {
	 data(NONEMPTY, i, (double)(new_me.mk[i] ? 1 : 0));
	 data(TOKENS, i, (double) new_me.mk[i]);
     }
     for (i = 0; i < Ntrans; i++) {
         data(ENABLED, i, (double) (InternalEnabled(&Arrtrans[i]) ? 1 : 0));
	 data(THROUGHPUT, i, 0.0);
     }
  }

  /* either way, process user measures at the end */
  if (expect_list.number) {
    ptr=expect_list.pr_expected;
    while (ptr) {
      data(USER_MEASURE, ptr->index, (double) stat.user[ptr->index]);
      ptr=ptr->next;
    }
    ptr=expect_list.pr_cum_expected;
    while (ptr) {
      data(USER_MEASURE,ptr->index,(double)stat.user[ptr->index]/clk);
      ptr=ptr->next;
    }
  }
}



/* main simulation function */
void simulate()
{
	static	int	flagPrint;
	static	int notYetAsked = VAL_YES;
	event_type *event_ptr;
	IMM_type   *IMM_ptr;  
	double ftime;
        int over,iteration,it;
	
	signal(SIGINT, sim_int);
        
        if((it = IOptionValue(IOP_SIM_SEED))>=0) r_seed=it;
	else r_seed=123456789;

	stat_initialize();

	clkmax = FOptionValue(FOP_SIM_LENGTH);
	if (clkmax == 0.0) {
	  sprintf(Msg,"No simulation length specified.\n Using fopt(FOP_SIM_LENGTH, time);\n");
	  LogMsg(MSG_ERROR,Msg);
	  exit(1);
	}

	conf_percent = FOptionValue(FOP_SIM_CONFIDENCE);

	if ((conf_percent != (double)(.9))  && 
	    (conf_percent != (double)(.95)) && 
	    (conf_percent != (double)(.99))) {
	  sprintf(Msg,"Warning: Default confidence vocerage 0.95 used. \n");
	  LogMsg(MSG_ERROR,Msg);
	  conf_percent = .95;
	}
	
	if ((it = IOptionValue(IOP_SIM_RUNS)) <= 0) {
	  it = -1;
	  relative_err = FOptionValue(FOP_SIM_ERROR);
	  if ((relative_err <= 0.0) || (relative_err >= 1.0)) {
	    sprintf(Msg,"Warning: relative error incorrect, using run until 5%% error\n");
	    LogMsg(MSG_ERROR,Msg);
	    relative_err = .05;
	  }
	}

	if (!assert()) {
	  sprintf(Msg,"Error: assert() returns in initial marking.\n");
	  LogMsg(MSG_ERROR,Msg);
	  exit(1);
	}

	initialize();
	make_correspondence_list();		

	schedule_trans(0);

	ftime=schedule_fevent();
       	for (iteration = 0; iteration < ((it==-1) ? (enough_run(iteration) ? 0:(iteration+1)):it);
	     iteration++) {

	  if (iteration > MAX_RUN) {
	    sprintf(Msg,"Warning:Exceeding MAX_RUN iterations, terminating !\n");
	    LogMsg(MSG_ERROR,Msg);
	    break;
	  }

	  while((clkmax==INFINITY?1:(clk < clkmax))&&(splaytree.root||IMM_que.number>0||ftime>0)) {
	    over=0;
	    if (IMM_que.number ) {
	      obtain_IMM(&IMM_ptr);
	      if (Arrtrans[IMM_ptr->trans_index].type == DIS_IMM) over=1;
	      else {
		over=2;
		if (ftime > 0) over=(IMM_ptr->time < ftime)? 2:3 ;
		if (over==3) add_to_IMMlist(IMM_ptr);
		if (splaytree.root) {
		  obtain_event(&event_ptr);
		  if (over==2) {
		    over=(event_ptr->time < IMM_ptr->time)? 4:2;
		    if (over==4) add_to_IMMlist(IMM_ptr);
		    if (over==2) add_to_eventlist(event_ptr);
		  }
		  if (over==3) {
		    over=(event_ptr->time < ftime)? 4:3;
		    if (over==3) add_to_eventlist(event_ptr);
		  }	 
		}
	      }
	    } else if (splaytree.root) {
	      obtain_event(&event_ptr);
	      if (ftime>0 && ftime<event_ptr->time) {over=3; add_to_eventlist(event_ptr);}
	      else over=4;
	    } else over=3;
	    if (over==2||over==1) {
	      fire_node = IMM_ptr->trans_index;
	      clk = (clkmax > IMM_ptr->time) ? IMM_ptr->time:clkmax;
	      collect_stat();
	      ReachState_Sim(IMM_ptr->trans_index);
	    }
	    else if (over==3) {
	      fire_node=-1;
	      clk=(clkmax > ftime) ? ftime : clkmax;
	      collect_stat();
	      if (clk < clkmax) ReachState_Sim(-1);
	    } else if (over==4) {
	      fire_node = event_ptr->trans_index;
	      clk = (clkmax > event_ptr->time) ? event_ptr->time:clkmax;
	      collect_stat();
	      if (clk < clkmax) ReachState_Sim(event_ptr->trans_index);
	      else add_to_eventlist(event_ptr);
	    }
	    if (clk < clkmax ) {
	      schedule_trans(1);
	      ftime=schedule_fevent();
	      last_clk=clk;
	    }	      
	  }

	  if (!assert()) {
	    sprintf(Msg,"Error: assert() returns error in new marking. \n");
	    LogMsg(MSG_ERROR,Msg);
	    LogState(MSG_ERROR,&new_me);
	    analyze_stat();
	    free_sim_mem();
	    exit(1);
	  }

	  conf_data();

	  if (clkmax==INFINITY?0:(clk < clkmax)) {
	    sprintf(Msg,"Warning: No more transition in event queue. \n");
	    LogMsg(MSG_ERROR,Msg);
	    clk = (clkmax==INFINITY?clk:clkmax);
	  }
	  if (notYetAsked == VAL_YES) {
	    fprintf(stderr,"Do you want verbose?\n");
	    flagPrint = getanswer();
	    notYetAsked = VAL_NO;
	  }
	  if (flagPrint == VAL_YES)  pr_run_stat(iteration);
	  
	  if (IOptionValue(IOP_SIM_RUNMETHOD)==VAL_BATCH) batchinitialize();
	  else {
	    initialize();		
	    schedule_trans(0);
	    ftime=schedule_fevent();		
	  }	
	}
	analyze_stat();
	free_sim_mem();
}


/* print out the statistical data for each run */
void pr_run_stat(int pr_iteration)
{int i;

  printf("\n\nNo. of RUNS = %d\t", pr_iteration+1);
  printf("Finishing clock = % .1E\n", clk);
  if (IOptionValue(IOP_SIM_CUMULATIVE)==VAL_YES ) {
    printf("Places\n");
    printf("               Name     Nonempty  tokens\n");
    for (i = 0; i < Nplace; i++) {
      printf("%20s\t%.5f\t%.5f\n",Arrplace[i].name,stat.nonempty[i]/clk,stat.avg_tokens[i]/clk);
    }

    printf("\n\nTransitions\n");
    printf("              Name      Enabled Throughput\n");
    for (i = 0; i < Ntrans; i++) {
      printf("%20s\t%.5f\t%.5f\n",
		                    Arrtrans[i].name,
                                    stat.enabled[i]/clk,
                                    ((double)stat.throughput[i])/clk);
    }
  }
}

















