/*   22 Aug., 2000

                   
    Programmed by :  BRUNO TUFFIN
*-----------------------------------------------------------------------*/

/*
        Example for the test library of simulation.
*/


#include       "user.h" 

int c1,c2,c3,c4;


options() {

        fopt(FOP_ABS_RET_M0, 0.0);   /*rate from absorb. marking to in */
        fopt(FOP_PRECISION,0.00000001);	/* minimum precision */
        iopt(IOP_SIMULATION,VAL_YES);
	iopt(IOP_SIM_RUNMETHOD,VAL_BATCH);
        iopt(IOP_SIM_CUMULATIVE,VAL_YES);
        iopt(IOP_SIM_STD_REPORT,VAL_YES);

	iopt(IOP_SIM_SEED,345983453);
        iopt(IOP_SIM_RUNS,5000);
        fopt(FOP_SIM_ERROR,0.1);
        fopt(FOP_SIM_LENGTH,40.0);
        fopt(FOP_SIM_CONFIDENCE,.95);


}

double mean1() {return(mark("PA1")+mark("PB1")+mark("PC1"));}

double fuprin() {return(0.95*mark("Up"));}
double fdnrin() {return(0.95*mark("Down"));}
double f21() 
 { double val;
   c4=fcondition("Two",F_GT,0);
   c1=fcondition("One",F_LT,1.0);
   val=c4 ? (c1 ? 0.1 :(0.05)) : 0;
   return (val);
 }
double fout() 
 { c4=fcondition("Two",F_GT,0);
   c2=fcondition("One",F_GT,0); 
   return (c4 ? 1.0: (c2? 1.0: 0.95)); 
 }

double fl1() { return(0.1);}
double fl2() { return(0.1);}

int gstop() {c3=fcondition("Two",F_EQ,2.0); return(c3*mark("Down"));}
int gstart(){return(mark("Up"));}

int multip() { return 2;}
int multiph() { return 8;}

double fun_prob() { return(0.5);}
double parameter_fun1() { return((double) mark("PA1"));}
double parameter_fun2() { return((double) mark("PA2"));}
double parameter_fun3() { return((double) mark("PA3"));} 
double parameter_fun3_1() { return(0.0);}
double parameter_fun4() { return(0.3);} 
double parameter_fun4_1() { return(1.0);}
double parameter_fun5() { return(1.5);} 
double parameter_fun5_1() { return(1.5);}
double parameter_fun6() { return((double) mark("PA6"));} 
double parameter_fun6_1() { return(1.5);}
double parameter_fun7() { return((double) mark("PA7"));} 
double parameter_fun7_1() { return(1.5);}
double parameter_fun8() { return((double) mark("PA8"));} 
double parameter_fun8_1() { return(1.5);}
double parameter_fun9() { return((double) mark("PA9"));}  
double parameter_fun9_1() { return(1.5);}
double parameter_fun10() { return(1.0);} 
double parameter_fun10_1() { return(1.5);}
double parameter_fun11() { return((double) mark("PA11"));} 
double parameter_fun11_1() { return(0.3);}
double parameter_fun11_2() { return(1.0);}
double parameter_fun12() { return(1.5);} 
double parameter_fun12_1() { return(0.3);} 
double parameter_fun12_2() { return(0.3);}
double parameter_fun13() { return((double) mark("PA13"));} 
double parameter_fun13_1() { return(1.0);} 
double parameter_fun13_2() { return(0.5);}
double parameter_fun14() { return(3.0);}  
double parameter_fun14_1() { return(0.3);} 
double parameter_fun14_2() { return(1.6);} 
double parameter_fun14_3() { return(1.0);}
double parameter_fun15() { return(3.0);} 
double parameter_fun15_1() { return((double) mark("PA15"));}
double parameter_fun16() { return((double) mark("PA16"));} 
double parameter_fun16_1() { return(3.0);}
double parameter_fun17() { return((double) mark("PA17"));} 
double parameter_fun17_1() { return(3.0);}
double parameter_fun18() { return((double) mark("PA18"));} 
double parameter_fun18_1() { return((double) 1.5*mark("PA18"));} 
double parameter_fun18_2() { return((double) 2*mark("PA18"));}
double parameter_fun19() { return(1.0);} 
double parameter_fun19_1() { return(1.0);} 
double parameter_fun19_2() { return(0.5);}
double parameter_fun20() { return((double) mark("PA20"));}
double parameter_fun20_1() { return(0.7);} 

int guard_fun1() { 
        if (mark("PC1")>=1) return(1); else return(0);
}
int guard_fun2() { 
        if (mark("PC2")>=1) return(1); else return(0);
}
int guard_fun3() { 
        if (mark("PC3")>=1) return(1); else return(0);
}
int guard_fun4() { 
        if (mark("PC4")>=1) return(1); else return(0);
}
int guard_fun5() { 
        if (mark("PC5")>=1) return(1); else return(0);
}
int guard_fun6() { 
        if (mark("PC6")>=1) return(1); else return(0);
}
int guard_fun7() { 
        if (mark("PC7")>=1)  return(1); else return(0);
}
int guard_fun8() { 
        if (mark("PC8")>=1)  return(1); else return(0);
}
int guard_fun9() { 
        if (mark("PC9")>=1) return(1); else return(0);
}
int guard_fun10() { 
        if (mark("PC10")>=1)  return(1); else return(0);
}
int guard_fun11() { 
        if (mark("PC11")>=1) return(1); else return(0);
}
int guard_fun12() { 
        if (mark("PC12")>=1) return(1); else return(0);
}
int guard_fun13() { 
        if (mark("PC13")>=1) return(1); else return(0);
}
int guard_fun14() { 
        if (mark("PC14")>=1)  return(1); else return(0);
}
int guard_fun15() { 
        if (mark("PC15")>=1) return(1); else return(0);
}
int guard_fun16() { 
        if (mark("PC16")>=1)  return(1); else return(0);
}
int guard_fun17() { 
        if (mark("PC17")>=1)  return(1); else return(0);
}
int guard_fun18() { 
        if (mark("PC18")>=1) return(1); else return(0);
}
int guard_fun19() { 
        if (mark("PC19")>=1) return(1); else return(0);
}
int guard_fun20() { 
        if (mark("PC20")>=1) return(1); else return(0);
}

double expected_fun1() { return((double) mark("PA1"));}
double expected_fun2() { return((double) mark("PA2"));}
double expected_fun3() { return((double) mark("PA3"));}
double expected_fun4() { return((double) mark("PA4"));}
double expected_fun5() { return((double) mark("PA5"));}
double expected_fun6() { return((double) mark("PA6"));}
double expected_fun7() { return((double) mark("PA7"));}
double expected_fun8() { return((double) mark("PA8"));}
double expected_fun9() { return((double) mark("PA9"));}
double expected_fun10() { return((double) mark("PA10"));}
double expected_fun11() { return((double) mark("PA11"));}
double expected_fun12() { return((double) mark("PA12"));}
double expected_fun13() { return((double) mark("PA13"));}
double expected_fun14() { return((double) mark("PA14"));}
double expected_fun15() { return((double) mark("PA15"));}
double expected_fun16() { return((double) mark("PA16"));}
double expected_fun17() { return((double) mark("PA17"));}
double expected_fun18() { return((double) mark("PA18"));}
double expected_fun19() { return((double) mark("PA19"));}
double expected_fun20() { return((double) mark("PA20"));}

net() {
  /*exponential net */
	place("PA1");
	place("PB1");
	place("PC1");

	init("PA1", 10);

	ratefun("ta1", parameter_fun1);  
	ratedep("tb1", 1.0,"PB1");
	rateval("tc1", 1.0);
	rateval("td1", 1.0);

	miarc("ta1","PA1",2);	
	moarc("ta1","PB1",2);
	viarc("tb1","PB1",multip);		
	voarc("tb1","PA1",multip);
	iarc("tc1","PA1");		
	oarc("tc1","PC1");
	iarc("td1","PC1");		
	oarc("td1","PA1");
	mharc("ta1","PA1",8);

	guard("td1",guard_fun1);
	affected("ta1","td1",PRI);
	policy("ta1",PRI);

 /*deterministic net ; with vharc!!!!*/ 
	place("PA2");
	place("PB2");
	place("PC2");

	init("PA2", 10);

	detfun("ta2", parameter_fun2);probval("ta2",4.0); 
	detdep("tb2", 1.0,"PB2");probval("tb2",0.5); 
	detval("tc2", 1.0);probval("tc2",1.0); 
	detval("td2", 1.0);probval("td2",1.0); 

	miarc("ta2","PA2",2);	
	moarc("ta2","PB2",2);
	viarc("tb2","PB2",multip);		
	voarc("tb2","PA2",multip);
	iarc("tc2","PA2");		
	oarc("tc2","PC2");
	iarc("td2","PC2");		
	oarc("td2","PA2");
	vharc("ta2","PA2",multiph);

	guard("td2",guard_fun2);
	affected("ta2","td2",PRI);
	policy("ta2",PRD);

 /*uniform net, */
	place("PA3");
	place("PB3");
	place("PC3");

	init("PA3", 10);

	uniffun("ta3", parameter_fun3_1,parameter_fun3);  
	unifdep("tb3", 0.0,1.0,"PB3");
	unifval("tc3", 0.0,1.0);
	unifval("td3", 1.0,2.0);

	miarc("ta3","PA3",2);	
	moarc("ta3","PB3",2);
	viarc("tb3","PB3",multip);		
	voarc("tb3","PA3",multip);
	iarc("tc3","PA3");		
	oarc("tc3","PC3");
	iarc("td3","PC3");		
	oarc("td3","PA3");
	vharc("ta3","PA3",multiph);

	guard("td3",guard_fun3);
	affected("ta3","td3",PRI);
	policy("ta3",PRD);

 /*geometric net */
	place("PA4");
	place("PB4");
	place("PC4");

	init("PA4", 10);

	geomfun("ta4", parameter_fun4, parameter_fun4_1);probval("ta4",0.5); 
	geomdep("tb4", 0.05,1.0,"PB4");probval("tb4",0.5); 
	geomval("tc4", 0.7,1.5);probval("tc4",3.5); 
	geomval("td4", 0.4,1.0);probval("td4",2.5); 

	miarc("ta4","PA4",2);	
	moarc("ta4","PB4",2);
	viarc("tb4","PB4",multip);		
	voarc("tb4","PA4",multip);
	iarc("tc4","PA4");		
	oarc("tc4","PC4");
	iarc("td4","PC4");		
	oarc("td4","PA4");
	mharc("ta4","PA4",8);

	guard("td4",guard_fun4);
	affected("ta4","td4",PRD);
	policy("ta4",PRS);

 /*weibul net */
	place("PA5");
	place("PB5");
	place("PC5");

	init("PA5", 10);

	weibfun("ta5", parameter_fun5, parameter_fun5_1);  
	weibdep("tb5", 2.0,2.0, "PB5");
	weibval("tc5", 1.0, 2.0);
	weibval("td5", 0.5,1.0);

	miarc("ta5","PA5",2);	
	moarc("ta5","PB5",2);
	viarc("tb5","PB5",multip);		
	voarc("tb5","PA5",multip);
	iarc("tc5","PA5");		
	oarc("tc5","PC5");
	iarc("td5","PC5");		
	oarc("td5","PA5");
	mharc("ta5","PA5",8);

	guard("td5",guard_fun5);
	affected("ta5","td5",PRI);
	policy("ta5",PRS);

 /*normal net */
	place("PA6");
	place("PB6");
	place("PC6");

	init("PA6", 10);

	normfun("ta6", parameter_fun6, parameter_fun6_1);  
	normdep("tb6", 1.0,1.0,"PB6");
	normval("tc6", 1.0,2.0);
	normval("td6", 2.0,1.0);

	miarc("ta6","PA6",2);	
	moarc("ta6","PB6",2);
	viarc("tb6","PB6",multip);		
	voarc("tb6","PA6",multip);
	iarc("tc6","PA6");		
	oarc("tc6","PC6");
	iarc("td6","PC6");		
	oarc("td6","PA6");
	mharc("ta6","PA6",8);


	guard("td6",guard_fun6);
	affected("ta6","td6",PRS);
	policy("ta6",PRD);

 /*lognormal net */
	place("PA7");
	place("PB7");
	place("PC7");

	init("PA7", 10);

	lognfun("ta7", parameter_fun7,parameter_fun7_1);  
	logndep("tb7", 1.0,1.0,"PB7");
	lognval("tc7", 2.0,2.0);
	lognval("td7", 0.5,1.0);

	miarc("ta7","PA7",2);	
	moarc("ta7","PB7",2);
	viarc("tb7","PB7",multip);		
	voarc("tb7","PA7",multip);
	iarc("tc7","PA7");		
	oarc("tc7","PC7");
	iarc("td7","PC7");		
	oarc("td7","PA7");
	mharc("ta7","PA7",8);

	guard("td7",guard_fun7);
	affected("ta7","td7",PRI);
	policy("ta7",PRS);

 /*gamma net */
	place("PA8");
	place("PB8");
	place("PC8");

	init("PA8", 10);

	gamfun("ta8", parameter_fun8,parameter_fun8_1);  
	gamdep("tb8", 1.0,1.0,"PB8");
	gamval("tc8", 2.0,0.5);
	gamval("td8", 0.5,2.0);

	miarc("ta8","PA8",2);	
	moarc("ta8","PB8",2);
	viarc("tb8","PB8",multip);		
	voarc("tb8","PA8",multip);
	iarc("tc8","PA8");		
	oarc("tc8","PC8");
	iarc("td8","PC8");		
	oarc("td8","PA8");
	mharc("ta8","PA8",8);

	guard("td8",guard_fun8);
	affected("ta8","td8",PRD);
	policy("ta8",PRD);

 /*beta net */
	place("PA9");
	place("PB9");
	place("PC9");

	init("PA9", 10);

	betfun("ta9", parameter_fun9,parameter_fun9_1);  
	betdep("tb9", 1.0,1.0,"PB9");
	betval("tc9", 2.0,0.5);
	betval("td9", 2.0,1.0);

	miarc("ta9","PA9",2);	
	moarc("ta9","PB9",2);
	viarc("tb9","PB9",multip);		
	voarc("tb9","PA9",multip);
	iarc("tc9","PA9");		
	oarc("tc9","PC9");
	iarc("td9","PC9");		
	oarc("td9","PA9");
	mharc("ta9","PA9",8);

	guard("td9",guard_fun9);
	affected("ta9","td9",PRS);
	policy("ta9",PRS);

 /*Poisson net */
	place("PA10");
	place("PB10");
	place("PC10");

	init("PA10", 10);

	poisfun("ta10", parameter_fun10, parameter_fun10_1);probval("ta10",5.0); 
	poisdep("tb10", 1.0,1.0,"PB10");probval("tb10",2.5); 
	poisval("tc10", 2.0,1.5);probval("tc10",0.5); 
	poisval("td10", 1.0,1.0);probval("td10",1.5); 

	miarc("ta10","PA10",2);	
	moarc("ta10","PB10",2);
	viarc("tb10","PB10",multip);		
	voarc("tb10","PA10",multip);
	iarc("tc10","PA10");		
	oarc("tc10","PC10");
	iarc("td10","PC10");		
	oarc("td10","PA10");
	mharc("ta10","PA10",8);

	guard("td10",guard_fun10);
	affected("ta10","td10",PRS);
	policy("ta10",PRD);

 /*binomial net */
	place("PA11");
	place("PB11");
	place("PC11");

	init("PA11", 10);

	binofun("ta11", parameter_fun11,parameter_fun11_1,parameter_fun11_2);probval("ta11",0.5); 
	binodep("tb11", 3.0,0.08,1.0,"PB11");probval("tb11",0.3); 
	binoval("tc11", 4.0,0.5,1.0);probval("tc11",0.5); 
	binoval("td11", 5.0,0.6,2.0);probval("td11",2.0); 

	miarc("ta11","PA11",2);	
	moarc("ta11","PB11",2);
	viarc("tb11","PB11",multip);		
	voarc("tb11","PA11",multip);
	iarc("tc11","PA11");		
	oarc("tc11","PC11");
	iarc("td11","PC11");		
	oarc("td11","PA11");
	mharc("ta11","PA11",8);

	guard("td11",guard_fun11);
	affected("ta11","td11",PRI);
	policy("ta11",PRI);

 /*negative binomial net */
	place("PA12");
	place("PB12");
	place("PC12");

	init("PA12", 10);

	negbfun("ta12", parameter_fun12,parameter_fun12_1,parameter_fun12_2);probval("ta12",0.5);  
	negbdep("tb12", 1.0,0.08,1.0,"PB12");probval("tb12",0.5); 
	negbval("tc12", 1.0,0.4,2.0);probval("tc12",0.3); 
	negbval("td12", 1.5,0.3,1.5);probval("td12",0.9); 

	miarc("ta12","PA12",2);	
	moarc("ta12","PB12",2);
	viarc("tb12","PB12",multip);		
	voarc("tb12","PA12",multip);
	iarc("tc12","PA12");		
	oarc("tc12","PC12");
	iarc("td12","PC12");		
	oarc("td12","PA12");
	mharc("ta12","PA12",8);

	guard("td12",guard_fun12);
	affected("ta12","td12",PRD);
	policy("ta12",PRD);

 /*hyper-exponential net */
	place("PA13");
	place("PB13");
	place("PC13");

	init("PA13", 10);

	hyperfun("ta13",parameter_fun13,parameter_fun13_1,parameter_fun13_2);  
	hyperdep("tb13", 1.0,2.0,0.8,"PB13");
	hyperval("tc13", 1.0,4.0,0.5);
	hyperval("td13", 2.0,0.5,0.5);

	miarc("ta13","PA13",2);	
	moarc("ta13","PB13",2);
	viarc("tb13","PB13",multip);		
	voarc("tb13","PA13",multip);
	iarc("tc13","PA13");		
	oarc("tc13","PC13");
	iarc("td13","PC13");		
	oarc("td13","PA13");
	mharc("ta13","PA13",8);

	guard("td13",guard_fun13);
	affected("ta13","td13",PRD);
	policy("ta13",PRS);

 /*hypo-exponential net */
	place("PA14");
	place("PB14");
	place("PC14");

	init("PA14", 10);

	hypofun("ta14", parameter_fun14, parameter_fun14_1, parameter_fun14_2, parameter_fun14_3);  
	hypodep("tb14", 2.0,1.0,2.0,0.0,"PB14");
	hypoval("tc14", 3.0,1.5,0.8,1.0);
	hypoval("td14", 2.0,1.0,2.0,0.0);

	miarc("ta14","PA14",2);	
	moarc("ta14","PB14",2);
	viarc("tb14","PB14",multip);		
	voarc("tb14","PA14",multip);
	iarc("tc14","PA14");		
	oarc("tc14","PC14");
	iarc("td14","PC14");		
	oarc("td14","PA14");
	mharc("ta14","PA14",8);

	guard("td14",guard_fun14);
	affected("ta14","td14",PRS);
	policy("ta14",PRI);

 /*erlang net */
	place("PA15");
	place("PB15");
	place("PC15");

	init("PA15", 10);

	erlfun("ta15", parameter_fun15, parameter_fun15_1);  
	erldep("tb15", 2.0,1.0,"PB15");
	erlval("tc15", 1.0,3.0);
	erlval("td15", 2.0,5.0);

	miarc("ta15","PA15",2);	
	moarc("ta15","PB15",2);
	viarc("tb15","PB15",multip);		
	voarc("tb15","PA15",multip);
	iarc("tc15","PA15");		
	oarc("tc15","PC15");
	iarc("td15","PC15");		
	oarc("td15","PA15");
	mharc("ta15","PA15",8);

	guard("td15",guard_fun15);
	affected("ta15","td15",PRI);
	policy("ta15",PRS);

 /*Pareto net */
	place("PA16");
	place("PB16");
	place("PC16");

	init("PA16", 10);

	parfun("ta16", parameter_fun16,parameter_fun16_1);  
	pardep("tb16", 1.0,0.5,"PB16");
	parval("tc16", 2.0,0.8);
	parval("td16", 1.0,1.5);

	miarc("ta16","PA16",2);	
	moarc("ta16","PB16",2);
	viarc("tb16","PB16",multip);		
	voarc("tb16","PA16",multip);
	iarc("tc16","PA16");		
	oarc("tc16","PC16");
	iarc("td16","PC16");		
	oarc("td16","PA16");
	mharc("ta16","PA16",8);

	guard("td16",guard_fun16);
	affected("ta16","td16",PRI);
	policy("ta16",PRI);

 /*Cauchy net */
	place("PA17");
	place("PB17");
	place("PC17");

	init("PA17", 10);

	caufun("ta17", parameter_fun17, parameter_fun17_1);  
	caudep("tb17", 1.0,1.0,"PB17");
	cauval("tc17", 1.3,0.5);
	cauval("td17", 2.0,1.0);

	miarc("ta17","PA17",2);	
	moarc("ta17","PB17",2);
	viarc("tb17","PB17",multip);		
	voarc("tb17","PA17",multip);
	iarc("tc17","PA17");		
	oarc("tc17","PC17");
	iarc("td17","PC17");		
	oarc("td17","PA17");
	mharc("ta17","PA17",8);

	guard("td17",guard_fun17);
	affected("ta17","td17",PRD);
	policy("ta17",PRI);

 /* triangular net */
	place("PA18");
	place("PB18");
	place("PC18");

	init("PA18", 10);

	trifun("ta18",parameter_fun18,parameter_fun18_1,parameter_fun18_2);  
	tridep("tb18", 1.0,1.8,3.0,"PB18");
	trival("tc18", 1.0,1.5,1.8);
	trival("td18", 0.0,0.3,1.0);

	miarc("ta18","PA18",2);	
	moarc("ta18","PB18",2);
	viarc("tb18","PB18",multip);		
	voarc("tb18","PA18",multip);
	iarc("tc18","PA18");		
	oarc("tc18","PC18");
	iarc("td18","PC18");		
	oarc("td18","PA18");
	mharc("ta18","PA18",8);

	guard("td18",guard_fun18);
	affected("ta18","td18",PRD);
	policy("ta18",PRD);

 /*cox2 net */
	place("PA19");
	place("PB19");
	place("PC19");

	init("PA19", 10);

	cox2fun("ta19",parameter_fun19,parameter_fun19_1,parameter_fun19_2);  
	cox2dep("tb19", 1.0,2.0,0.4,"PB19");
	cox2val("tc19", 0.5,1.0,0.9);
	cox2val("td19", 3.0,0.8,0.5);

	miarc("ta19","PA19",2);	
	moarc("ta19","PB19",2);
	viarc("tb19","PB19",multip);		
	voarc("tb19","PA19",multip);
	iarc("tc19","PA19");		
	oarc("tc19","PC19");
	iarc("td19","PC19");		
	oarc("td19","PA19");
	mharc("ta19","PA19",8);

	guard("td19",guard_fun19);
	affected("ta19","td19",PRS);
	policy("ta19",PRS);

 /*defective exponential net */
	place("PA20");
	place("PB20");
	place("PC20");

	init("PA20", 10);

	deffun("ta20",parameter_fun20, parameter_fun20_1);probval("ta20",0.5);
	defdep("tb20", 1.0,0.4,"PB20");probval("tb20",0.7);
	defval("tc20", 2.0,0.1);probval("tc20",1.0);
	defval("td20", 0.7,0.6);probval("td20",0.2);

	miarc("ta20","PA20",2);	
	moarc("ta20","PB20",2);
	viarc("tb20","PB20",multip);		
	voarc("tb20","PA20",multip);
	iarc("tc20","PA20");		
	oarc("tc20","PC20");
	iarc("td20","PC20");		
	oarc("td20","PA20");
	mharc("ta20","PA20",8);

	guard("td20",guard_fun20);
	affected("ta20","td20",PRS);
	policy("ta20",PRD);


/* for immediate transitions */
	place("PA21");
	place("PB21");
	place("PC21");
        place("PD21");

	init("PA21", 10);

	imm("ta21");probval("ta21",0.5);
	imm("tb21");probdep("tb21",0.7,"PA21");
	imm("tc21");probfun("tc21",fun_prob);
	rateval("td21",1.0);
	rateval("te21",1.0);
	rateval("tf21",1.0);

	miarc("ta21","PA21",2);	
	moarc("ta21","PB21",2);
	viarc("tb21","PA21",multip);		
	voarc("tb21","PC21",multip);
	iarc("tc21","PA21");		
	oarc("tc21","PD21");
	iarc("td21","PB21");		
	oarc("td21","PA21");
	iarc("te21","PC21");		
	oarc("te21","PA21");
	iarc("tf21","PD21");		
	oarc("tf21","PA21");
	harc("tb21","PC21");

/* fluid net */ 
  place("On"); place("Off"); place("Up"); place("Down");init("On",1); init("Up",1);
  fplace("One"); finit("One",0.0); fbound("One",1.0);
  fplace("Two"); fbound("Two",2.0); finit("Two",1.0);
  inf("Fill");        
  inf("Use");        
  inf("Xfer"); 
  imm("Stop");        probval("Stop",1.0);  guard("Stop",gstop);
  imm("Start");       probval("Start",1.0); guard("Start",gstart);
  rateval("Fail",0.1);
  rateval("Repair",1);

  iarc("Fill","On");oarc("Fill","On");
      fvoarc("Fill","One",fuprin); fvoarc("Fill","Two",fdnrin);
      floarc("Use","One",fl1,fl2); dmiarc("Use","One",0.05);
  iarc("Stop","On"); 
      oarc("Stop","Off"); 
  iarc("Start","Off"); oarc("Start","On");  
  iarc("Xfer","Up"); oarc("Xfer","Up");
     fmiarc("Xfer","Two",0.1);fvoarc("Xfer","One",f21);
  iarc("Use","Up"); oarc("Use","Up"); fviarc("Use","One",fout);
  iarc("Fail","Up");oarc("Fail","Down");iarc("Repair","Down");oarc("Repair","Up");

}


assert() { }
ac_init() { }
ac_reach() { }


ac_final() { 
	pr_mc_info();
	pr_cum_expected("mean number of tokens i net 1",mean1);
        pr_cum_expected("cumulative mean number of tokens in Place PA1",expected_fun1);
        pr_expected("pointwise mean number of tokens in Place PA1",expected_fun1);
        pr_cum_expected("cumulative mean number of tokens in Place PA2",expected_fun2);
        pr_expected("pointwise mean number of tokens in Place PA2",expected_fun2);
        pr_cum_expected("cumulative mean number of tokens in Place PA3",expected_fun3);
        pr_expected("pointwise mean number of tokens in Place PA3",expected_fun3);
        pr_cum_expected("cumulative mean number of tokens in Place PA4",expected_fun4);
        pr_expected("pointwise mean number of tokens in Place PA4",expected_fun4);
        pr_cum_expected("cumulative mean number of tokens in Place PA5",expected_fun5);
        pr_expected("pointwise mean number of tokens in Place PA5",expected_fun5);
        pr_cum_expected("cumulative mean number of tokens in Place PA6",expected_fun6);
        pr_expected("pointwise mean number of tokens in Place PA6",expected_fun6);
        pr_cum_expected("cumulative mean number of tokens in Place PA7",expected_fun7);
        pr_expected("pointwise mean number of tokens in Place PA7",expected_fun7);
        pr_cum_expected("cumulative mean number of tokens in Place PA8",expected_fun8);
        pr_expected("pointwise mean number of tokens in Place PA8",expected_fun8);
        pr_cum_expected("cumulative mean number of tokens in Place PA9",expected_fun9);
        pr_expected("pointwise mean number of tokens in Place PA9",expected_fun9);
        pr_cum_expected("cumulative mean number of tokens in Place PA10",expected_fun10);
        pr_expected("pointwise mean number of tokens in Place PA10",expected_fun10);
        pr_cum_expected("cumulative mean number of tokens in Place PA11",expected_fun11);
        pr_expected("pointwise mean number of tokens in Place PA11",expected_fun11);
        pr_cum_expected("cumulative mean number of tokens in Place PA12",expected_fun12);
        pr_expected("pointwise mean number of tokens in Place PA12",expected_fun12);
        pr_cum_expected("cumulative mean number of tokens in Place PA13",expected_fun13);
        pr_expected("pointwise mean number of tokens in Place PA13",expected_fun13);
        pr_cum_expected("cumulative mean number of tokens in Place PA14",expected_fun14);
        pr_expected("pointwise mean number of tokens in Place PA14",expected_fun14);
        pr_cum_expected("cumulative mean number of tokens in Place PA15",expected_fun15);
        pr_expected("pointwise mean number of tokens in Place PA15",expected_fun15);
        pr_cum_expected("cumulative mean number of tokens in Place PA16",expected_fun16);
        pr_expected("pointwise mean number of tokens in Place PA16",expected_fun16);
        pr_cum_expected("cumulative mean number of tokens in Place PA17",expected_fun17);
        pr_expected("pointwise mean number of tokens in Place PA17",expected_fun17);
        pr_cum_expected("cumulative mean number of tokens in Place PA18",expected_fun18);
        pr_expected("pointwise mean number of tokens in Place PA18",expected_fun18);
        pr_cum_expected("cumulative mean number of tokens in Place PA19",expected_fun19);
        pr_expected("pointwise mean number of tokens in Place PA19",expected_fun19);
        pr_cum_expected("cumulative mean number of tokens in Place PA20",expected_fun20);
        pr_expected("pointwise mean number of tokens in Place PA20",expected_fun20);

}


