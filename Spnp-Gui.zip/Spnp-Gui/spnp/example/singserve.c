
/* This is the input file used for calculating results for the paper by
Ibe and Trivedi in IEEE-JSAC, Dec. 1990. In order to run many cases
with different sets of input parameters, this spn input file was
exercised through the shell file sing.sh */

# include	"user.h"

int	M; 
double  l1,l2,l3,m1,m2,m3,r1,r2,r3,rho; 


parameters() {
iopt(IOP_METHOD,VAL_SSSOR);
iopt(IOP_MC,VAL_CTMC);
iopt(IOP_PR_RGRAPH,VAL_NO);
iopt(IOP_PR_RSET,VAL_NO);
iopt(IOP_PR_MC,VAL_NO);
fopt(FOP_PRECISION,0.00000000001);

	M  = input("Number of tokens");
        l1 = input("Arrival rate of 1");
        m1 = input("Service rate of 1");
        r1 = input("Walk rate of 1");
        l2 = input("Arrival rate of 2");
        m2 = input("Service rate of 2");
        r2 = input("Walk rate of 2");
        l3 = input("Arrival rate of 3");
        m3 = input("Service rate of 3");
        r3 = input("Walk rate of 3");
	rho = M*(l1/m1+l2/m2+l3/m3);


	}
net() {

	place("P1i");
	place("P1b");
	place("P1s");
	place("P1p");
	place("P2i");
        place("P2b");
	place("P2s");
	place("P2p");
	init("P1i",M);
        place("P3i");
        place("P3b");
        place("P3s");
	place("P3p");
	init("P2i",M);
	init("P3i",M);
	init("P1s",1);
	
	trans("tl1");
	trans("tm1");
	trans("tr1");
	trans("tl2");
	trans("tm2");
	trans("tr2");
	trans("tl3");
	trans("tm3");
	trans("tr3");

	trans("s1");
	trans("s2");
	trans("s3");

	ratedep("tl1", l1,"P1i");
	rateval("tm1", m1);
	rateval("tr1", r1);
	ratedep("tl2", l2,"P2i");
	rateval("tm2", m2);
	rateval("tr2", r2);
	ratedep("tl3", l3,"P3i");
	rateval("tm3", m3);
	rateval("tr3", r3);


        priority("s1",100);
       	priority("s2",100);
	priority("s3",100);
   
        priority("tl1",10);
	priority("tm1",10);
	priority("tr1",10);
	priority("tl2",10);
        priority("tm2",10);
	priority("tr2",10);
	priority("tl3",10);
	priority("tm3",10);
        priority("tr3",10);

	probval("s1",1.0);
	probval("s2",1.0);
	probval("s3",1.0);

	iarc("tl1","P1i");
	oarc("tl1","P1b");

	iarc("tm1","P1b");
	iarc("tm1","P1s");
	oarc("tm1","P1i");

	iarc("tr2","P2p");
	oarc("tr2","P2s");

	iarc("tl2","P2i");
	oarc("tl2","P2b");

	iarc("tm2","P2b");
	iarc("tm2","P2s");
	oarc("tm2","P2i");

	iarc("tr3","P3p");
	oarc("tr3","P3s");

	iarc("tl3","P3i");
	oarc("tl3","P3b");

	iarc("tm3","P3b");
	iarc("tm3","P3s");
	oarc("tm3","P3i");


	iarc("tr1","P1p");
	oarc("tr1","P1s");
	
	iarc("s1","P1s");
	harc("s1","P1b");
	oarc("s1","P2p");

	iarc("s2","P2s");
	harc("s2","P2b");
	oarc("s2","P3p");

	iarc("s3","P3s");
	harc("s3","P3b");
	oarc("s3","P1p");
}

assert() { return(RES_NOERR); }
ac_init() { fprintf(stderr,"\single service with 3 stations"); }
ac_reach() { }
reward_type	Rmsg_arr_1() { return (rate("tl1")); }
reward_type	Rmsg_arr_2() { return (rate("tl2")); }
reward_type	Rmsg_arr_3() { return (rate("tl3")); }

ac_final() { 
	FILE	*ff;
	double	resp_3,resp_1,resp_2;
pr_mc_info();
		resp_1 = (M / expected(Rmsg_arr_1)) - 1.0/l1;
		resp_2 = (M /expected(Rmsg_arr_2)) - 1.0/l2;
		resp_3 = (M /expected(Rmsg_arr_3)) - 1.0/l3;
	/*pr_std_average();*/
	ff = fopen("sing.tmp","w");
	fprintf(ff,"         rho = %f\n",rho);
	fprintf(ff,"        average response time at 1 = %f\n",resp_1);
	fprintf(ff,"        average response time at 2 = %f\n",resp_2);
	fprintf(ff,"        average response time at 3 = %f\n",resp_3);
}
