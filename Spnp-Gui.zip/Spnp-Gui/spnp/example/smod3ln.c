#include <stdio.h>
#include <string.h>
#include <math.h>
#include "user.h"

/* global variables */ 

int N = 8;

int NHBUF = 32;

int NTK = 8;

int NLBUF = 32;

int NER = 3;

double larvrate = 3;
double harvrate = 6;

double rateTMMPP01 = 0.01;
double rateTMMPP10 = 0.02;

double rateTTK = 5;

double rateTHTX = 18;
double rateTLTX = 18;

double prbtVPN = 0.9;
double prbtBE = 0.1;

double prbtHB_l, prbtHB_h;
double prbtHE_l, prbtHE_h;
double prbtPL23_l, prbtPL23_h;
double prbtHQ_l, prbtHQ_h;
double prbtPL3_l, prbtPL3_h;
double prbtLQ_l, prbtLQ_h;

int TIpolicy = 1;
int TIp3_th = 1;

char linktype[128];
char nameFP[128];

  /* prototype guard functions */ 
  int guard_tRD () ; 
  int guard_tLDIS () ; 

  /* prototype rate functions */ 
  double rate_TARV () ; 

  /* prototype cardinality functions */ 
  int cardinality_HERD () ; 
  int cardinality_HFRD () ; 
 
 
void mmpp2para(double a0, double a1, double b01, double b10,
	       double *m, double *v, double *u, double *t)
{
  *m = (b01 * a1 + b10 * a0) / (b01 + b10);
  *v = (a1 - a0) * (a1 - a0) * b01 * b10 / ((b01 + b10) * (b01 + b10));
  *u = (a1 * a1 * a1 * b01 + a0 * a0 * a0 * b10) / (b01 + b10);
  *u = *u - 3 * *m * *v - *m * *m * *m;
  *t = 1 / (b01 + b10);
}

void para2mmpp(double *l1, double *l2, double *th01, double *th10,
	       double *m, double *v, double *u, double *t, int N)
{
  double x, e;

  *m = N * *(m + 1) + *(m + 2);
  *v = N * *(v + 1) + *(v + 2);
  *u = N * *(u + 1) + *(u + 2);
  *t = (N * *(v + 1) * *(t + 1) + *(v + 2) * *(t + 2)) / *v;

  /*
  x = (*u - 3 * *m * *v - *m * *m * *m) / sqrt(*v * *v * *v);
  */
  x = *u / sqrt(*v * *v * *v);
  /*
  if (x > 0)
    e = (x * x + 2 - x * sqrt(4 + x * x)) / 2;
  else
    e = (x * x + 2 + x * sqrt(4 + x * x)) / 2;
  */
  e = (x * x + 2 - x * sqrt(4 + x * x)) / 2;

  *l1 = *m + sqrt(*v / e);
  *l2 = *m - sqrt(*v * e);
  *th01 = 1 / (*t * (1 + e));
  *th10 = e / (*t * (1 + e));
}

void LoadConfig()
{
  FILE *fp;
  char sstr[100], *ptr;
  int i;
  double m[3], v[3], u[3], t[3];
  double nlarvrate, nharvrate, nrateTMMPP01, nrateTMMPP10;
  double tlarvrate, tharvrate, trateTMMPP01, trateTMMPP10;

  sprintf(sstr, "%s.cfg", modelname);
  if ((fp = fopen(sstr, "r")) == NULL) 
    {
      perror("Can not Open the Config File");
      exit(1);
    }

  while (fgets(sstr, 100, fp)) {
    if (*sstr == '#' || *sstr == '\n')
      continue;

    if (!strncmp(sstr, "Number of Links:", 16)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%d", &N);
	continue;
      }

    if (!strncmp(sstr, "Size of Low-Priority Buffer:", 28)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%d", &NLBUF);
	continue;
      }

    if (!strncmp(sstr, "Rate of MMPP 0 to 1:", 20)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &rateTMMPP01);
	continue;
      }

    if (!strncmp(sstr, "Rate of MMPP 1 to 0:", 20)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &rateTMMPP10);
	continue;
      }

    if (!strncmp(sstr, "High Packet Arrival Rate:", 24)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &harvrate);
	continue;
      }

    if (!strncmp(sstr, "Low Packet Arrival Rate:", 23)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &larvrate);
	continue;
      }

    if (!strncmp(sstr, "Packet Leaving Rate:", 20)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &rateTHTX);
	rateTLTX = rateTHTX;
	continue;
      }

    if (!strncmp(sstr, "Percent of High Priority Packet:", 32)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &prbtVPN);
	prbtVPN /= 100;
	continue;
      }

    if (!strncmp(sstr, "Percent of Low Priority Packet:", 31)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &prbtBE);
	prbtBE /= 100;
	continue;
      }

    if (!strncmp(sstr, "Traffic Interaction Policy:", 27)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%d", &TIpolicy);
	continue;
      }
    
    if (!strncmp(sstr, "Link Type:", 10)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%s", linktype);
	continue;
      }


    if (!strncmp(sstr, "Tagged Link Data File:", 22)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%s", nameFP);
	continue;
      }

  }

  fclose(fp);

  mmpp2para(larvrate, harvrate, rateTMMPP01, rateTMMPP10, m+1, v+1, u+1, t+1);
  mmpp2para(larvrate, harvrate, rateTMMPP01, rateTMMPP10, m+2, v+2, u+2, t+2);
  para2mmpp(&nharvrate, &nlarvrate, &nrateTMMPP01, &nrateTMMPP10, m, v, u, t, N-1);
  
  if ((fp = fopen(nameFP, "r")) == NULL) 
    {
      perror("Can not Open the Data File");
      exit(1);
    }
  
  
  for (i = 1; i <= 3; i++)
    {
      if (!fgets(sstr, 100, fp))
	break;

      if (*sstr == '#' || *sstr == '\n')
	{
	  printf("Error in Data File\n");
	  fclose(fp);
	  exit(1);
	}
      switch(i)
	{
	case 1: 
	  sscanf(sstr, "%lf%lf", &prbtHE_l, &prbtHE_h);
	  prbtHB_l = 1 -  prbtHE_l;
	  prbtHB_h = 1 -  prbtHE_h;
	  break;
	case 2:
	  if (TIpolicy > 1)
	    {
	      sscanf(sstr, "%lf%lf", &prbtPL23_l, &prbtPL23_h);
	      mmpp2para(larvrate * prbtPL23_l, harvrate * prbtPL23_h, rateTMMPP01, rateTMMPP10, m+1, v+1, u+1, t+1);
	      mmpp2para(larvrate * prbtPL23_l, harvrate * prbtPL23_h, rateTMMPP01, rateTMMPP10, m+2, v+2, u+2, t+2);
	      para2mmpp(&tharvrate, &tlarvrate, &trateTMMPP01, &trateTMMPP10, m, v, u, t, N-1);
	      prbtPL23_l = tlarvrate / nlarvrate;
	      prbtPL23_h = tharvrate / nharvrate;
	      prbtHQ_l = 1 -  prbtPL23_l;
	      prbtHQ_h = 1 -  prbtPL23_h;
	    }
	  break;
	case 3:
	  if (TIpolicy > 2)
	    {
	      sscanf(sstr, "%lf%lf", &prbtPL3_l, &prbtPL3_h);
	      mmpp2para(larvrate * prbtPL3_l, harvrate * prbtPL3_h, rateTMMPP01, rateTMMPP10, m+1, v+1, u+1, t+1);
	      mmpp2para(larvrate * prbtPL3_l, harvrate * prbtPL3_h, rateTMMPP01, rateTMMPP10, m+2, v+2, u+2, t+2);
	      para2mmpp(&tharvrate, &tlarvrate, &trateTMMPP01, &trateTMMPP10, m, v, u, t, N-1);
	      prbtPL3_l = tlarvrate / nlarvrate;
	      prbtPL3_h = tharvrate / nharvrate;
	      prbtLQ_l = 1 -  prbtPL3_l;
	      prbtLQ_h = 1 -  prbtPL3_h;
	    }
	  break;
	}
    }
  fclose(fp);

  larvrate = nlarvrate;
  harvrate = nharvrate;
  rateTMMPP01 = nrateTMMPP01;
  rateTMMPP10 = nrateTMMPP10;
}

void options() {
  iopt(IOP_PR_RGRAPH,VAL_NO) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_NO) ;
  iopt(IOP_USENAME,VAL_NO) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_NO) ;
  iopt(IOP_PR_MC_ORDER,VAL_FROMTO) ;
  /* NUMERICAL SOLUTION chosen */ 
  iopt(IOP_SENSITIVITY,VAL_NO) ;
  iopt(IOP_MC,VAL_CTMC) ;
  iopt(IOP_SSMETHOD,VAL_SSSOR) ;
  iopt(IOP_TSMETHOD,VAL_FOXUNIF) ;
  iopt(IOP_ITERATIONS,10000) ;
  fopt(FOP_PRECISION,0.000001) ;
  fopt(FOP_ABS_RET_M0,0.000000) ;
  iopt(IOP_CUMULATIVE,VAL_YES) ;
  iopt(IOP_SSDETECT,VAL_YES) ;
  iopt(IOP_OK_ABSMARK,VAL_NO) ;
  iopt(IOP_OK_VANLOOP,VAL_NO) ;
  iopt(IOP_OK_TRANS_M0,VAL_YES) ;
  iopt(IOP_OK_VAN_M0,VAL_YES) ;
  iopt(IOP_ELIMINATION,VAL_REDONTHEFLY) ;

  LoadConfig();
} 



/* GUARD Functions */ 
int guard_tRD () 
{
  if ((mark("pHF") + mark("pHE") == N) && mark("pHF"))
    return(1);
  else
    return(0);
}
int guard_tLDIS () 
{
  if (mark("pLQ") > NLBUF)
    return(1);
  else
    return(0);
}
int guard_tPL23()
{
  if (TIpolicy > 1)
    return(1);
  else
    return(0);
}
int guard_tPL3()
{
  if (TIpolicy < 3)
    return(0);
  else
    return(1);
}

/* RATE Functions */ 
double rate_TARV () 
{
  if (mark("pMMPP")) 
    return(harvrate);
  else
    return(larvrate);
}

/* PRB Functions */ 
double prb_HB()
{
  if (mark("pMMPP"))
    return(prbtHB_h);
  else
    return(prbtHB_l);
}
double prb_HE()
{
  if (mark("pMMPP"))
    return(prbtHE_h);
  else
    return(prbtHE_l);
}
double prb_HQ()
{
  if (TIpolicy == 1)
    return(1.0);
  else 
    {
      if (mark("pMMPP"))
	return(prbtHQ_h);
      else
	return(prbtHQ_l);
    }
}
double prb_PL23()
{
  if (TIpolicy == 1)
    return(0.0);
  else 
    {
      if (mark("pMMPP"))
	return(prbtPL23_h);
      else
	return(prbtPL23_l);
    }
}
double prb_LQ()
{
  if (TIpolicy < 3)
    return(1.0);
  else 
    {
      if (mark("pMMPP"))
	return(prbtLQ_h);
      else
	return(prbtLQ_l);
    }
}
double prb_PL3()
{
  if (TIpolicy < 3)
    return(0.0);
  else 
    {
      if (mark("pMMPP"))
	return(prbtPL3_h);
      else
	return(prbtPL3_l);
    }
}

/* CARDINALITY Functions */ 
int cardinality_HERD () 
{
  return(mark("pHE"));
}
int cardinality_HFRD () 
{
  return(mark("pHF"));
}


void net() {
  /*  MMPP  */
  place("pMMPP") ;
  
  rateval("TMMPP10",rateTMMPP10) ;
  rateval("TMMPP01",rateTMMPP01) ;

  iarc("TMMPP10","pMMPP") ;
  oarc("TMMPP01","pMMPP") ;
  harc("TMMPP01","pMMPP") ;

  /* best-effort link */
  place("pARV") ;
  place("pTHQ") ;
  place("pLQ") ;
  place("pTLQ") ;

  ratefun("TARV",rate_TARV) ;
  rateval("TLTX",rateTLTX) ;
  imm("tVPN") ;
  priority("tVPN",20) ;
  probval("tVPN",prbtVPN) ;
  imm("tBE") ;
  priority("tBE",20) ;
  probval("tBE",prbtBE) ;
  imm("tHQ") ;
  priority("tHQ",20) ;
  probfun("tHQ",prb_HQ) ;
  imm("tLQ") ;
  priority("tLQ",20) ;
  probfun("tLQ",prb_LQ) ;
  imm("tPL23") ;
  priority("tPL23",20) ;
  probfun("tPL23",prb_PL23) ;
  guard("tPL23",guard_tPL23) ;
  imm("tPL3") ;
  priority("tPL3",20) ;
  probfun("tPL3",prb_PL3) ;
  guard("tPL3",guard_tPL3) ;
  imm("tLDIS") ;
  guard("tLDIS",guard_tLDIS) ;
  priority("tLDIS",20) ;
  probval("tLDIS",1.) ;

  oarc("TARV","pARV") ;
  iarc("tVPN","pARV") ;
  oarc("tVPN","pTHQ") ;
  iarc("tHQ","pTHQ") ;
  iarc("tPL23","pTHQ") ;
  oarc("tPL23","pLQ") ;
  iarc("tBE","pARV") ;
  oarc("tBE","pTLQ") ;
  iarc("tPL3","pTLQ") ;
  iarc("tLQ","pTLQ") ;
  oarc("tLQ","pLQ") ;
  iarc("tLDIS","pLQ") ;
  iarc("TLTX","pLQ") ;

  /* VPN link */
  place("pHE") ;
  place("pHB") ;
  place("pHQ") ;
  init("pHQ",N) ;
  place("pHF") ;
  place("pRLT") ;

  rateval("THTX",rateTHTX) ;
  imm("tHB") ;
  priority("tHB",20) ;
  probfun("tHB",prb_HB) ;
  imm("tHE") ;
  priority("tHE",20) ;
  probfun("tHE",prb_HE) ;
  imm("tRD") ;
  guard("tRD",guard_tRD) ;
  priority("tRD",20) ;
  probval("tRD",1.) ;
  imm("tLT") ;
  priority("tLT",20) ;
  probval("tLT",1.) ;
 
  iarc("tHB","pHQ") ;
  oarc("tHB","pHB") ;
  iarc("THTX","pHB") ;
  oarc("THTX","pHF") ;
  viarc("tRD","pHF",cardinality_HFRD) ;
  iarc("tHE","pHQ") ;
  oarc("tHE","pHE") ;
  viarc("tRD","pHE",cardinality_HERD) ;
  moarc("tRD","pHQ",N) ;
  miarc("tLT","pHE",N) ;
  oarc("tLT","pRLT") ;
  iarc("TLTX","pRLT") ;
  moarc("TLTX","pHQ",N) ;
} 

int assert() 
{ 
	return RES_NOERR;
}

void ac_init() 
{ 

}

void ac_reach() 
{ 

}

double get_loss()
{
  if (mark("pLQ") == NLBUF)
    return((prb_LQ() * prbtBE + (1.0 - prb_HQ()) * prbtVPN)* rate_TARV());
  else
    return(0.0);     
}

double get_VPN2BE()
{
  return((1.0 - prb_HQ()) * prbtVPN * rate_TARV());
}

void ac_final() 
{ 
	solve(INFINITY);
	pr_std_average();

	fprintf(Outfile,"\nTraffic from VPN to Best-Effort = %.12e\n", expected(get_VPN2BE));
	fprintf(Outfile,"\nLoss Traffic at Best-Effort = %.12e\n", expected(get_loss));
	
}

