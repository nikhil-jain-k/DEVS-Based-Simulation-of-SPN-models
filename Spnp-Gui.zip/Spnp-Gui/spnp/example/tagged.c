#include <stdio.h>
#include <string.h>
#include <math.h>
#include "user.h"
#include "misc.h"

/* global variables */ 

int NBUF = 32;

int NTK = 8;

int NRR = 1;

int NMRR = 2;

int NER = 3;

double larvrate = 3;
double harvrate = 6;

double rateTMMPP01 = 0.01;
double rateTMMPP10 = 0.02;

double rateTTK = 5;

double rateTTX = 18;
double rateTMTX = 18;

double prbtVPN = 0.8;
double prbtBE = 0.2;

double prbtRT[128];
double my_prbtRT[128];

char nameFP[128];
double FPprecision = 0.000001;

int TIpolicy = 1;
int TIp3_th = 1;

char linktype[128];

int ntoken = 0;
 
  /* prototype guard functions */ 
  int guard_tRT () ; 
  int guard_tBP () ; 
  int guard_tMBP () ; 
  int guard_tBE () ; 
  int guard_tVPN () ; 
  int guard_tMWT () ; 

  /* prototype rate functions */ 
  double rate_TARV () ; 

  /* prototype cardinality functions */ 
  int cardinality_MWT () ; 
 
void LoadConfig()
{
  FILE *fp;
  char sstr[100], *ptr;
  int i, nodata = 0;

  sprintf(sstr, "%s.cfg", modelname);
  if ((fp = fopen(sstr, "r")) == NULL) 
    {
      perror("Can not Open the Config File");
      exit(1);
    }

  while (fgets(sstr, 100, fp)) {
    if (*sstr == '#' || *sstr == '\n')
      continue;

    if (!strncmp(sstr, "Size of Buffer:", 15)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%d", &NBUF);
	continue;
      }

    if (!strncmp(sstr, "Size of Leaky-Bucket Token Pool:", 32)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%d", &NTK);
	continue;
      }

    if (!strncmp(sstr, "Round Robin Weight:", 18)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%d", &NRR);
	continue;
      }

    if (!strncmp(sstr, "Maximum Waiting Time:", 21)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%d", &NMRR);
	continue;
      }

    if (!strncmp(sstr, "Rate of MMPP 0 to 1:", 20)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &rateTMMPP01);
	continue;
      }

    if (!strncmp(sstr, "Rate of MMPP 1 to 0:", 20)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &rateTMMPP10);
	continue;
      }

    if (!strncmp(sstr, "Leaky-Bucket Token Rate:", 24)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &rateTTK);
	continue;
      }

    if (!strncmp(sstr, "High Packet Arrival Rate:", 24)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &harvrate);
	continue;
      }

    if (!strncmp(sstr, "Low Packet Arrival Rate:", 23)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &larvrate);
	continue;
      }

    if (!strncmp(sstr, "Packet Leaving Rate:", 20)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &rateTTX);
	rateTMTX = rateTTX;
	continue;
      }

    if (!strncmp(sstr, "Percent of High Priority Packet:", 32)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &prbtVPN);
	prbtVPN /= 100;
	continue;
      }

    if (!strncmp(sstr, "Percent of Low Priority Packet:", 31)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &prbtBE);
	prbtBE /= 100;
	continue;
      }

    if (!strncmp(sstr, "Erlang Stage:", 13)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%d", &NER);
	continue;
      }
    
    if (!strncmp(sstr, "Traffic Interaction Policy:", 27)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%d", &TIpolicy);
	continue;
      }
    
    if (!strncmp(sstr, "Policy III Threshold:", 20)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%d", &TIp3_th);
	continue;
      }

    if (!strncmp(sstr, "Fix Point Iteration File:", 25)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%s", nameFP);
	continue;
      }

    if (!strncmp(sstr, "Fix Point Precision:", 20)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%lf", &FPprecision);
	continue;
      }
 
    if (!strncmp(sstr, "Link Type:", 10)) 
      {
	ptr = strchr(sstr, ':');
	sscanf(ptr + 1, "%s", linktype);
	continue;
      }
  }

  fclose(fp);
  rateTTK *= NER;

  nodata = 0;
  sprintf(sstr, "%s.itp", modelname);
  if ((fp = fopen(sstr, "r")) != NULL) 
    {
      for (i = 0; i <= NRR; i++)
	{
	  if (!fgets(sstr, 100, fp))
	    {
	      nodata = 1;
	      break;
	    }
	  if (*sstr == '#' || *sstr == '\n')
	    {
	      printf("Error in Iteration Date\n");
	      exit(1);
	    }
	  sscanf(sstr, "%lf", my_prbtRT + i);
	}
      fclose(fp);
    }
  else
    nodata = 1;  
  if (nodata)
    for (i = 0; i <= NRR; i++)
      my_prbtRT[i] = 1 / ((double)NRR + 1.0);

  nodata = 0;
  if ((fp = fopen(nameFP, "r")) != NULL) 
    {
      for (i = 0; i <= NMRR; i++)
	{
	  if (!fgets(sstr, 100, fp))
	    {
	      nodata = 1;
	      break;
	    }
	  if (*sstr == '#' || *sstr == '\n')
	    {
	      printf("Error in Iteration Date\n");
	      exit(1);
	    }
	  sscanf(sstr, "%lf", prbtRT + i);
	}
      fclose(fp);
    }
  else
    nodata = 1;  
  if (nodata)
    for (i = 0; i <= NMRR; i++)
      prbtRT[i] = 1 / ((double)NMRR + 1.0);


}

void options() {
  iopt(IOP_PR_RGRAPH,VAL_NO) ;
  iopt(IOP_PR_MC,VAL_NO) ;
  iopt(IOP_PR_DERMC,VAL_NO) ;
  iopt(IOP_PR_PROB,VAL_NO) ;
  iopt(IOP_PR_PROBDTMC,VAL_NO) ;
  iopt(IOP_PR_DOT,VAL_NO) ;
  iopt(IOP_PR_MERG_MARK,VAL_YES) ;
  iopt(IOP_PR_FULL_MARK,VAL_NO) ;
  iopt(IOP_USENAME,VAL_YES) ;
  iopt(IOP_DEBUG,VAL_NO) ;
  iopt(IOP_PR_MARK_ORDER,VAL_CANONIC) ;
  iopt(IOP_PR_RSET,VAL_NO) ;
  iopt(IOP_PR_MC_ORDER,VAL_FROMTO) ;
  /* NUMERICAL SOLUTION chosen */ 
  iopt(IOP_SENSITIVITY,VAL_NO) ;
  iopt(IOP_MC,VAL_CTMC) ;
  iopt(IOP_SSMETHOD,VAL_GASEI) ;
  iopt(IOP_TSMETHOD,VAL_FOXUNIF) ;
  iopt(IOP_ITERATIONS,20000) ;
  fopt(FOP_PRECISION,0.000001) ;
  fopt(FOP_ABS_RET_M0,0.000000) ;
  iopt(IOP_CUMULATIVE,VAL_YES) ;
  iopt(IOP_SSDETECT,VAL_YES) ;
  iopt(IOP_OK_ABSMARK,VAL_NO) ;
  iopt(IOP_OK_VANLOOP,VAL_NO) ;
  iopt(IOP_OK_TRANS_M0,VAL_YES) ;
  iopt(IOP_OK_VAN_M0,VAL_YES) ;
  iopt(IOP_ELIMINATION,VAL_REDONTHEFLY) ;

  LoadConfig();

} 

/* GUARD Functions */ 
int guard_tRT () 
{
  if (mark("pHQ") && mark("pTK")) 
    return(1);
  else
    return(0);
}
int guard_tBP () 
{
  if (mark("pHQ") && mark("pTK")) 
    return(0);
  else
    return(1);
}
int guard_tMBP () 
{
  if (mark("pHQ") && mark("pTK")) 
    return(1);
  else
    return(0);
}
int guard_tBE_p12 () 
{
  return(1);
}
int guard_tBE_p3 () 
{
  if (mark("pTK") - mark("pHQ") >= TIp3_th)
    return(0);
  else
    return(1); 
}
int guard_tVPN () 
{
  if (mark("pHQ") < NBUF) 
    return(1);
  else
    return(0);
}
int guard_tMWT () 
{
  if (!mark("pMTX") && mark("pMWT")) 
    return(1);
  else
    return(0);
}


/* RATE Functions */ 
double rate_TARV () 
{
  if (mark("pMMPP")) 
    return(harvrate);
  else
    return(larvrate);
}


/* CARDINALITY Functions */ 
int cardinality_MWT () 
{
  return(mark("pMWT"));
}

void net() {
  int i;
  char rt[128];
  
  /* MMPP */
  place("pMMPP") ;

  rateval("TMMPP10",rateTMMPP10) ;
  rateval("TMMPP01",rateTMMPP01) ;

  iarc("TMMPP10","pMMPP") ;
  oarc("TMMPP01","pMMPP") ;
  harc("TMMPP01","pMMPP") ;

  /* Tagged / Aggregated link */
  place("pARV") ;
  place("pHQ") ;
  place("pTK") ;
  place("pER") ;

  ratefun("TARV",rate_TARV) ;
  rateval("TTK",rateTTK) ;
  rateval("TTX",rateTTX) ;
  imm("tVPN") ;
  guard("tVPN",guard_tVPN) ;
  priority("tVPN",20) ;
  probval("tVPN",prbtVPN) ;
  imm("tBE") ;
  if (TIpolicy < 3)
    guard("tBE",guard_tBE_p12) ;
  else
    guard("tBE",guard_tBE_p3) ;
  priority("tBE",20) ;
  probval("tBE",prbtBE) ;
  imm("tER") ;
  priority("tER",20) ;
  probval("tER",1.) ;

  oarc("TARV","pARV") ;
  iarc("tBE","pARV") ;
  iarc("tVPN","pARV") ;
  oarc("tVPN","pHQ") ;
  oarc("TTK","pER") ;
  miarc("tER","pER",NER) ;
  oarc("tER","pTK") ;
  mharc("TTK","pTK",NTK) ;
  iarc("TTX","pHQ") ;
  iarc("TTX","pTK") ;

  /*  Round Robin  */
  place("pRR") ;
  place("pRC") ;
  init("pRC",NRR) ;
  place("pMTX") ;
  place("pMWT") ;

  rateval("TMTX",rateTMTX) ;

  imm("tBP") ;
  guard("tBP",guard_tBP) ;
  priority("tBP",20) ;
  probval("tBP",1.) ;
  imm("tMWT") ;
  guard("tMWT",guard_tMWT) ;
  priority("tMWT",20) ;
  probval("tMWT",1.) ;
  imm("tMBP") ;
  guard("tMBP",guard_tMBP) ;
  priority("tMBP",20) ;
  probval("tMBP",prbtRT[0]) ;

  oarc("TTX","pRC") ;
  iarc("TTX","pRR") ;
  iarc("tBP","pRR") ;
  oarc("tBP","pRC") ;
  miarc("tMBP","pRC",NRR) ;
  moarc("tMBP","pRR",NRR) ;
  iarc("TMTX","pMTX") ;
  oarc("TMTX","pMWT") ;
  viarc("tMWT","pMWT",cardinality_MWT) ;
  moarc("tMWT","pRR",NRR) ;

  for (i = 1; i <= NMRR; i++)
    {
      sprintf(rt, "tRT_%d", i);
      imm(rt) ;
      guard(rt,guard_tRT) ;
      priority(rt,20) ;
      probval(rt,prbtRT[i]) ;
      miarc(rt,"pRC",NRR) ;
      moarc(rt,"pMTX",i) ;
    }
} 

int assert() 
{ 
  return RES_NOERR;
}

void ac_init() 
{ 
}

void ac_reach() 
{ 
}

double get_prbtRT()
{
  if (((mark("pTK") == ntoken) && (mark("pHQ") >= ntoken))
      || ((mark("pTK") >= ntoken) && (mark("pHQ") == ntoken)))
    return(1.0);
  else
    return(0.0);
}

double get_though()
{
  if (mark("pHQ") < NBUF)
    {
      if (mark("pMMPP"))
	return(prbtVPN * harvrate);
      else
	return(prbtVPN * larvrate);
    }
  else
    return(0.0);
}

double get_arrival()
{
  if (mark("pMMPP"))
    return(harvrate);
  else
    return(larvrate);
}

double get_util()
{
  if (mark("pTK") < NTK) 
    return(1.0);
  else
    return(0.0);
}

double get_VPN2BE()
{
  if (mark("pHQ") == NBUF)
    {
      if (mark("pMMPP"))
	return(prbtVPN * harvrate);
      else
	return(prbtVPN * larvrate);
    }
  else
    return(0.0);
}

double get_prbVPN2BE()
{
  if (mark("pHQ") == NBUF)
    return(1.0);
  else
    return(0.0);
}

double get_prbBVPN2BE()
{
  if ((mark("pHQ") == NBUF) && mark("pMMPP"))
    return(1.0);
  else
    return(0.0);
}

double get_prbNBVPN2BE()
{
  if ((mark("pHQ") == NBUF) && !mark("pMMPP"))
    return(1.0);
  else
    return(0.0);
}

double get_BE2VPN()
{
  if (mark("pTK") - mark("pHQ") >= TIp3_th)
    {
      if (mark("pMMPP"))
	return(prbtBE * harvrate);
      else
	return(prbtBE * larvrate);
    }
  else
    return(0.0); 
}

double get_prbBE2VPN()
{
  if (mark("pTK") - mark("pHQ") >= TIp3_th)
    return(1.0);
  else
    return(0.0); 
}

double get_prbBBE2VPN()
{
  if ((mark("pTK") - mark("pHQ") >= TIp3_th) && mark("pMMPP"))
    return(1.0);
  else
    return(0.0); 
}

double get_prbNBBE2VPN()
{
  if ((mark("pTK") - mark("pHQ") >= TIp3_th) && !mark("pMMPP"))
    return(1.0);
  else
    return(0.0); 
}


double get_prbBEMPTY()
{
  if ((!mark("pTK") || !mark("pHQ") || !mark("pRR")) && mark("pMMPP"))
    return(1.0);
  else
    return(0.0);
}
double get_prbNBEMPTY()
{
  if ((!mark("pTK") || !mark("pHQ") || !mark("pRR")) && !mark("pMMPP"))
    return(1.0);
  else
    return(0.0);
}

double get_prbBust()
{
  if (mark("pMMPP"))
    return(1.0);
  else
    return(0.0);
}

void ac_final() 
{
  double delta = 0.0, tmp_prbtRT, maxvalue, total_prbtRT = 0.0;
  double prbVPN2BE_h, prbVPN2BE_l, prbBE2VPN_h = 0, prbBE2VPN_l = 0;
  double prbBust;
  FILE *fp;
  char sstr[100];
  int i;

  solve(INFINITY);
  
  sprintf(sstr, "%s.itp", modelname);
  if ((fp = fopen(sstr, "w")) == NULL) 
    {
      perror("Can not Open the Fix Point Data File");
      exit(1);
    }
  
  for (ntoken = 0; ntoken < NRR; ntoken++)
    {
      tmp_prbtRT = expected(get_prbtRT);
      maxvalue = max(fabs(my_prbtRT[ntoken]), fabs(tmp_prbtRT));
      my_prbtRT[ntoken] -= tmp_prbtRT;
      maxvalue = fabs(my_prbtRT[ntoken]) / maxvalue;
      if (maxvalue > delta)
	delta = maxvalue;
      total_prbtRT += tmp_prbtRT;
      fprintf(fp, "%.12e\n", tmp_prbtRT);
    }
  my_prbtRT[NRR] -= 1.0 - total_prbtRT;
  fprintf(fp, "%.12e\n", 1.0 - total_prbtRT);

  fclose(fp);
    
  pr_std_average();
  
  if (delta < FPprecision)
    {
      printf("Fix Point Precision Satisfied\n");
      if (!strncmp(linktype, "Tagged", 6))
	{
	  prbBust = expected(get_prbBust);
	  fprintf(Outfile,"\nProb. of VPN getting through = %.12e\n", expected(get_though)/ (prbtVPN * expected(get_arrival)));
	  fprintf(Outfile,"\nUltilization of VPN = %.12e\n", expected(get_util));
	  prbVPN2BE_h = expected(get_prbBVPN2BE) / prbBust;
	  prbVPN2BE_l = expected(get_prbNBVPN2BE) / (1 - prbBust);
	  fprintf(Outfile,"\nTraffic from VPN to Best-Effort = %.12e\n", expected(get_VPN2BE));
	  fprintf(Outfile,"\nProb. of Traffic from VPN to Best-Effort = %.12e\n", expected(get_prbVPN2BE));
	  fprintf(Outfile,"\nProb. of Traffic from VPN to Best-Effort at Busty = %.12e\n", prbVPN2BE_h);
	  fprintf(Outfile,"\nProb. of Traffic from VPN to Best-Effort at Non-Busty = %.12e\n", prbVPN2BE_l);
	  if (TIpolicy == 3)
	    {
	      fprintf(Outfile,"\nTraffic from Best-Effort to VPN = %.12e\n", expected(get_BE2VPN));
	      prbBE2VPN_h = expected(get_prbBBE2VPN) / prbBust;
	      prbBE2VPN_l = expected(get_prbNBBE2VPN) / (1 - prbBust);
	      fprintf(Outfile,"\nProb. of Traffic from Best-Effort to VPN = %.12e\n", expected(get_prbBE2VPN));
	      fprintf(Outfile,"\nProb. of Traffic from Best-Effort to VPN at Busty = %.12e\n", prbBE2VPN_h);
	      fprintf(Outfile,"\nProb. of Traffic from Best-Effort to VPN at Non-Busty = %.12e\n", prbBE2VPN_l);
	    }

	  sprintf(sstr, "%s.pda", modelname);
	  if ((fp = fopen(sstr, "w")) == NULL) 
	    {
	      perror("Can not Open Data File");
	      fclose(Outfile);
	      exit(1);
	    }
	  for (i = 1; i <= 3; i++)
	    {
	      switch(i)
		{
		case 1: 
		  fprintf(fp, "%.12e\t%.12e\n", expected(get_prbNBEMPTY) / (1 - prbBust), expected(get_prbBEMPTY) / prbBust);
		  break;
		case 2:
		  fprintf(fp, "%.12e\t%.12e\n", prbVPN2BE_l, prbVPN2BE_h);
		  break;
		case 3:
		  fprintf(fp, "%.12e\t%.12e\n", prbBE2VPN_l, prbBE2VPN_h);
		  break;
		}
	    }
	  fclose(fp);
	  fclose(Outfile);
	  exit(2);
	}
    }
}




