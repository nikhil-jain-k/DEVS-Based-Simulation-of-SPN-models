#ifndef _LM_H
#define _LM_H

#include <lmcons.h>
#include <lmaccess.h>
#include <lmalert.h>
#include <lmat.h>
#include <lmaudit.h>
#include <lmchdev.h>
#include <lmconfig.h>
#include <lmmsg.h>
#include <lmshare.h>
#include <lmapibuf.h>
#include <lmremutl.h>
#include <lmrepl.h>
#include <lmuse.h>
#include <lmerrlog.h>
#include <lmsvc.h>
#include <lmwksta.h>
#include <lmstats.h>

#endif
