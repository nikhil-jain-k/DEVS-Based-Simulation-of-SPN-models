/* sysinclude.h */
#include	<math.h>
#include	<stdlib.h>
#include	<stdio.h>
#include        <string.h>
#include	<ctype.h>
#include	<sys/time.h>
#include        <signal.h>
#include	<float.h>
