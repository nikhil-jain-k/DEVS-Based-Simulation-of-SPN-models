#include "pch.h"
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "entstr.h"
#include "tglobal.h"
#include "Place.h"
#include "Transition.h"
#include "Genr.h"
#include "Transd.h"


// MakeSES function- to create models
void MakeSES(void) {

}

//////////////////////////////////////////////////////////////////////////////////
//  TODO: global variables, prototype, guard function part's code of SPNP in Here

// Till here: global variables, prototype, guard function part's code of SPNP
//////////////////////////////////////////////////////////////////////////////////


ENTSTR TEST("test");

char GENRMessage[1024];
CString nn;
CString rname = "TEST";

typedef struct {
	CString tname;
	double val;
} ttype;

vector <CString> mcode, ccode, icode, iicode;
vector <CString> vitransition, vttransition, vplace;
vector <CString> vguard, vmdepend;

map <CString, vector <ttype>> pMap;

map <CString, vector <CString>> info;

map <CString, vector <CString>> tfromMap;
map <CString, vector <CString>> ttoMap;
map <CString, vector <CString>> pfromMap;
map <CString, vector <CString>> ptoMap;

typedef struct {
	double prob;
	CString pn;
} mdp_type;

map <CString, double> probMap;
map <CString, vector <CString>> probMap_fmd;
map <CString, mdp_type> probMap_md;
map <CString, CString> probMap_func;

//map <arc_type, int> mulMap;

void place(CString pn)
{
	vplace.push_back(pn);
	sprintf_s(GENRMessage,"%s.AddItem(new Place(\"PM%s\", 0));", rname, pn);	
	mcode.push_back(GENRMessage);
}

void init(CString pn, int m)
{
	sprintf_s(GENRMessage,"%s.AddItem(new Place(\"PM%s\", %d));", rname, pn, m);
	mcode.pop_back();	
	mcode.push_back(GENRMessage);
}

void end(void)
{ 
	int i;

	for(i=0; i < (int)mcode.size(); i++)
	{
		Display(mcode[i]); NewLine();
	}
	NewLine();

	for(i=0; i < (int)ccode.size(); i++)
	{
		Display(ccode[i]); NewLine();
	}
	NewLine();

	for(i=0; i < (int)icode.size(); i++)
	{
		Display(icode[i]); NewLine();
	}
	NewLine();

	for(i=0;i < (int)iicode.size(); i++)
	{
		Display(iicode[i]); NewLine();
	}
}

void imm(CString tn)
{
	//imm("t1");
	vitransition.push_back(tn);
	sprintf_s(GENRMessage,"%s.AddItem(new Transition(\"TM%s\"));", rname, tn);
	mcode.push_back(GENRMessage);
}

void priority(CString tn, double p)
{
	//priority("t1",100);

	sprintf_s(GENRMessage,"if(p = %s.Children.FindFirstList(\"TM%s\"))", rname, tn);
	iicode.push_back(GENRMessage);
	iicode.push_back("{");
	sprintf_s(GENRMessage,"((Transition *) p->Model)->my_priority = %f;", p);
	iicode.push_back(GENRMessage);
	iicode.push_back("}");
}

void probval(CString tn, double p)
{
	//probval("t1",1.0);

	sprintf_s(GENRMessage,"if(p = %s.Children.FindFirstList(\"TM%s\"))", rname, tn);
	iicode.push_back(GENRMessage);
	iicode.push_back("{");
	sprintf_s(GENRMessage,"((Transition *) p->Model)->my_prob = %e;", p);
	iicode.push_back(GENRMessage);
	iicode.push_back("}");
}

void probdep(CString tn, double p, CString pn)
{
	sprintf_s(GENRMessage,"if(p = %s.Children.FindFirstList(\"TM%s\"))", rname, tn);
	iicode.push_back(GENRMessage);
	iicode.push_back("{");
	sprintf_s(GENRMessage,"((Transition *) p->Model)->my_prob = %e;", p*(-1));
	iicode.push_back(GENRMessage);
	sprintf_s(GENRMessage,"((Transition *) p->Model)->mdPlace = \"PM%s\";", pn);
	iicode.push_back(GENRMessage);
	iicode.push_back("}");

	CString TMtn, PMpn;

	TMtn = "TM"+tn;
	PMpn = "PM"+pn;

	sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"TM%s\",    \"moutTM%s\", \"minPM%s\");", rname, pn, tn, tn, pn);
	ccode.push_back(GENRMessage);

	sprintf_s(GENRMessage,"((Transition *) p->Model)->AddMinpt(\"minPM%s\", 1);", pn);
	info[TMtn].push_back(GENRMessage); 

	sprintf_s(GENRMessage,"((Place *) p->Model)->AddMoutpt(\"moutTM%s\", 1);", tn);
	info[PMpn].push_back(GENRMessage); 
}

void probfun(CString tn, CString mf)
{ 
	sprintf_s(GENRMessage,"if(p = %s.Children.FindFirstList(\"TM%s\"))", rname, tn);
	iicode.push_back(GENRMessage);
	iicode.push_back("{");
	sprintf_s(GENRMessage,"((Transition *) p->Model)->my_prob = %e;", 0.0);
	iicode.push_back(GENRMessage);
	sprintf_s(GENRMessage,"((Transition *) p->Model)->fn = \"%s\";", mf);
	iicode.push_back(GENRMessage);
	iicode.push_back("}");

	CString TMtn, PMpn;
	TMtn = "TM"+tn;

	/*vttransition.push_back(tn);
	sprintf_s(GENRMessage,"%s.AddItem(new Transition(\"TM%s\", \"%s\"));", rname, tn, mf);
	mcode.push_back(GENRMessage);*/

	vmdepend.clear(); // tr�� ���ǵ� mf�Լ��� ���Ե� �÷��̽��� ����

	if(tn == "t0") //prob_t0
	{
		vmdepend.push_back("P1");
	}
	else if(tn == "t1")//prob_t1
	{
		vmdepend.push_back("P2");
	}

	//vmdepend�� mfunc���� ����, marking-dependent�Լ��� ������ ���� vmdepend ���� �����ؾ���.
	//vmdepend.push_back("P1");

	for(int i=0; i < (int)vmdepend.size(); i++)
	{
		PMpn = "PM"+vmdepend[i];
		sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"TM%s\",    \"moutTM%s\", \"minPM%s\");", rname, vmdepend[i], tn, tn, vmdepend[i]);
		ccode.push_back(GENRMessage);

		sprintf_s(GENRMessage,"((Transition *) p->Model)->AddMinpt(\"minPM%s\", 1);", vmdepend[i]);
		info[TMtn].push_back(GENRMessage); 

		sprintf_s(GENRMessage,"((Place *) p->Model)->AddMoutpt(\"moutTM%s\", 1);", tn);
		info[PMpn].push_back(GENRMessage); 
	}
}

void rateval(CString tn, double r)
{
		//rateval("t_r",mu_r);
	vttransition.push_back(tn);
	sprintf_s(GENRMessage,"%s.AddItem(new Transition(\"TM%s\", %e));", rname, tn, r);
	mcode.push_back(GENRMessage);
}

void ratedep(CString tn, double r, CString pn)
{
		//ratedep("t_h_o",lam_h_o,"T");
	vttransition.push_back(tn);
	sprintf_s(GENRMessage,"%s.AddItem(new Transition(\"TM%s\", %e, \"PM%s\"));", rname, tn, r, pn);
	mcode.push_back(GENRMessage);

	CString TMtn, PMpn;

	TMtn = "TM"+tn;
	PMpn = "PM"+pn;

	sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"TM%s\",    \"moutTM%s\", \"minPM%s\");", rname, pn, tn, tn, pn);
	ccode.push_back(GENRMessage);

	sprintf_s(GENRMessage,"((Transition *) p->Model)->AddMinpt(\"minPM%s\", 1);", pn);
	info[TMtn].push_back(GENRMessage); 

	sprintf_s(GENRMessage,"((Place *) p->Model)->AddMoutpt(\"moutTM%s\", 1);", tn);
	info[PMpn].push_back(GENRMessage); 
}

// ratefun("Thr", func_hr);
void ratefun(CString tn, CString mf)
{
	CString TMtn, PMpn;
	TMtn = "TM"+tn;

	vttransition.push_back(tn);
	sprintf_s(GENRMessage,"%s.AddItem(new Transition(\"TM%s\", \"%s\"));", rname, tn, mf);
	mcode.push_back(GENRMessage);

	vmdepend.clear(); // tr�� ���ǵ� mf�Լ��� ���Ե� �÷��̽��� ����

	if(tn == "Thr") //func_hr
	{
		vmdepend.push_back("Pfh");
	}
	else if(tn == "Twr")//func_wr
	{
		vmdepend.push_back("Pfw");
		vmdepend.push_back("Pbw");
	}
	else if(tn == "Tcr")//func_cr
	{
		vmdepend.push_back("Pfc");
		vmdepend.push_back("Pbc1");
		vmdepend.push_back("Pbc2");
	}

	//vmdepend�� mfunc���� ����, marking-dependent�Լ��� ������ ���� vmdepend ���� �����ؾ���.
	//vmdepend.push_back("P1");

	for(int i=0; i < (int)vmdepend.size(); i++)
	{
		PMpn = "PM"+vmdepend[i];
		sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"TM%s\",    \"moutTM%s\", \"minPM%s\");", rname, vmdepend[i], tn, tn, vmdepend[i]);
		ccode.push_back(GENRMessage);

		sprintf_s(GENRMessage,"((Transition *) p->Model)->AddMinpt(\"minPM%s\", 1);", vmdepend[i]);
		info[TMtn].push_back(GENRMessage); 

		sprintf_s(GENRMessage,"((Place *) p->Model)->AddMoutpt(\"moutTM%s\", 1);", tn);
		info[PMpn].push_back(GENRMessage); 
	}
}

void efmaking()
{
	int i, j;

	sprintf_s(GENRMessage,"%s.AddItem(new GENR(\"gen\"));", rname);
	mcode.push_back(GENRMessage);

	sprintf_s(GENRMessage,"%s.AddItem(new Transd(\"transd\"));", rname);
	mcode.push_back(GENRMessage);

	sprintf_s(GENRMessage,"%s.AddCouple(\"gen\",    \"transd\",    \"finish\", \"finish\");", rname);
	mcode.push_back(GENRMessage);

	for(i = 0; i < (int)vplace.size(); i++)
	{
		sprintf_s(GENRMessage,"%s.AddCouple(\"gen\",    \"PM%s\",    \"finish\", \"finish\");", rname, vplace[i]);
		mcode.push_back(GENRMessage);

		sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"transd\",    \"info\", \"info-PM%s\");", rname, vplace[i], vplace[i]);
		mcode.push_back(GENRMessage);
	}

	for(i = 0; i < (int)vitransition.size(); i++)
	{
		sprintf_s(GENRMessage,"%s.AddCouple(\"gen\",    \"TM%s\",    \"finish\", \"finish\");", rname, vitransition[i]);
		mcode.push_back(GENRMessage);

		sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"transd\",    \"token\", \"token\");", rname, vitransition[i]);
		mcode.push_back(GENRMessage);

	}

	for(i = 0; i < (int)vttransition.size(); i++)
	{
		sprintf_s(GENRMessage,"%s.AddCouple(\"gen\",    \"TM%s\",    \"finish\", \"finish\");", rname, vttransition[i]);
		mcode.push_back(GENRMessage);

		sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"transd\",    \"token\", \"token\");", rname, vttransition[i]);
		mcode.push_back(GENRMessage);
	}

    /////////////////////////////////////////////////////////////////////////////////////
	//�÷��̽��� Ʈ������ ���� - �÷��̽����� output�Լ� �ּ��� ����
	//for(i = 0; i < (int)vplace.size(); i++)
	//{
	//	for(j = 0; j < (int)vttransition.size(); j++)
	//	{
	//		sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"TM%s\",    \"out\", \"in\");", rname, vplace[i], vttransition[j]);
	//		mcode.push_back(GENRMessage);
	//	}
	//}

	/////////////////////////////////////////////////////////////////////////////////////
    //���ϴ� Ʈ�����ǳ��� ����
	for(i = 0; i < (int)vitransition.size()-1; i++)  // vi <-> vi
	{
		for(j = i+1; j < (int)vitransition.size(); j++)
		{
			sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"TM%s\",    \"out\", \"in\");", rname, vitransition[i], vitransition[j]);
			mcode.push_back(GENRMessage);
			sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"TM%s\",    \"out\", \"in\");", rname, vitransition[j], vitransition[i]);
			mcode.push_back(GENRMessage);
		}
	}
	for(i = 0; i < (int)vitransition.size(); i++)   // vi <-> vt
	{
		for(j = 0; j < (int)vttransition.size(); j++)
		{
			sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"TM%s\",    \"out\", \"in\");", rname, vitransition[i], vttransition[j]);
			mcode.push_back(GENRMessage);
			sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"TM%s\",    \"out\", \"in\");", rname, vttransition[j], vitransition[i]);
			mcode.push_back(GENRMessage);
		}
	}
	for(i = 0; i < (int)vttransition.size()-1; i++)  // vt <-> vt
	{
		for(j = i+1; j < (int)vttransition.size(); j++)
		{
			sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"TM%s\",    \"out\", \"in\");", rname, vttransition[i], vttransition[j]);
			mcode.push_back(GENRMessage);
			sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"TM%s\",    \"out\", \"in\");", rname, vttransition[j], vttransition[i]);
			mcode.push_back(GENRMessage);
		}
	}

	for(i = 0; i < (int)vitransition.size(); i++) 
	{
		sprintf_s(GENRMessage,"if(p = %s.Children.FindFirstList(\"TM%s\"))", rname, vitransition[i]);
		iicode.push_back(GENRMessage);
		iicode.push_back("{");
		sprintf_s(GENRMessage,"((Transition *) p->Model)->N_imm = %d;", (int)vitransition.size());
		iicode.push_back(GENRMessage);
		sprintf_s(GENRMessage,"((Transition *) p->Model)->N_tim = %d;", (int)vttransition.size());
		iicode.push_back(GENRMessage);
		iicode.push_back("}");
	}
	for(i = 0; i < (int)vttransition.size(); i++) 
	{
		sprintf_s(GENRMessage,"if(p = %s.Children.FindFirstList(\"TM%s\"))", rname, vttransition[i]);
		iicode.push_back(GENRMessage);
		iicode.push_back("{");
		sprintf_s(GENRMessage,"((Transition *) p->Model)->N_tim = %d;", (int)vttransition.size());
		iicode.push_back(GENRMessage);
		sprintf_s(GENRMessage,"((Transition *) p->Model)->N_imm = %d;", (int)vitransition.size());
		iicode.push_back(GENRMessage);
		iicode.push_back("}");
	}
}

//iarc("t_h_i","CP");
void iarc(CString tn, CString pn)
{
	int i;

	map <CString, double>::iterator IterPos;
	map <CString, mdp_type>::iterator IterPos_md;
	map <CString, vector <CString>>::iterator IterPos_func;

	CString TMtn, PMpn;
	TMtn = "TM"+tn;
	PMpn = "PM"+pn;

	for(i = 0; i < (int)vttransition.size(); i++)
	{ 
		if(vttransition[i] == tn)
		{
			sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"PM%s\",    \"foutPM%s\", \"finTM%s\");", rname, tn, pn, pn, tn);
			ccode.push_back(GENRMessage);

			sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"TM%s\",    \"tdoutTM%s\", \"tdinPM%s\");", rname, pn, tn, tn, pn);
			ccode.push_back(GENRMessage);

			sprintf_s(GENRMessage,"((Transition *) p->Model)->AddFoutpt(\"foutPM%s\", 1);", pn);
			info[TMtn].push_back(GENRMessage); 
			sprintf_s(GENRMessage,"((Transition *) p->Model)->AddTDinpt(\"tdinPM%s\", 1);", pn);
			info[TMtn].push_back(GENRMessage); 

			sprintf_s(GENRMessage,"((Place *) p->Model)->AddFinpt(\"finTM%s\", 1);", tn);
			info[PMpn].push_back(GENRMessage); 
			sprintf_s(GENRMessage,"((Place *) p->Model)->AddTDoutpt(\"tdoutTM%s\", 1);", tn);
			info[PMpn].push_back(GENRMessage); 

			break;
		}
	}

	for(i = 0; i < (int)vitransition.size(); i++)
	{
		if(vitransition[i] == tn)
		{
			sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"PM%s\",    \"foutPM%s\", \"finTM%s\");", rname, tn, pn, pn, tn);
			ccode.push_back(GENRMessage);

			sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"TM%s\",    \"idoutTM%s\", \"idinPM%s\");", rname, pn, tn, tn, pn);
			ccode.push_back(GENRMessage);

			sprintf_s(GENRMessage,"((Transition *) p->Model)->AddFoutpt(\"foutPM%s\", 1);", pn);
			info[TMtn].push_back(GENRMessage); 
			sprintf_s(GENRMessage,"((Transition *) p->Model)->AddIDinpt(\"idinPM%s\", 1);", pn);
			info[TMtn].push_back(GENRMessage); 

			sprintf_s(GENRMessage,"((Place *) p->Model)->AddFinpt(\"finTM%s\", 1);", tn);
			info[PMpn].push_back(GENRMessage);

			sprintf_s(GENRMessage,"((Place *) p->Model)->AddIDoutpt(\"idoutTM%s\", 1);", tn);
			info[PMpn].push_back(GENRMessage); 
			
			break;
		}
	}
}

//miarc("t_n","CP",g_c+1);
void miarc(CString tn, CString pn, int mul)
{
	//arc_type iarc;
	int i;

	map <CString, double>::iterator IterPos;
	map <CString, mdp_type>::iterator IterPos_md;
	map <CString, vector <CString>>::iterator IterPos_func;

	CString TMtn, PMpn;
	TMtn = "TM"+tn;
	PMpn = "PM"+pn;

	for(i = 0; i < (int)vttransition.size(); i++)
	{ 
		if(vttransition[i] == tn)
		{
			sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"PM%s\",    \"foutPM%s\", \"finTM%s\");", rname, tn, pn, pn, tn);
			ccode.push_back(GENRMessage);

			sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"TM%s\",    \"tdoutTM%s\", \"tdinPM%s\");", rname, pn, tn, tn, pn);
			ccode.push_back(GENRMessage);

			//iarc.from = pn;
			//iarc.to = tn;

			//mulMap[iarc] = mul;

			sprintf_s(GENRMessage,"((Transition *) p->Model)->AddFoutpt(\"foutPM%s\", 1);", pn);
			info[TMtn].push_back(GENRMessage); 
			sprintf_s(GENRMessage,"((Transition *) p->Model)->AddTDinpt(\"tdinPM%s\", %d);", pn, mul);
			info[TMtn].push_back(GENRMessage); 

			sprintf_s(GENRMessage,"((Place *) p->Model)->AddFinpt(\"finTM%s\", 1);", tn);
			info[PMpn].push_back(GENRMessage); 
			sprintf_s(GENRMessage,"((Place *) p->Model)->AddTDoutpt(\"tdoutTM%s\", %d);", tn, mul);
			info[PMpn].push_back(GENRMessage); 

			break;
		}
	}

	for(i = 0; i < (int)vitransition.size(); i++)
	{
		if(vitransition[i] == tn)
		{
			sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"PM%s\",    \"foutPM%s\", \"finTM%s\");", rname, tn, pn, pn, tn);
			ccode.push_back(GENRMessage);

			sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"TM%s\",    \"idoutTM%s\", \"idinPM%s\");", rname, pn, tn, tn, pn);
			ccode.push_back(GENRMessage);

			sprintf_s(GENRMessage,"((Transition *) p->Model)->AddFoutpt(\"foutPM%s\", 1);", pn);
			info[TMtn].push_back(GENRMessage); 
			sprintf_s(GENRMessage,"((Transition *) p->Model)->AddIDinpt(\"idinPM%s\", %d);", pn, mul);
			info[TMtn].push_back(GENRMessage); 

			sprintf_s(GENRMessage,"((Place *) p->Model)->AddFinpt(\"finTM%s\", 1);", tn);
			info[PMpn].push_back(GENRMessage);

			sprintf_s(GENRMessage,"((Place *) p->Model)->AddIDoutpt(\"idoutTM%s\", %d);", tn, mul);
			info[PMpn].push_back(GENRMessage); 
			
			break;
		}
	}
}

//oarc("t1","T");
void oarc(CString tn, CString pn)
{
	CString TMtn, PMpn;
	TMtn = "TM"+tn;
	PMpn = "PM"+pn;

	sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"PM%s\",    \"doutPM%s\", \"dinTM%s\");", rname, tn, pn, pn, tn);
	ccode.push_back(GENRMessage);

	sprintf_s(GENRMessage,"((Transition *) p->Model)->AddDoutpt(\"doutPM%s\", 1);", pn);
	info[TMtn].push_back(GENRMessage); 

	sprintf_s(GENRMessage,"((Place *) p->Model)->AddDinpt(\"dinTM%s\", 1);", tn);
	info[PMpn].push_back(GENRMessage); 
}

//moarc("t_n","CP",g_c);
void moarc(CString tn, CString pn, int mul)
{
	//arc_type oarc;
	CString TMtn, PMpn;
	TMtn = "TM"+tn;
	PMpn = "PM"+pn;

	sprintf_s(GENRMessage,"%s.AddCouple(\"TM%s\",    \"PM%s\",    \"doutPM%s\", \"dinTM%s\");", rname, tn, pn, pn, tn);
	ccode.push_back(GENRMessage);

	//oarc.from = tn;
	//oarc.to = pn;

	//mulMap[oarc] = mul;

	sprintf_s(GENRMessage,"((Transition *) p->Model)->AddDoutpt(\"doutPM%s\", %d);", pn, mul);
	info[TMtn].push_back(GENRMessage); 

	sprintf_s(GENRMessage,"((Place *) p->Model)->AddDinpt(\"dinTM%s\", %d);", tn, mul);
	info[PMpn].push_back(GENRMessage); 
}

//harc("T0","P0");
void harc(CString tn, CString pn)
{
	CString TMtn, PMpn;
	TMtn = "TM"+tn;
	PMpn = "PM"+pn;

	sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"TM%s\",    \"houtTM%s\", \"hinPM%s\");", rname, pn, tn, tn, pn);
	ccode.push_back(GENRMessage);

	sprintf_s(GENRMessage,"((Transition *) p->Model)->AddHinpt(\"hinPM%s\", 1);", pn);
	info[TMtn].push_back(GENRMessage); 

	sprintf_s(GENRMessage,"((Place *) p->Model)->AddHoutpt(\"houtTM%s\", 1);", tn);
	info[PMpn].push_back(GENRMessage); 
}

//mharc("T3","P1",100);
void mharc(CString tn, CString pn, int mul)
{
	//arc_type harc;

	CString TMtn, PMpn;
	TMtn = "TM"+tn;
	PMpn = "PM"+pn;

	sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"TM%s\",    \"houtTM%s\", \"hinPM%s\");", rname, pn, tn, tn, pn);
	ccode.push_back(GENRMessage);

	//harc.from = pn;
	//harc.to = tn;

	//mulMap[harc] = mul;

	sprintf_s(GENRMessage,"((Transition *) p->Model)->AddHinpt(\"hinPM%s\", %d);", pn, mul);
	info[TMtn].push_back(GENRMessage); 

	sprintf_s(GENRMessage,"((Place *) p->Model)->AddHoutpt(\"houtTM%s\", %d);", tn, mul);
	info[PMpn].push_back(GENRMessage); 
}

//guard("tpup",gtpup);
void guard(CString tn, int (*gfunc)())
{   
	CString TMtn, PMpn;
	TMtn = "TM"+tn;

	vguard.clear();

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//  TODO: 1) vgaurd�� guard function���� ����, guard function ���� vguard�� ���� �����ؾ���.
//           ex) "guard("tpup",gtpup);" in SPNP
//           =>   if (tn == "tpup") //gtpup
//	              {
//		              vguard.push_back("P1");  // mark("P1") in gtpup()
// 	              }
//                else if(tn == ...) { ... }
//        2) transition�𵨿� guard function�� ����Լ��� �߰��ϰ� isGuard() �Լ��� üũ�ϴ� �ڵ带 �߰��ؾ� ��.
//////////////////////////////////////////////////////////////////////////////////////////////////////////
// TODO: Modified Guard function of SPNP here

// Till here: Modified Guard function of SPNP 
/////////////////////////////////////////////////////////////////////////////////////////////////		


	for(int i=0; i < (int)vguard.size(); i++)
	{
		PMpn = "PM"+vguard[i];
		sprintf_s(GENRMessage,"%s.AddCouple(\"PM%s\",    \"TM%s\",    \"goutTM%s\", \"ginPM%s\");", rname, vguard[i], tn, tn, vguard[i]);
		ccode.push_back(GENRMessage);

		sprintf_s(GENRMessage,"((Transition *) p->Model)->AddGinpt(\"ginPM%s\", 1);", vguard[i]);
		info[TMtn].push_back(GENRMessage); 

		sprintf_s(GENRMessage,"((Place *) p->Model)->AddGoutpt(\"goutTM%s\", 1);", tn);
		info[PMpn].push_back(GENRMessage); 
	}
}

void tmaking()
{
   	map <CString, vector <CString>>::iterator IterPos;

	icode.push_back("ListElement *p;");

	for(IterPos = info.begin(); IterPos != info.end(); ++IterPos)
	{
		sprintf_s(GENRMessage,"if(p = %s.Children.FindFirstList(\"%s\"))", rname, IterPos->first);
		icode.push_back(GENRMessage);
		icode.push_back("{");
		for(int i=0; i<(int)IterPos->second.size(); i++)
		{
			icode.push_back(IterPos->second[i]);
		}
		icode.push_back("}");
	}
}
 
//void MakeSES(void)
//{
//////////////////////////////////////////////////////////////////
//  TODO : Copy & Paste Translated //net()// function code in Here

// Till here: Copy & Paste Translated //net()// function code
//////////////////////////////////////////////////////////////////////////
//}

void MakeInput()
{
/////////////////////////////////////////////////
//  TODO: net() function code of SPNP in Here

// Till here: net() function code of SPNP
/////////////////////////////////////////////////////////////////////
//  TODO : Mandatory Code - Don't remove

 	efmaking();
	tmaking();
	end();

/////////////////////////////////////////////////////////////////////
}

void StartSimulation(void)
{ 
	time_t start_time = 0;
	time_t end_time = 0;

//	Display("nr : "); Display(nr); Display(", k : "); Display(k); NewLine(); 

	MakeSES();

	start_time = time(NULL);

	TEST.Restart();

	end_time = time(NULL);

	Display("solution time : "); Display((int)(end_time - start_time)); NewLine();
}
