#include "pch.h"
#include "transd.h"
#include "message.h"
#include "tglobal.h"
#include "place.h"

///////////////////////////////////////////////////////////////////
//  TODO: extern declaration of global variables of SPNP in Here

/* Global Variables */
// MP
extern int n;
extern int c;
extern double gamma;
extern double delta;
extern double beta;
extern double tao;
extern int negC;
extern double timeVal;
///////////////////////////////////////////////////////////////////


Transd::Transd(CString EName) : ATOMIC(EName) {
	SetName(Name);
}

Transd::Transd(char* EName) : ATOMIC(EName) {
	SetName(Name);
}

void Transd::ExtTransitionFN(double E, DevsMessage MSG)
{
	char GENRMessage[1024];

	if (MSG.ContentPort() == "finish")
	{
		if (MSG.ContentValue() == "finish") // BATCH
		{
			if (rflag)
//2020 delete			rewardvalue += (AddTime(GetLastEventTime(),E) - oldtime) * reward;
				rewardvalue += (TEST.CClock - oldtime) * reward; //2020 add
//2020 delete		rewardvalue = rewardvalue - oldrewardvalue;

			Display("=========================================================");
			NewLine();

//2020 delete		double rtemp = rewardvalue / (AddTime(GetLastEventTime(),E)-oldCClock);
			double rtemp = rewardvalue / (TEST.CClock - oldCClock); //2020 add

			v_rewardvalue.push_back(rtemp);
			Display("Reward : "); Display(rtemp);

			NewLine();

//2020 delete		oldrewardvalue = rewardvalue; 
//2020 delete		oldCClock = AddTime(GetLastEventTime(),E);
			rewardvalue = oldrewardvalue = 0; //2020 add
			oldCClock = TEST.CClock;          //2020 add

			if ((reward = getreward()) != 0)
			{
				rflag = true;
//2020 delete			oldtime =  AddTime(GetLastEventTime(),E);
				oldtime = TEST.CClock; //2020 add
			}
			else
			{
				rflag = false;
				oldtime = TEST.CClock; //2020 add
			}

			Continue();
		}
		else if (MSG.ContentValue() == "complete") // REPLICATE
		{
			if (rflag)
//2020 delete			rewardvalue += (AddTime(GetLastEventTime(),E) - oldtime) * reward;
				rewardvalue += (TEST.CClock - oldtime) * reward; //2020 add

			Display("=========================================================");
			NewLine();


//2020 delete		double rtemp = rewardvalue / (AddTime(GetLastEventTime(),E)-oldCClock);
			double rtemp = rewardvalue / (TEST.CClock - oldCClock); //2020 add

			v_rewardvalue.push_back(rtemp);
			Display("Reward : "); Display(rtemp);
			NewLine();

			Continue();
		}
		else if (MSG.ContentValue() == "terminate") // exit
		{
			Display("=========================================================");
			NewLine();

			/////////////////////////////////////////////////////////
			for (int i = 0; i < (int)v_rewardvalue.size() - 1; i++)
			{
				total_reward += v_rewardvalue[i];
			}

			ave_reward = total_reward / ((int)v_rewardvalue.size() - 1);

			for (int i = 0; i < (int)v_rewardvalue.size() - 1; i++)
			{
				total_var_reward += pow((ave_reward - v_rewardvalue[i]), 2);
			}

			var_reward = total_var_reward / (((int)v_rewardvalue.size() - 1) - 1);

			ci_reward = 2.78 * sqrt(var_reward) / sqrt(((double)v_rewardvalue.size() - 1));

			sprintf_s(GENRMessage, "Reward : %.10e [%.10e, %.10e]", ave_reward, ave_reward - ci_reward, ave_reward + ci_reward);
			Display(GENRMessage); NewLine();

			////////////////////////////////////////////////////////


			//	Display("Reward : "); Display(); 
			//	NewLine();

			Passivate();
		}
	}
	else
	{
		MsgData = *((msg_type*)(MSG.ContentValue()));

		//if(MsgData.type == DT)	// "token"�ΰ��
		//{			 
		//	if(rflag)
		//		rewardvalue += (AddTime(GetLastEventTime(),E) - oldtime) * reward;

		//	if(reward = getreward())
		//	{
		//		rflag = true;
		//		oldtime =  AddTime(GetLastEventTime(),E);
		//	}
		//	else
		//	{
		//		rflag = false;
		//		oldtime =  AddTime(GetLastEventTime(),E);
		//	}
		//}

		if (MsgData.type == IF)	// "��ū ����"�ΰ��
		{
			/*map <CString, int>::iterator IterPos;
			IterPos = token_map.find(MSG.ContentPort());
			if(IterPos == token_map.end()) { Display("Halt"); NewLine(); exit(0); }*/

			token_map[MSG.ContentPort()] = MsgData.value.cur_tkn;

			if (rflag)
//2020 delete			rewardvalue += (AddTime(GetLastEventTime(),E) - oldtime) * reward;
				rewardvalue += (TEST.CClock - oldtime) * reward; //2020 add

			if ((reward = getreward()) != 0)
			{
				rflag = true;
//2020 delete			oldtime =  AddTime(GetLastEventTime(),E);
				oldtime = TEST.CClock; //2020 add
			}
			else
			{
				rflag = false;
//2020 delete			oldtime =  AddTime(GetLastEventTime(),E);
				oldtime = TEST.CClock; //2020 add
			}
		}

		Continue();
	}
}

void Transd::IntTransitionFN(void) {
	Display(Name); Display("(INT) --> "); NewLine();

	if (Phase == "active") {
		Passivate();
	}
	else
		Continue();
}

void Transd::OutputFN(void) {
	Display(Name); Display("(OUT) --> "); NewLine();
	if (Phase == "active")
		MakeContent();
	else
		MakeContent();
}

void Transd::InitializeFN(void)
{
	total_reward = ave_reward = var_reward = total_var_reward = ci_reward = 0;
	rewardvalue = oldrewardvalue = 0;
	oldCClock = TEST.CClock;

	if ((reward = getreward()) != 0)
	{
		rflag = true;
		oldtime = TEST.CClock;
	}
	else
	{
		rflag = false;
//2020 delete	oldtime = 0;
		oldtime = TEST.CClock; //2020 add
	}

	HoldIn("active", INF);
}

double Transd::mark(CString pn)
{
	//ListElement *p;	
	//pn = "PM" + pn;

	//p = TEST.Children.GetHead();

	//do{
	//	if(p == NULL) break;

	//	if(p->Model->Name == pn)
	//	{
	//		return ((Place *) p->Model)->buffer.size();
	//	}

	//	p = p->Next;

	//}while(1);

	////return -1;
	//exit(0);

	pn = "info-PM" + pn;

	map <CString, int>::iterator IterPos;

	IterPos = token_map.find(pn);

	if (IterPos == token_map.end())
		return(0);
	else
		return(token_map[pn]);
}

double Transd::getreward()
{ 
	double rw = 0.0;

/////////////////////////////////////////////////
//  TODO: Reward function code of SPNP in Here
/////////////////////////////////////////////////

// Till here: Reward function code of SPNP
/////////////////////////////////////////////////

	return rw;
}
