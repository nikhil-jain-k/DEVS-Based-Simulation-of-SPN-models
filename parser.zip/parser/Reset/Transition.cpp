#include "pch.h"
#include "Transition.h"
#include "Place.h"

///////////////////////////////////////////////////////////////////
//  TODO: extern declaration of global variables of SPNP in Here

/* Global Variables */
// MP
extern int n;
extern int c;
extern double gamma;
extern double delta;
extern double beta;
extern double tao;
extern int negC;
extern double timeVal;

///////////////////////////////////////////////////////////////////

extern vector <pmr_type> pResult, ave_pResult, var_pResult, ci_pResult;
extern vector <tmr_type> tResult, ave_tResult, var_tResult, ci_tResult;
extern vector <vector <pmr_type>> all_pResult;
extern vector <vector <tmr_type>> all_tResult;

CString Transition::getPMName(CString s)
{
	if(s.GetAt(0) == 't' || s.GetAt(0) == 'i')
		return s.Right(s.GetLength()-4);
	else if(s.GetAt(0) == 'g' || s.GetAt(0) == 'm' || s.GetAt(0) == 'h') 
		return s.Right(s.GetLength()-3);
	else 
		exit(0);
}

///////////////////////////////////////
// DISTRIBUTION Functions  
// TODO : Add distribution functions 
//  ...
///////////////////////////////////////


///////////////////////////////////////
// GUARD Functions 
// TODO : Add guard functions in SPNP 	

// Till here: Add guard functions
/////////////////////////////////////////


Transition::Transition(CString EName) : ATOMIC(EName) 
{ 
//	md = false;
	tr_type = IMM;
	tRate = 0;
	my_priority = 1;
	my_prob = 1;
    SetName(EName); 
}

Transition::Transition(char *EName) : ATOMIC(EName)  
{ 
	tr_type = IMM;
	tRate = 0;
	my_priority = 1;
	my_prob = 1;
    SetName(EName); 
}

Transition::Transition(CString EName, double r) : ATOMIC(EName)
{ 
	tr_type = TIM;	
	tRate = r;
	mdPlace = "";
	my_priority = 1;
	my_prob = 1;
    SetName(EName); 
}

Transition::Transition(char *EName, double r) : ATOMIC(EName)  
{ 
	tr_type = TIM;	
	tRate = r;
	mdPlace = "";
	my_priority = 1;
	my_prob = 1;
    SetName(EName); 
}

Transition::Transition(CString EName, double r, CString p) : ATOMIC(EName)
{ 
	tr_type = TIM;	
	tRate = r;
	mdPlace = p;
	my_priority = 1;
	my_prob = 1;
    SetName(EName); 
}

Transition::Transition(char *EName, double r, CString p) : ATOMIC(EName) 
{ 
	tr_type = TIM;	
	tRate = r;
	mdPlace = p;
	my_priority = 1;
	my_prob = 1;
    SetName(EName);
}

Transition::Transition(CString EName, double (*mf)(void)) : ATOMIC(EName)
{ 
	tr_type = TIM;	
	tRate = -1;
	mfunc = mf;
	mdPlace = "";
	my_priority = 1;
	my_prob = 1;
    SetName(EName);
}

Transition::Transition(char *EName, double (*mf)(void)) : ATOMIC(EName) 
{ 
	tr_type = TIM;	
	tRate = -1;
	mfunc = mf;
	mdPlace = "";
	my_priority = 1;
	my_prob = 1;
    SetName(EName);
}

Transition::Transition(CString EName, CString fn) : ATOMIC(EName)
{
	tr_type = TIM;	
	tRate = -1;
	this->fn = fn;
	mdPlace = "";
	my_priority = 1;
	my_prob = 1;
    SetName(EName);
}

Transition::Transition(char *EName, CString fn) : ATOMIC(EName) 
{ 
	tr_type = TIM;	
	tRate = -1;
	this->fn = fn;
	mdPlace = "";
	my_priority = 1;
	my_prob = 1;
    SetName(EName);
}

void Transition::ExtTransitionFN(double e, DevsMessage MSG) 
{
	// Cinpt ���

	// CDinpt ���
//	 Display(Name); Display("(ext) --> "); NewLine();
	if(MSG.ContentPort() == "finish")
	{
		if(MSG.ContentValue() == "finish") // BATCH
		{			
			tR.s_length = AddTime(GetLastEventTime(),e) - oldtR.s_length;
			oldtR.s_length = AddTime(GetLastEventTime(),e);

			tR.fCount = fCount - oldtR.fCount;
			oldtR.fCount = fCount;

			if(Phase == "enabled")
			{
				eTime = eTime + e;

				TeTime = TeTime + eTime;  
				tR.TeTime = TeTime - oldtR.TeTime;
				oldtR.TeTime = TeTime;

				Continue();
			}
			else 
			{
				tR.TeTime = TeTime - oldtR.TeTime;
				oldtR.TeTime = TeTime;

				Continue();
			}
		}
		else if(MSG.ContentValue() == "complete") // REPLICATE
		{
			tR.s_length = AddTime(GetLastEventTime(),e) - oldtR.s_length;

			tR.fCount = fCount;

			if(Phase == "enabled")
			{
				eTime = eTime + e;

				TeTime = TeTime + eTime;  
				tR.TeTime = TeTime;				
			}
			else
			{
				tR.TeTime = TeTime;
			}

			Passivate();
		}
		else if(MSG.ContentValue() == "terminate") // exit
			Passivate();
	}
	else
	{
		MsgData = *((msg_type *)(MSG.ContentValue()));

		if(MsgData.type == DT)	// "token"�ΰ��
		{			 
			if(Phase == "input")
			{ // input arc���� multi���� ������ inf, �ƴϸ� 0

				buffer.push(MsgData.value.data);	

				map <CString, state_type>::iterator IterPos;
				//IterPos = emap.find(getPMName(MSG.ContentPort()));
				IterPos = emap.find(MSG.ContentPort());
				if(IterPos == emap.end()) { Display("Halt"); NewLine(); exit(0); }
				//emap[getPMName(MSG.ContentPort())].cur_tkn = MsgData.value.cur_tkn;
				emap[MSG.ContentPort()].cur_tkn = MsgData.value.cur_tkn;

				Ntoken++;

				if(Ntoken < NTCDmulti)
				{
					Continue();
				}
				else
				{
					Ntoken = 0;
					HoldIn("input", 0);
				}
			}
			else
				Continue();
		}
		else if(MsgData.type == CT)
		{
			map <CString, state_type>::iterator IterPos;
			//IterPos = emap.find(getPMName(MSG.ContentPort()));
			//if(IterPos == emap.end()) { Display("Halt"); NewLine(); exit(0); }
			//emap[getPMName(MSG.ContentPort())].cur_tkn = MsgData.value.cur_tkn;
			//emap[getPMName(MSG.ContentPort())].state = MsgData.value.data;
			IterPos = emap.find(MSG.ContentPort());
			if(IterPos == emap.end()) { Display("Halt"); NewLine(); exit(0); }
			emap[MSG.ContentPort()].cur_tkn = MsgData.value.cur_tkn;
			emap[MSG.ContentPort()].state = MsgData.value.data;

			if(MsgData.value.cur_tkn == 10)  // �׽�Ʈ�ڵ�
				Display("");

			if(Phase == "checking")
				Continue();
			else if(Phase == "disabled")
				HoldIn("checking", 0);
			else if(Phase == "enabled")
			{
				eTime = eTime + e;
				TeTime = TeTime + eTime;  // enable���¿��� �����Ǳ� �������� �ð��� �߰�
				eTime = 0;

				HoldIn("checking", 0);
			}
			else if(Phase == "waiting")
			{
				//eTime = eTime + e;
				//TeTime = TeTime + eTime;  // enable���¿��� �����Ǳ� �������� �ð��� �߰�
				//eTime = 0;

				HoldIn("checking", 0);
			}
			else if(Phase == "input")
			{
				Continue();
			}
			else if(Phase == "output")
			{
				Continue();
			}
			else
				Continue();
		}
		else if(MsgData.type == CI)
		{
			priomap.clear();
			pbmap.clear();

			pb_bid = MsgData.value.pb_bid;

			if(Phase == "disabled")
				HoldIn("checking", 0);
			else if(Phase == "enabled")
			{
				eTime = eTime + e;
				TeTime = TeTime + eTime;  // enable���¿��� �����Ǳ� �������� �ð��� �߰�
				eTime = 0;

				HoldIn("checking", 0);
			}
			else if(Phase == "waiting")
			{
				//eTime = eTime + e;
				//TeTime = TeTime + eTime;  // enable���¿��� �����Ǳ� �������� �ð��� �߰�
				//eTime = 0;

				HoldIn("checking", 0);
			}
			else
				Continue();
		}
		else if(MsgData.type == SI)
		{
			priomap[MsgData.value.data] = MsgData.value.prio; // prio means priority value.
			pbmap[MsgData.value.data] = MsgData.value.pb;

			if(Phase == "checking")
				Continue();
			else if(Phase == "disabled")
			{
				Continue();
			}
			else if(Phase == "enabled")
			{
				eTime = eTime + e;
				TeTime = TeTime + eTime;  // enable���¿��� �����Ǳ� �������� �ð��� �߰�
				eTime = 0;

				Continue();
			}
			else if(Phase == "waiting")
			{
				if((int)priomap.size() < N_tim+N_imm) 
				{
					//eTime = eTime + e;
					//TeTime = TeTime + eTime;  // enable���¿��� �����Ǳ� �������� �ð��� �߰�
					//eTime = 0;

					Continue();
				}
				else 
				{
					//eTime = eTime + e;
					//TeTime = TeTime + eTime;  // enable���¿��� �����Ǳ� �������� �ð��� �߰�
					//eTime = 0;
					flag = true;
					HoldIn("checking", 0);
				}
			}
			else if(Phase == "input")
			{
				Continue();
			}
			else if(Phase == "output")
			{
				Continue();
			}
			else 
				Continue();
		}
		else
			Continue();
	}
}

void Transition::IntTransitionFN(void)
{
 	 char GENRMessage[100]={0,};
//Display(Name); Display("(int) --> "); NewLine();

	 if(Phase == "checking")
	 {
		 if(MsgData.value.prio == -1) // !isAllSatisfied() // �ӵ������� ����. 
		 {
			 HoldIn("disabled", INF);
		 }
		 else
		 {
			 switch(isMaxPriority(my_priority)){
				 case NOTYET : 
					 HoldIn("waiting", INF);
					 break;
				 case NO :
					 HoldIn("disabled", INF);
					 break;
				 case YES :
					/* if(!isGuard())
					 {
						 HoldIn("disabled", INF);
					 }
					 else*/
					 {
						 if(tr_type == TIM)
						 {
							 tTime = gettTime();
							 // if(tTime == -1) Display("����");

							 HoldIn("enabled", tTime);  // tTime: Ʈ�����ǽð�, md: mark dependent(����Ʈ�� 1)
						 }
						 else if(tr_type == IMM) // tRate == 0
						 {
							 if(isProb(pb_bid))
							 {
								 tTime = 0;  
								 HoldIn("enabled", tTime);
							 }
							 else
								 HoldIn("disabled", INF);
						 }
					 }

					 break;
			 }
		 }
	 }
	 else if(Phase == "enabled")
	 {	
		 // TeTime = TeTime + tTime;
 		 TeTime = TeTime + Sigma; // Sigma�� ���ݱ����� ���ӽð���. ������ �ɰ��⶧���� tTime��� Sigma ���
		 eTime = 0;

		 if(NTCDmulti > 0)
			 HoldIn("input", INF);
		 else
			 HoldIn("input", 0);
	 }
	 else if(Phase == "input")
	 {
		 HoldIn("output", 0);
	 }
	 else if(Phase == "output")
	 {
		 HoldIn("checking", 0);
	 }
	 else 
		 Continue();
}

void Transition::OutputFN(void) 
{
 	 char GENRMessage[100]={0,};
//Display(Name); Display("(out) --> "); Display(Phase); NewLine();
	 int i;
	 if(Phase == "checking")
	 {
		 if(!isAllSatisfied())
		 {
			 MsgData.type = SI; 
			 MsgData.value.data = Name;
			 MsgData.value.tr_type = tr_type;
			 MsgData.value.prio = -1;
			 priomap[Name] = MsgData.value.prio;
			 MsgData.value.pb = -1;
			 pbmap[Name] = MsgData.value.pb;
		 }
		 else
		 {
			 MsgData.type = SI; 
			 MsgData.value.data = Name;
			 MsgData.value.tr_type = tr_type;
			 MsgData.value.prio = tr_type * my_priority;
			 priomap[Name] = MsgData.value.prio;
			 if(tr_type == TIM)
				 MsgData.value.pb = 0;
			 else 
				 MsgData.value.pb = get_prob();
			 pbmap[Name] = MsgData.value.pb;
		 }

		 MakeContent("out", &MsgData); // Ʈ���������� ����
	 }
	 else if(Phase == "waiting")
	 {
		 MakeContent();
	 }
	 else if(Phase == "enabled")
	 {
		 for(i = 0; i < (int)Foutpt.size(); i++)
		 {
			 MsgData.type = CT;
			 MsgData.value.data = "fire";

			 MakeContent(Foutpt[i].name, &MsgData);
		 }
	 }
	 else if(Phase == "input")
	 {
		 MakeContent();
	 }
	 else if(Phase == "output")
	 { 	
		 //tR.s_length = GetNextEventTime();
		 fCount++;
		 //tR.fCount = fCount;

		 for(i = 0; i < (int)Doutpt.size(); i++)
		 {
			 MsgData.type = DT;

			 for(int j = 0; j < Doutpt[i].multi; j++)
			 {
				 MsgData.value.cur_tkn = Doutpt[i].multi;

				 if(buffer.size() > 0)
				 {
					 MsgData.value.data = buffer.front(); // ���ۿ� ���� ��ū�� ����,
					 buffer.pop();
				 }
				 else
					 MsgData.value.data = "token";        // �ƴϸ� ���� �����ؾ� ��.
				 
				 MakeContent(Doutpt[i].name, &MsgData);
			 }

	 		// MakeContent("token", &MsgData); // Ʈ�����༭�� ���� .. 20131115 Ʈ���༭���� Ȱ���� ���� �ּ�ó����.
		 }
         
		 priomap.clear();
		 pbmap.clear();

		 MsgData.type = CI;

		 MsgData.value.data = Name;
		 //MsgData.value.cur_tkn = -1; 
		 MsgData.value.prio = -1; // disable���� �ǹ���
		 MsgData.value.pb_bid = (double)rand() / (RAND_MAX+1);
		 pb_bid = MsgData.value.pb_bid;
		 MakeContent("out", &MsgData); // Ʈ���������� ����
	 }
	 else
		 MakeContent();
}

void Transition::InitializeFN(void)
{	
	NHinpt = Hinpt.size(); 	
	NGinpt = Ginpt.size();
	NMinpt = Minpt.size();
	NTDinpt = TDinpt.size();
	NIDinpt = IDinpt.size();
	NFoutpt = Foutpt.size();	
	NDoutpt = Doutpt.size(); 

	NTCDmulti = getNTCDmulti();

	emap.clear();

	//for(int i = 0; i < NHinpt; i++)
	//	emap[getPMName(Hinpt[i].name)].state = "disable";

	//for(int i = 0; i < NTDinpt; i++)
	//	emap[getPMName(TDinpt[i].name)].state = "disable";

	//for(int i = 0; i < NIDinpt; i++)
	//	emap[getPMName(IDinpt[i].name)].state = "disable";

	//for(int i = 0; i < NGinpt; i++)
	//	emap[getPMName(Ginpt[i].name)].state = "disable";

	//for(int i = 0; i < NMinpt; i++)
	//	emap[getPMName(Minpt[i].name)].state = "disable";

	for(int i = 0; i < NHinpt; i++)
		emap[Hinpt[i].name].state = "disable";

	for(int i = 0; i < NTDinpt; i++)
		emap[TDinpt[i].name].state = "disable";

	for(int i = 0; i < NIDinpt; i++)
		emap[IDinpt[i].name].state = "disable";

	for(int i = 0; i < NGinpt; i++)
		emap[Ginpt[i].name].state = "disable";

	for(int i = 0; i < NMinpt; i++)
		emap[Minpt[i].name].state = "disable";

	
	Ntoken = 0;
	Nsatisfied = 0;

	fCount = 0;
	eTime = 0;
	tTime = 0;
	TeTime = 0;
	md = 1; // marking dependent. ����Ʈ�� 1
	pb_bid = 0;

	tR.s_length = oldtR.s_length = newtR.s_length = TEST.CClock;
	tR.name = oldtR.name = newtR.name = this->Name;
	tR.fCount = oldtR.fCount = newtR.fCount = this->fCount;
	tR.TeTime = oldtR.TeTime = newtR.TeTime = this->TeTime;

	HoldIn("checking", 0);
}

void Transition::AddHinpt(CString n,int m)
{
	pt_type pt;

	pt.name = n;
	pt.multi = m;
	Hinpt.push_back(pt); // inhibitor arc
}

void Transition::AddGinpt(CString n,int m)
{
	pt_type pt;

	pt.name = n;
	pt.multi = m;
	Ginpt.push_back(pt);
}

void Transition::AddMinpt(CString n,int m)
{
	pt_type pt;

	pt.name = n;
	pt.multi = m;
	Minpt.push_back(pt);
}

void Transition::AddTDinpt(CString n,int m)
{
	pt_type pt;

	pt.name = n;
	pt.multi = m;
	TDinpt.push_back(pt); 
}

void Transition::AddIDinpt(CString n,int m)
{
	pt_type pt;

	pt.name = n;
	pt.multi = m;
	IDinpt.push_back(pt); 
}

void Transition::AddFoutpt(CString n,int m)
{
	pt_type pt;

	pt.name = n;
	pt.multi = m;
	Foutpt.push_back(pt);
}

void Transition::AddDoutpt(CString n,int m)
{
	pt_type pt;

	pt.name = n;
	pt.multi = m;
	Doutpt.push_back(pt);
}

int Transition::getNTCDmulti(void)
{
	int i;
	int n = 0;

	for(i = 0; i < (int)IDinpt.size(); i++)
	{
		n += IDinpt[i].multi;
	}

	for(i = 0; i < (int)TDinpt.size(); i++)
	{
		n += TDinpt[i].multi;
	}

	return n;
}

bool Transition::isAllSatisfied(void)
{
   	map <CString, state_type> ::iterator IterPos;

	for(IterPos = emap.begin(); IterPos != emap.end(); ++IterPos)
	{
		if(IterPos->second.state == "disable")
			return false;
	}

	if(!isGuard())
		return false;

	return true;
}

bool Transition::isGuard(void)
{
	if(NGinpt > 0)
	{
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//        if(emap["ginPMp0"].cur_tkn >= 2)  // ex) if (#mark(p0) < 2) then transition is enabled. 
//           return false;
//
//        "guard("tpup",gtpup);" in SPNP 
//        => if(Name == "TMtpup") 
// 		     { 
// 		         return gtpup();
//           }
//           else if(Name == "...) { ... }
//////////////////////////////////////////////////////////////////////////////////////////////////////////

// TODO: Add guard funcions checking routine

// Till here: Add guard functions checking routine
////////////////////////////////////////////////////////////////
	}
	else
		return true;
}

int Transition::isMaxPriority(double prio)
{
	map <CString, double>::iterator IterPos;

	if((int)priomap.size() < N_tim+N_imm) // ��� priorityȹ���߳�?
	{
		return NOTYET;
	}

	for(IterPos = priomap.begin(); IterPos != priomap.end(); ++IterPos)
	{
		if((tr_type * prio) < IterPos->second)
			return NO;
	}

	return YES;
}

void Transition::modify_priority(double max)
{
	map <CString, double>::iterator IterPos; 

	for(IterPos = priomap.begin(); IterPos != priomap.end(); ++IterPos)
	{
		if(IterPos->second < max)
			IterPos->second = -1;
	}
}

double Transition::mark(CString p)
{
	CString pn = "PM" + p;
	CString tdinpn, idinpn, hinpn,ginpn, minpn;
	int mk;

	//map <CString, state_type>::iterator IterPos;
	//IterPos = emap.find(pn);
	//if(IterPos == emap.end()) { Display("Halt"); NewLine(); exit(0); }

	//return emap[pn].cur_tkn;

	tdinpn = "tdin" + pn;
	idinpn = "idin" + pn;
	hinpn = "hin" + pn;
	ginpn = "gin" + pn;
	minpn = "min" + pn;

	if((mk=checkPN(ginpn)) != -1)
		return mk;
	else
	{
		if((mk=checkPN(minpn)) != -1)
			return mk;
		else
		{
			if((mk=checkPN(tdinpn)) != -1)
				return mk;
			else
			{
				if((mk=checkPN(idinpn)) != -1)
					return mk;
				else
				{
					if((mk=checkPN(hinpn)) != -1)
						return mk;
					else
						return 0;
				}
			}
		}
	}
}
int Transition::checkPN(CString s)
{
	map <CString, state_type>::iterator IterPos;

	IterPos = emap.find(s);

	if(IterPos == emap.end()) 
		return -1;
	else
		return emap[s].cur_tkn;
}

//double Transition::mark(CString pn)
//{
//	ListElement *p;	
//	pn = "PM" + pn;
//
//	p = TEST.Children.GetHead();
//
//	do{
//		if(p == NULL) break;
//
//		if(p->Model->Name == pn)
//		{
//			return ((Place *) p->Model)->buffer.size();
//		}
//
//		p = p->Next;
//
//	}while(1);
//
//	exit(0);
//}


int Transition::isProb(double bid)
{
	double total_pb = 0, real_pb = 0, start_pb = 0, end_pb = 0;
	map <CString, double>::iterator IterPos;

	if((int)pbmap.size() < N_tim+N_imm) // ��� pbȹ���߳�?
	{
		return NOTYET;
	}
	else
	{  
		for(IterPos = pbmap.begin(); IterPos != pbmap.end(); ++IterPos) // ��ü Ȯ�� ���
		{
			//if(IterPos->second == -1 || IterPos->second == 0) // -1:disable, 0:TIM
			if(priomap[IterPos->first] < priomap[Name]) // ���ǳ����� �����ϰ� priority���� IMM�� ������.
				continue;

			total_pb += IterPos->second;
		} 

		if(total_pb == get_prob()) // �ڽŸ� enabled�� ���.
			return YES;

		for(IterPos = pbmap.begin(); IterPos != pbmap.end(); ++IterPos)
		{
			//if(IterPos->second == -1 || IterPos->second == 0) // -1:disable, 0:TIM
			if(priomap[IterPos->first] < priomap[Name]) // ���ǳ����� �����ϰ� priority���� IMM�� ������.
				continue;

			end_pb = start_pb + (IterPos->second / total_pb);

			if(start_pb <= bid && bid < end_pb)
			{
				if(IterPos->first == Name)
					return YES; 
			}
			
			start_pb = end_pb;
		}
	
		return NO;
	}
}

double Transition::get_prob(void)
{
	int i;

	if(my_prob > 0)
	{                                           
		return my_prob;                           
	}
	else if(my_prob < 0)
	{ 
		for(i = 0; i < (int)Minpt.size(); i++)
		{
			if(mdPlace == getPMName(Minpt[i].name))
			{
				return(mark(mdPlace.Right(mdPlace.GetLength()-2)) * my_prob * (-1));
			}
		}
	}
	else if(my_prob == 0)  // function
	{ 
		/*if(fn == "prob_t0")
			return(prob_t0());
		else if(fn == "prob_t1")
			return(prob_t1());*/

	}

	return(-1);
}

double Transition::gettTime(void)
{
	if(tRate == -1) // function
	{				
		/*if(fn == "func_hr")
			return(expdist(funchr()));
		if(fn == "func_wr")
			return(expdist(funcwr()));
		if(fn == "func_cr")
			return(expdist(funccr()));
		else*/
			return(-1);
	}
	else if(tRate > 0)
	{
		if(mdPlace != "")
		{
			md = emap["tdin"+mdPlace].cur_tkn;
		}

		return(expdist(tRate * md));
	}
	else
		return(-1);
}
