#include "atomic.h"
#include "tglobal.h"

class Transition : public ATOMIC {
public:
	int flag;
	int tr_type;
	int N_imm;
	int N_tim;
	double my_priority, max_priority;
	double my_prob, pb, pb_bid;
    double (*mfunc)(void);

	double eTime;
	double fCount;

	CString mdPlace;
	int md;

	double tTime;
	double tRate;
	double TeTime;

	tmr_type tR, oldtR, newtR;

	msg_type MsgData;

	typedef struct {
		CString state;
		int cur_tkn;  // add for guard function
	} state_type;

	queue <CString> buffer;
	map <CString, state_type> emap;
	map <CString, double> priomap;
	map <CString, double> pbmap;

	vector <pt_type> Hinpt;
	vector <pt_type> Ginpt;
	vector <pt_type> Minpt;
	vector <pt_type> TDinpt;
	vector <pt_type> IDinpt;
	vector <pt_type> Foutpt;
	vector <pt_type> Doutpt;

	int Ntoken;

	int NHinpt;
	int NGinpt;
	int NMinpt;
	int NTDinpt;
	int NIDinpt;
	int NFoutpt;
	int NDoutpt;
	
	int NTCDmulti;

	int Nsatisfied;


public:
	Transition(CString);   // imm tr
	Transition(char *);    // imm tr

	Transition(CString, double);  // timed tr(name, rate)
	Transition(char *, double);   // timed tr(name, rate)

	Transition(CString, double, CString);  // timed tr(name, rate, dependent pl)
	Transition(char *, double, CString);   // timed tr(name, rate, dependent pl)

    Transition(CString, double (__cdecl *)(void)); // timed tr(name, func_pointer) �̱���
    Transition(char *, double (__cdecl *)(void));  // timed tr(name, func_pointer) �̱���

	Transition(CString, CString );  // timed tr(name, func_name)
	Transition(char *, CString );   // timed tr(name, func_name)
	CString fn;

    void ExtTransitionFN(double,DevsMessage);
	void IntTransitionFN(void);
	void OutputFN(void);
	void InitializeFN(void);

	int getNTCDmulti(void);
	bool isAllSatisfied(void);
	int isMaxPriority(double);
	void modify_priority(double);

	int isProb(double);
	double get_prob(void);

	void AddHinpt(CString,int);
	void AddGinpt(CString,int);
	void AddMinpt(CString,int);
	void AddTDinpt(CString,int);
	void AddIDinpt(CString,int);
	void AddFoutpt(CString,int);
	void AddDoutpt(CString,int);

	double get_fCount()
	{
		return fCount;
	}

	double get_TeTime()
	{
		return TeTime;
	}

	double mark(CString);

	CString getPMName(CString);
	int checkPN(CString);
	bool isGuard(void);
	double gettTime(void);

///////////////////////////////////////
// GUARD Functions 
// TODO : Add guard functions declaration in SPNP	

// Till here: Add guard functions declaration
///////////////////////////////////////


///////////////////////////////////////
// DISTRIBUTION Functions  
// TODO : Add distribution functions 
//  ...
///////////////////////////////////////

};
