#include <iostream>
#include <fstream>
#include <string>
#include<cstring>

using namespace std;

// Intermediate Output File Streams------------------------------------------------------------------------

ofstream globalVariablesFile; // 1.1
ofstream netFuncFile; // 1.2
ofstream modGuardFile; // 1.3
ofstream guardFuncDec; // 2.1
ofstream modGuardFuncDef; // 2.1
ofstream isGuardFile;  // 2.2
ofstream rewardFunc; // 3.0

// Global variables, prototype, guard function, net, probablity and distribution function parser (1.1, 1.2)
void parse_contents(const char* fileName, const char* mode, const char* strStart, const char* strEnd)
{
    int offset;
    string line;
    ifstream myFile;

    if(mode == "NET") 
        netFuncFile.open("out/net_function_contents.txt");
    else {
        globalVariablesFile.open("out/global_prototype_guard.txt", ios_base::app);
    }

    myFile.open(fileName);
    if (myFile.is_open())
    {
        while (!myFile.eof())
        {
            getline(myFile, line);
            if ((offset = line.find(strStart, 0)) != string::npos)
            {
               while(!myFile.eof()){

                if(!strcmp(strStart, "DISTRIBUTION")) {
                    if((offset = line.find("GUARD", 0)) != string::npos)
                    break;
                }

                if((offset = line.find(strEnd, 0)) != string::npos)
                  break;
                
                if(mode == "NET")
                    netFuncFile<<line<<endl;
                else
                    globalVariablesFile<<line<<endl;

                getline(myFile, line);
              }
            }
        }
        myFile.close();
     }
    else { 
        //in a gui, throw an exception
        if(mode == "NET")
            netFuncFile<<"Unable to open the SPNP .c file"<<endl;
        else
            globalVariablesFile<<"Unable to open the SPNP .c file"<<endl;
    }

    if(mode == "NET")
        netFuncFile.close();
    else
        globalVariablesFile.close();
}

// Modifying transtion.h and transition.c function in DEVS, guard-functions-parser (2.1)
void guard_function_to_transition(const char* fileName, const char* strStart, const char* strEnd)
{
    int offset;
    string line;
    ifstream myFile;

    myFile.open(fileName);

    if(strStart == "Prototype" || strEnd == "OPTIONS")
       guardFuncDec.open("out/guard_func_dec.txt");
    
    if(strStart == "/* GUARD Functions */" || strEnd == "/* REWARD Functions */")
       modGuardFuncDef.open("out/modified_guard_func_def.txt");

    if (myFile.is_open())
    {
        while (!myFile.eof())
        {
            //getline function keeps extracting the subsequent line in the line
            getline(myFile, line);

            //if the line extracted has a matching string = strStart
            if ((offset = line.find(strStart, 0)) != string::npos)
            {
               while(!myFile.eof()){
                if((offset = line.find(strEnd, 0)) != string::npos)
                  break;
                
                //since guard functions are of int type only, the next if condition
                //ensures that only functions of type int are written to the file.
                if(strStart == "Prototype" || strEnd == "OPTIONS") {
                   if((offset = line.find("int", 0)) != string::npos) {
                      guardFuncDec<<line<<endl;
                   }
                }

                if(strStart == "/* GUARD Functions */" || strEnd == "/* REWARD Functions */") {
                    //add Transition in between int and g
                    if((offset = line.find("int", 0)) != string::npos) {
                      modGuardFuncDef<<line.insert(4, "Transition::")<<endl;
                    }
                    else
                    modGuardFuncDef<<line<<endl;
                }
                getline(myFile, line);
              }
            }
        }
        myFile.close();
     }
    else {
        if(strStart == "Prototype" || strEnd == "OPTIONS")
            guardFuncDec<< "Unable to open the SPNP .c file" << endl;
        if(strStart == "/* GUARD Functions */" || strEnd == "/* REWARD Functions */")
            modGuardFuncDef<< "Unable to open the SPNP .c file" << endl;
    }
    guardFuncDec.close();
    modGuardFuncDef.close();
}
         
// (1.3)
void add_vguard_def(string word, const char* fileName) {
    modGuardFile <<"{"<<endl;

    int offset;
    string line;
    ifstream file;
    file.open(fileName);
    
    if (file.is_open())
    {
        while (!file.eof())
        {
            //getline function keeps extracting the subsequent line in the line
            getline(file, line);

            //if the line extracted has a matching string
            if ((offset = line.find("int " + word + " ()", 0)) != string::npos)
            {
                getline(file, line);

                size_t search = 0;
                while(search < line.length()) {
                  search = line.find('"', search);

                  if(search != string::npos) {
                      search = search + 1;
                      size_t search2 = search;
                      search = line.find('"', search2);
                      modGuardFile<<"  vguard.push_back(\""<<line.substr(search2, search-search2)<<"\");"<<endl;
                  }
                  else {
                    break;
                  }

                  search = search+1;
                }
            }
        }
    }
    modGuardFile <<"}\n"<<endl;
}

// (1.3)
void modify_guard_func_in_devs(const char* fileName, const char* strStart, const char* strEnd)
{
    int offset;
    string line;
    ifstream myFile;

    myFile.open(fileName);

    modGuardFile.open("out/mod_guard_file.txt");
    modGuardFile.close();

    modGuardFile.open("out/mod_guard_file.txt", ios_base::app);

    if (myFile.is_open())
    {
        while (!myFile.eof())
        {
            //getline function keeps extracting the subsequent line in the line
            getline(myFile, line);

            //if the line extracted has a matching string = strStart
            if ((offset = line.find(strStart, 0)) != string::npos)
            {
               while(!myFile.eof()){
                if((offset = line.find(strEnd, 0)) != string::npos)
                  break;
                
                //to find "guard" fucntion in SPNP .c file
                if((offset = line.find("guard", 0)) != string::npos) {
                    
                    char delimiter = '"';
                    string wordBetweenQuotes, wordBetweenComma;
                    size_t pos = 0;
                    
                    while((pos = line.find(delimiter)) != string::npos) {
                        //first in "guard("tquick", gf)", "guard(" will be put in wordBetweenQuotes,
                        //in the next iteration "tquick" will be put. Hence latest word is between the delimiter.
                        //i.e. quick without t.
                        wordBetweenQuotes = line.substr(0, pos);
                        line.erase(0, pos + 2);
                    }
                    
                    while((pos = line.find(')')) != string::npos) {
                        wordBetweenComma = line.substr(0, pos);
                        line.erase(0, pos + 1);
                    }
                    
                    modGuardFile<<"if(tn == \"t"<<wordBetweenQuotes<<"\")\n"; 
                    add_vguard_def(wordBetweenComma, fileName);                   
                }
                getline(myFile, line);
              }
            }
        }
        myFile.close();
     }
    else
        modGuardFile<< "Unable to open the SPNP .c file" << endl;

    modGuardFile.close();
}
              
// (2.2)
void parse_for_is_guard(const char* fileName, const char* strStart, const char* strEnd)
{
    int check = 0;
    int offset;
    string line;
    ifstream myFile;

    myFile.open(fileName);

    isGuardFile.open("out/isGuard_func.txt");
    isGuardFile.close();
    
    isGuardFile.open("out/isGuard_func.txt", ios_base::app);

    if (myFile.is_open())
    {
        while (!myFile.eof())
        {
            //getline function keeps extracting the subsequent line in the line
            getline(myFile, line);

            //if the line extracted has a matching string = strStart
            if ((offset = line.find(strStart, 0)) != string::npos)
            {
               while(!myFile.eof()){
                if((offset = line.find(strEnd, 0)) != string::npos)
                  break;
                
                //to find "guard" fucntion in SPNP .c file
                if((offset = line.find("guard", 0)) != string::npos) {
                    
                    char delimiter = '"';
                    string wordBetweenQuotes, wordBetweenComma;
                    size_t pos = 0;
                    
                    while((pos = line.find(delimiter)) != string::npos) {
                        //first in "guard("tquick", gf)", "guard(" will be put in wordBetweenQuotes,
                        //in the next iteration "tquick" will be put. Hence latest word is between the delimiter.
                        //i.e. quick without t.
                        wordBetweenQuotes = line.substr(0, pos);
                        line.erase(0, pos + 2);
                    }
                    
                    while((pos = line.find(')')) != string::npos) {
                        wordBetweenComma = line.substr(0, pos);
                        line.erase(0, pos + 1);
                    }
                    
                    check = 1;
                    isGuardFile<<"if(Name == \"TMt"<<wordBetweenQuotes<<"\")\n  { return "<<wordBetweenComma<<"(); }\n";                    
                   
                }
                getline(myFile, line);
              }
            }
        }

        if(check == 1) {
            isGuardFile<<"else\n    return true;\n";
        }
        myFile.close();    
     }
    else
        isGuardFile<< "Unable to open this file." << endl;
    isGuardFile.close();
}

// (3.0)
void parse_reward_func(const char* fileName, const char* strStart, const char* strEnd)
{
    int offset;
    string line;
    ifstream myFile;

    rewardFunc.open("out/modified_reward_func.txt");

    myFile.open(fileName);
    if (myFile.is_open())
    {
        while (!myFile.eof())
        {
            getline(myFile, line);
            if ((offset = line.find(strStart, 0)) != string::npos)
            {
               //To not copy the function name
               getline(myFile, line);
               getline(myFile, line);
               
               if((offset = line.find(strEnd, 0)) != string::npos)
                  break;

               while(!myFile.eof()){
                if((offset = line.find(strEnd, 0)) != string::npos)
                  break;

                if((offset = line.find("return", 0)) != string::npos) {
                    string replaceWith = "rw = ";
                    string toBeReplaced = "return";
                    size_t pos = line.find(toBeReplaced);
                    size_t len = toBeReplaced.length();

                    line.replace(pos, len, replaceWith);
                    rewardFunc<<line<<endl;
                }
                else {
                    rewardFunc<<line<<endl;
                }
                
                getline(myFile, line);
              }
            }
        }
        myFile.close();
     }
    else
        //in a gui, throw an error
        rewardFunc<< "Unable to open this file." << endl;
    rewardFunc.close();
}

// Writing to DEVS

void copy_to_DEVS(char* sourceFile, char* targetFile, int targetLine)
{
    FILE* resultFilePtr = fopen("result.txt", "w");
    FILE* sourceFilePtr = fopen(sourceFile, "r");
    FILE* targetFilePtr = fopen(targetFile, "r");

    char line[256];
    int lineCounter= 0;

    while (fgets(line, 256, targetFilePtr)!=NULL)
    {
        if (lineCounter == targetLine-1) 
        {
            char lineToBeAdded[256];
            //Now read sourceFile
            while (fgets(lineToBeAdded, 256, sourceFilePtr) != NULL)
            {
                fprintf(resultFilePtr, "%s", lineToBeAdded);
            }
            fprintf(resultFilePtr, "%s", "\n");
        }
        fprintf(resultFilePtr, "%s", line);
        lineCounter++;
    }

    fclose(sourceFilePtr);
    fclose(targetFilePtr);
    fclose(resultFilePtr);

    //Remove old .txt file with new one
    remove(targetFile);
    rename("result.txt", targetFile);

}

void check_arguments(int argc, char** argv) {
    if(argc != 3) {
        cout << "USAGE ERROR: CSPL file path/SPNP2DEVS folder path not Specified\n";
        exit(0);
    }
    FILE* spnpFile = fopen(argv[1], "r");
    if(spnpFile == NULL) {
        cout << "FILE PATH ERROR: File cannot be opened\n";
        exit(0);
    }
    fclose(spnpFile);
}

char* check_and_add_slash(char* path) {
    char* slash = "\\";
    int len = strlen(path);
    if(path[len-1] != '\\') {
        strcat(path, slash);
    }
    return path;
}

int main(int argc, char** argv)
{

    check_arguments(argc, argv);
    char* DEVSEnginePath = check_and_add_slash(argv[2]);
    
    // Parsing------------------------------------------------------------------------------------------------------

    parse_contents(argv[1], "GLOBAL", "global", "Prototype"); // 1.1
    parse_contents(argv[1], "GLOBAL", "Prototype", "OPTIONS");
    parse_contents(argv[1], "GLOBAL", "GUARD", "REWARD");
    parse_contents(argv[1], "GLOBAL", "PROBABILITY", "DISTRIBUTION");
    parse_contents(argv[1], "GLOBAL", "DISTRIBUTION", "REWARD");
    parse_contents(argv[1], "NET", "PLACE", "}"); // 1.2

    guard_function_to_transition(argv[1], "Prototype", "OPTIONS"); // 2.1
    guard_function_to_transition(argv[1], "/* GUARD Functions */", "/* REWARD Functions */"); // 2.1

    modify_guard_func_in_devs(argv[1], "TRANSITION", "ARC"); //1.3

    parse_for_is_guard(argv[1], "TRANSITION", "ARC"); // 2.2

    parse_reward_func(argv[1], "/* REWARD Functions */", "}"); // 3.0
    
    // Writing--------------------------------------------------------------------------------------------------------

    //If file name is same, then process max line number first, to avoid line shifting
    char* mainFile = strdup(DEVSEnginePath);
    strcat(mainFile, "Main.cpp");
    cout<<mainFile<<endl;
    copy_to_DEVS("out/net_function_contents.txt", mainFile, 671);
    copy_to_DEVS("out/mod_guard_file.txt", mainFile, 620);
    copy_to_DEVS("out/global_prototype_guard.txt", mainFile, 17);

    char* transitionHeaderFile = strdup(DEVSEnginePath);
    strcat(transitionHeaderFile, "Transition.h");
    cout<<transitionHeaderFile<<endl;
    copy_to_DEVS("out/guard_func_dec.txt", transitionHeaderFile, 119);

    char* transitionFile = strdup(DEVSEnginePath);
    strcat(transitionFile, "Transition.cpp");
    copy_to_DEVS("out/isGuard_func.txt", transitionFile, 717);
    copy_to_DEVS("out/modified_guard_func_def.txt", transitionFile, 46);

    char* transdFile = strdup(DEVSEnginePath);
    strcat(transdFile, "Transd.cpp");
    copy_to_DEVS("out/modified_reward_func.txt", "C:/Users/njkam/Desktop/SPNP2DEVS/SPNP2DEVS/Transd.cpp", 258);

    remove("out/net_function_contents.txt");
    remove("out/mod_guard_file.txt");
    remove("out/global_prototype_guard.txt");
    remove("out/guard_func_dec.txt");
    remove("out/isGuard_func.txt");
    remove("out/modified_guard_func_def.txt");
    remove("out/modified_reward_func.txt");

    return 0;
}